---
name: capture-06-lead-list-builder
description: "Use after a gated post has been running for a while and you want the people who came through it turned into one list, with nothing made up to fill the gaps. Takes the commenter names and headlines from the gated post plus any DM threads that followed and returns one row per captured name, unknown fields marked unknown. Triggers on \"build my lead list from this post\", \"turn these commenters into a list\", \"who came through my gate\", \"make a roster from this thread\", \"list everyone who commented my keyword\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 06 of 06: the lead list builder

## What this does

Takes the names and headlines visible on a gated post, plus whatever DM
threads followed, and turns them into one row per person, with only the
fields the reader actually captured. Nothing is filled in from a guess about
what a person in that role would probably have.

**The line only this unit produces:** one lead row per captured name with
every unknown field marked unknown.

## Required input

1. **Commenter names and headlines**, from the gated post, as shown on the
   screen.
2. **DM threads that followed**, if any, pasted as text.

## What it refuses

**Refusal, nothing to build from.** If the commenter list carries zero names,
stop:

```
NO COMMENTERS SUPPLIED
There is no list to build. [NEEDS: the commenter names and headlines from the
gated post]
```

**Standing rule, never derive a field.** No email is ever constructed from a
name and a company domain, even when both are known. An email is captured
only when it appears verbatim in the input. A company is captured only when
the person states it themselves. This rule cannot be waived by a request to
"just guess the format".

## Method

**Step 1, dedupe the commenter list.** The population is commenter rows as
pasted, counted once each. Two rows are the same person only when name and
headline match exactly. Print:

```
population: commenter rows as pasted
rows pasted: <n>
unique people after dedupe: <n>
duplicates removed: <n>
```

**Step 2, headline field.** For each unique person, the headline is exactly
what was pasted. A blank headline prints `unknown`, never a guessed title.

**Step 3, match DM threads to people.** For each unique person, look for a DM
thread from someone with the same name. If found, `dm status: replied`. If no
thread matches, `dm status: no reply`.

**Step 4, pull only literally stated fields from a matched thread.** Read the
matched thread's messages from that person only. Two fields can be captured
this way:

- `company`: only if the person states it themselves in their own words
  ("I run ops at X", "I work at X"). Never inferred from a headline or a
  domain.
- `email`: only if an email address appears verbatim in their message. Never
  constructed from their name plus a company's domain, even when both are
  known from elsewhere in the same thread.

Any field not literally stated prints `unknown`.

**Step 5, print one row per unique person**, in the order they first appear
in the commenter list.

## Output format

```
# Lead list

## Count
population: commenter rows as pasted
rows pasted: <n>
unique people after dedupe: <n>
duplicates removed: <n>

## Rows
### <name>
headline: <text> | unknown
dm status: replied | no reply
company: <text, literally stated> | unknown
email: <address, literally stated> | unknown
notes: <e.g. "appeared twice in the pasted list, counted once">
```

## Worked case

This is the fixture run. It is `fixtures/commenters-and-dms.md`, executed
line by line against the rules above.

```
## Count
population: commenter rows as pasted
rows pasted: 4
unique people after dedupe: 3
duplicates removed: 1

## Rows
### Grace Whitfield
headline: Freelance brand designer
dm status: replied
company: unknown
email: unknown
notes: appeared twice in the pasted list (rows 1 and 3), counted once; her
reply ("thanks, got it") states no company and no email, so both stay unknown
even though a company could be guessed from her headline. Never derived.

### Tomasz Lund
headline: unknown
dm status: no reply
company: unknown
email: unknown
notes: no headline shown on the comment, and no DM thread from this name in
the pasted input

### Marisol Vega
headline: Ops lead, small agency
dm status: replied
company: Fieldstone Studio
email: marisol@fieldstonestudio.com
notes: both fields literally stated in her own message ("I run ops at
Fieldstone Studio" and the email pasted directly); neither is derived
```

The second fixture, `fixtures/no-commenters.md`, fires the refusal. Its count
line reads `rows pasted: 0`, and no lead rows are written.

## Edge cases

**Two different people share the same name.** If their headlines differ, they
are two separate rows, never merged. If a DM thread cannot be matched to one
of them with certainty, print `dm status: unmatched, two people share this
name` on both rows rather than guessing which one replied.

**A DM thread exists but the sender's name is not on the commenter list.**
Leave it out of this list. This unit builds from the gated post's commenters;
a name that never commented the keyword is a different kind of lead and does
not belong in this ledger.

**Someone states a company that a plausible email domain could be guessed
from.** The email field still prints `unknown`. Company and email are
captured independently; one being known never fills the other in.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never derive an email address, from a name, a company, or any combination
  of the two.
- Never fill a headline, a company, or any other field with a guess about
  what someone in that role would typically have.
- Never merge two different people into one row, or split one person into
  two, without a printed reason.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
