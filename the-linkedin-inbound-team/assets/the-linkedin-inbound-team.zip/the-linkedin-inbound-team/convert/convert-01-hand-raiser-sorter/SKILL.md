---
name: convert-01-hand-raiser-sorter
description: "Use when a gated post has pulled in a list of keyword commenters and you need to know who is worth a reply beyond the file. Takes the commenter list from the gated post, names and headlines as shown, and returns the two-bucket split of who gets a conversation and who gets the file and nothing else. Triggers on \"sort my gate commenters\", \"who from this post is worth a reply\", \"who just wants the file\", \"which of these commenters should I talk to\", \"sort this comment list\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 25 of 30: the hand-raiser sorter

## What this does

Reads the list of people who commented the gate keyword under one post and
splits each name into one of two conversation buckets, using only what the
comment itself carried beyond the keyword, and whether a headline exists to
sort against at all.

**The line only this unit produces:** the two-bucket split of the people who
commented: CONVERSATION, or FILE ONLY, with the printed reason for each row.

This is not the delivery message. Gate Reply Writer (capture-05) sends the
asset to every name on this list regardless of bucket; that already happened
or is happening in parallel. What this unit answers is narrower: does the
comment carry anything besides the keyword that is worth a reply of its own,
once the file is on its way.

## Required input

1. **The commenter list from the gated post**, one row per person, names and
   headlines exactly as shown on the post, with the full comment text each one
   left, not only the keyword, the whole line including whatever came before
   or after it.
2. Nothing else. No follower counts, no company size, no offer sentence, no
   CRM tag, no past-purchase history.

If the comment text was not copied, the run cannot tell a bare keyword from a
keyword plus a question. Every slot on that row that the missing text would have
filled prints `[NEEDS: the comment text as left, not only the keyword]`, and that
means all four of them: `comment`, `keyword found`, `remainder` and the class.
`keyword found` is a three-value slot for this reason, not a two-value one, and
the row lands in Step 6's `NOT CLASSED` count rather than in a bucket it was
never sorted into.

## What it refuses

**Refusal 1, a blank headline gets parked, never sorted on the name.** A name
with no headline carries nothing this unit can weigh, and sorting it on the name
alone would be a guess wearing a decision. The row is not sorted into either
bucket. It prints one line, under the `### PARKED` heading of the output format
and nowhere else, in this exact shape:

```
- "<name>"   because: blank headline   [NEEDS: the headline as it shows on their comment, or on their profile]
```

That line is the whole refusal. There is no second, longer form of it.

## Method

**Step 1, list every row and merge duplicates.** Walk the pasted list in the
order given. If the same name appears twice, once for each time they commented
the keyword, merge the two rows into one and keep the longer of the two
comment texts. Print `MERGED: "<name>", <n> comments collapsed to 1`.

**Step 2, split each comment at the keyword.** For every merged row, find the
gate keyword inside the comment text and print what is left once it is
removed:

```
comment: "<full comment as left>"
keyword found: yes | no | [NEEDS: the comment text as left, not only the keyword]
remainder: "<what is left after the keyword is removed>" | none | [NEEDS: the comment text as left, not only the keyword]
```

**What comes out, exactly.** The keyword comes out and nothing else comes out
with it. Two tidies are allowed after the removal, and only these two: trim
whitespace from both ends of what is left, and collapse the double space the
removal opened up in the middle. One deletion is allowed: a comma or a full stop
left stranded at the very front, where the keyword used to be, comes off with the
space behind it. Every other word the person wrote stays, including the words
that were wrapped round the keyword. `Sending SWIPE now, also is this ...` leaves
`Sending now, also is this ...`, because `Sending` and `now` are theirs. A
remainder that reads awkwardly is still the remainder, and a run that smooths it
is inventing what the person said.

If the keyword is not found anywhere in the comment, print
`KEYWORD NOT FOUND IN THIS COMMENT` beside the row and still class it. A
person can ask for the file in words that never contain the literal keyword.

**Step 3, the headline gate, run before classing.** Every row with a blank
headline fires Refusal 1 and is parked, regardless of what the remainder
carries.

**Step 4, class the remainder.** Two classes, applied only to rows that
passed Step 3:

| Class | The test |
|---|---|
| `CONVERSATION` | The remainder carries a question, a stated situation, or a specific detail about their own work that is not already inside the keyword |
| `FILE ONLY` | The remainder is empty, or carries only a reaction with no content of its own: a repeated please, a thanks, a tag of somebody else, an emoji-only aside |

A remainder that restates interest in the file with no added content about the
person stays `FILE ONLY` even as a full sentence. "This looks useful, send it
over" adds nothing about them and is `FILE ONLY`. "This looks useful, I have
been trying to fix this exact thing on my own list for a month" adds a stated
situation and is `CONVERSATION`.

**Step 5, per-instance statuses.** One comment can carry more than one fact:
a question about the resource, and a separate remark about their own work.
Where that happens, print both facts on the row. The row still gets one class,
decided by whichever fact is the stronger of the two, but neither fact is
dropped from the printed row to make the row simpler.

**Step 6, the counts.** Population, stated in words: every row on the list you
pasted, one per person, after Step 1's merge. Every row on the list lands in
exactly one of the four counts below, and every count prints, including at zero:

```
population: commenters on the gated post, one row per person after merging duplicates: <n>
CONVERSATION: <n>   <names>
FILE ONLY:    <n>   <names>
PARKED:       <n>   <names>
NOT CLASSED, comment text missing: <n>   <names>
```

The four rows add back to the population. A run where they do not is a run that
has lost somebody, and the fourth row exists because losing them is exactly what
happens when a list arrives with no comment text on it. Those people sit on the
list. Nothing parked them, and no bucket holds them. Check the sum before you
print it.

No percentage is printed. A share computed over one gated post is not large
enough or repeatable enough for a number to mean anything beyond the count
itself.

## Output format

```
# Hand-raiser split for <post description, one line as supplied>

## The list, merged
- "<name>"   headline: "<headline>" | blank
  comment: "<full comment>" | [NEEDS: the comment text as left, not only the keyword]
  keyword found: yes | no | [NEEDS: ...]      remainder: "<remainder>" | none | [NEEDS: ...]

## The split
### CONVERSATION
- "<name>"   because: <the specific thing in the remainder>

### FILE ONLY
- "<name>"   because: <empty remainder | reaction-only remainder, quoted>

### PARKED
- "<name>"   because: blank headline   [NEEDS: the headline as it shows on their comment, or on their profile]

### NOT CLASSED
- "<name>"   because: no comment text pasted   [NEEDS: the comment text as left, not only the keyword]

## Counts
<the population line and four rows from Step 6>
```

## Worked case

This is the fixture run. It is `fixtures/gated-post-commenters.md`, executed
line by line against the rules above.

```
## The list, merged
- "Dara Voss"   headline: "Freelance copywriter for SaaS onboarding"
  comment: "SWIPE, appreciate it"
  MERGED: "Dara Voss", 2 comments collapsed to 1
  keyword found: yes   remainder: "appreciate it"

- "Marcus Iyer"   headline: "Head of Content, Loft & Bramble"
  comment: "SWIPE, I've been rewriting our onboarding emails for three weeks and cannot get the second one right"
  keyword found: yes   remainder: "I've been rewriting our onboarding emails for three weeks and cannot get the second one right"

- "Priya Okonkwo"   headline: blank
  comment: "SWIPE please"
  keyword found: yes   remainder: "please"

- "Callum Reyes"   headline: "Operations Manager, Thistlewick Goods"
  comment: "SWIPE"
  keyword found: yes   remainder: none

- "Naomi Shah"   headline: "Founder, Birchfield Studio"
  comment: "Sending SWIPE now, also is this the same framework you used for the LinkedIn carousel post last month"
  keyword found: yes   remainder: "Sending now, also is this the same framework you used for the LinkedIn carousel post last month"

- "Ravi Chandran"   headline: "Demand Gen Lead, Corvid Analytics"
  comment: "Can someone send me this, saw it on Priya's repost"
  keyword found: no   KEYWORD NOT FOUND IN THIS COMMENT
  remainder: "Can someone send me this, saw it on Priya's repost"

## The split
### CONVERSATION
- "Marcus Iyer"   because: names a specific, ongoing problem with the onboarding sequence, not already in the keyword
- "Naomi Shah"   because: asks a direct question about the resource beyond the keyword itself

### FILE ONLY
- "Dara Voss"   because: reaction-only remainder, "appreciate it"
- "Callum Reyes"   because: empty remainder
- "Ravi Chandran"   because: remainder is a request with no content about their own work, only a source attribution

### PARKED
- "Priya Okonkwo"   because: blank headline   [NEEDS: the headline as it shows on their comment, or on their profile]

### NOT CLASSED
none

## Counts
population: commenters on the gated post, one row per person after merging duplicates: 6
CONVERSATION: 2   Marcus Iyer, Naomi Shah
FILE ONLY:    3   Dara Voss, Callum Reyes, Ravi Chandran
PARKED:       1   Priya Okonkwo
NOT CLASSED, comment text missing: 0
```

Raw list before merge carried 7 rows; Dara Voss commented twice, so the
population after Step 1 is 6, and 2 + 3 + 1 + 0 = 6.

Naomi Shah's remainder keeps `Sending now,` on the front. Those are her words
and the keyword removal has no authority over them: only `SWIPE` came out, then
the double space closed up. Her row still classes `CONVERSATION`, on the
question at the end of the remainder rather than on the tidiness of the start of
it.

The second fixture, `fixtures/no-comment-text-pasted.md`, exercises the input
gap directly: names and headlines only, no comment text. All three headlines are
present, so nothing parks. Executed line by line, every row prints:

```
- "Elin Roskam"   headline: "Marketing Lead, Verrick Home"
  comment: [NEEDS: the comment text as left, not only the keyword]
  keyword found: [NEEDS: the comment text as left, not only the keyword]   remainder: [NEEDS: the comment text as left, not only the keyword]
```

and the counts reconcile against a population none of them reached a bucket in:

```
population: commenters on the gated post, one row per person after merging duplicates: 3
CONVERSATION: 0
FILE ONLY:    0
PARKED:       0
NOT CLASSED, comment text missing: 3   Elin Roskam, Tobias Ndlovu, Marguerite Sole
```

## Edge cases

**Two different people share the same first and last name.** Treat as two
rows only if the headlines differ. If the headlines are identical too, print
`AMBIGUOUS: "<name>" appears twice with matching headlines, cannot confirm
these are the same person or two different ones` and park both rows rather
than guessing which comment belongs to whom.

**The keyword appears inside a word, not as its own token** (the keyword is
"SWIPE" and the comment reads "SWIPED through this already"). Print
`keyword found: partial, inside another word` and treat the whole comment as
the remainder, since the literal keyword was never actually said.

**A commenter's headline is a company name only, no role** ("Thistlewick
Goods"). That is not blank. It passes Step 3 and is classed normally.

**The post had more than one gate keyword running at once** (a rotated
keyword mid-thread). Sort against whichever keyword the individual comment
actually used, printed per row, not against one keyword for the whole list.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never sort a blank-headline row into either bucket.
- Never print counts that do not add back to the population. Every person on the
  pasted list is in exactly one of the four rows, and a row that would fold a
  person into nobody's count is the defect this unit checks for before printing.
- Never invent a situation, a question, or a detail the comment text did not
  carry.
- Never print a percentage or a share over this list. Counts only.
- Never treat two different comments from the same name as two different
  people without checking the headlines match.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
