# Fixture, a long draft pasted the way it was written

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: a draft that opens on an announcement,
restates one of its own findings later, and carries a transition word inside a
sentence worth keeping.

---

I want to talk about something that took me a while to work out.

I keep a file called "questions people ask twice". It started as a note on my
phone in January, after a third call in one week opened with the same sentence.
The sentence was, "how do you actually decide what to write about". I wrote it
down that afternoon.

By March the file had nine entries. Six of the nine asked how to decide. Three
asked about the writing itself. As I said, most of the file is about deciding.

Before I go on, it is worth saying this is a small sample.

Anyway, the file changed how I open a call. The next call I ran, I opened on how
the choice gets made. She booked a second call before we hung up.

The file is still on my phone and it still gets entries.
