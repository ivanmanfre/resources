---
name: engage-02-own-post-reply-writer
description: "Use after you post and comments start coming in, to draft a reply to every commenter that keeps their thread going. Takes the comment thread on your own post, names and headlines as shown, and returns one reply per commenter, each ending in a question only that commenter could answer. Triggers on \"write replies to my post comments\", \"help me respond to these comments\", \"draft replies for my LinkedIn post\", \"what do I say back to these people\", \"reply to everyone who commented\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 02 of 30: the own-post reply writer

## What this does

Reads every comment on your own post and drafts one reply per commenter,
each ending in a question that only that specific commenter, given what they
wrote, could answer.

**The line only this unit produces:** one reply per commenter, each ending
in a question only that commenter can answer.

It does not reply to the post as a whole and it does not write one reply that
gets copy-pasted under everyone's name. A thread that keeps going is one
where the next reply proves you read the specific line, not the general
topic.

## Required input

1. **The comment thread on your post**, with names and headlines as shown,
   pasted whole, one comment per commenter in the order they appear.

Nothing else is required. No engagement figures, no follower counts, no DM
history with any commenter.

## What it refuses

**Refusal 1, no comments to read.** If the paste carries zero comments,
stop:

```
NO COMMENTS FOUND
This unit drafts replies to comments. Paste the thread with at least one
comment in it.
```

**Refusal 2, per comment: one word or an emoji gets no reply.** Applied per
commenter, not to the whole thread. See Step 3.

## Method

**Step 1, split the thread into individual comments.** One row per
commenter: name, headline as shown (or `no headline shown`), and the comment
text, in the order pasted. If the paste is empty, fire Refusal 1 and stop.
Print the population in words: `comments in this thread: <n>`.

**Step 2, classify each comment.** Two classes, printed for every row:

- `CONTENT`: carries at least one word beyond a greeting, a name, or an
  emoji. "Congrats" alone fails. "Congrats, this matches what we saw in
  March" passes.
- `NO CONTENT`: one word, a greeting only, or an emoji with no words.

Print both class rows even when one is empty, population stated above them:

```
comments in this thread: <n>
CONTENT: <n>
NO CONTENT: <n>
```

**Step 3, for every `NO CONTENT` row, print the per-instance refusal and
move on.**

```
<name>: NO REPLY DRAFTED - one word or emoji only ("<the comment as pasted>")
```

**Step 4, for every `CONTENT` row, find the specific thing they said.**
Quote the span of their comment that carries a claim, a question, or a detail:
the whole sentence it sits in, from its first word to its closing punctuation.
Where the claim runs across the whole comment, the whole comment is the span.

Two things come out, and only these two: a sentence that is nothing but a
greeting or a compliment with no detail in it (`Love this,`), and a sign-off. A
clause that sets the claim up stays, even where the reply will not use it. `We
tried a tiered pricing move like this last year and` stays. `This is close to
what we're planning for Q1,` stays. Neither one is a greeting, and cutting them
makes the quote tidier at the price of citing a sentence the person never wrote
on its own. What you quote back is what they said, not the part of it you
wanted.

**Step 5, write the reply.** Rules: names the specific thing from Step 4 in
the first sentence, then asks one question that only this commenter, given
what they wrote, is positioned to answer. A question answerable by anyone
reading the post ("what do you think?") fails this rule; rewrite it so it is
traceable to their own words or their own stated situation.

If the commenter's own comment was itself a direct question, this unit was
not given the answer, since it only reads the comment thread. In that case
the reply names the question as a real one worth answering precisely, prints
`[NEEDS: your answer to "<their question>"]`, and still ends in a follow-up
question that is about the commenter's own situation, not the poster's.
Never guess at the answer to fill the reply.

**Step 6, print the arithmetic.**

```
replies drafted / comments in thread: <n> / <n>
```

This is a count, not a rate to judge by. No percentage is printed, because a
comment thread's ratio of content to noise says nothing about the post and
everything about how people happened to comment that day.

## Output format

```
# Replies
comments in this thread: <n>
CONTENT: <n>   NO CONTENT: <n>

## <name 1>, <headline>
their comment: "<quoted>"
reply: "<the reply text, ending in the question>"

## <name 2>, <headline>
NO REPLY DRAFTED - one word or emoji only ("<comment>")

## Counts
replies drafted / comments in thread: <n> / <n>
```

This is a draft in neutral register, not a claim of your voice. Rewrite each
reply in your own words before you post it.

## Worked case

This worked case is a literal run of `fixtures/product-launch-thread.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Replies
comments in this thread: 5
CONTENT: 3   NO CONTENT: 2

## Tomasz Bilek, Head of Ops at Ferndale Metals
their comment: "We tried a tiered pricing move like this last year and the
mid-tier cannibalized our top tier for two months before it settled."
reply: "The two-month window before it settled is the part I want to
understand. When it settled at Ferndale Metals, did the top tier fully
recover, or did some of that revenue stay parked in the mid-tier for good?"

## Priya Nandan, no headline shown
NO REPLY DRAFTED - one word or emoji only ("🔥")

## Colm Ashworth, Founder at Voss & Rye
NO REPLY DRAFTED - one word or emoji only ("Congrats")

## Selin Aydemir, RevOps Lead at Bramwell Co
their comment: "How did you handle grandfathering people who were already on
the old plan?"
reply: "That's the one detail I'd want to get precise before answering in
public. [NEEDS: your answer to "How did you handle grandfathering people who
were already on the old plan?"] What does Bramwell do today when you change
a plan structure on existing customers?"

## Devon Achebe, Support Manager at Kestrel Freight
their comment: "This is close to what we're planning for Q1, we're worried
about support load doubling."
reply: "Support load doubling is the part of a tier launch that is hardest
to size in advance. Is Kestrel's current support team sized for double
volume already, or is that hire still pending?"

## Counts
replies drafted / comments in thread: 3 / 5
```

Two quotes in this run keep a clause the reply never uses. Tomasz's `We tried a
tiered pricing move like this last year and` and Devon's `This is close to what
we're planning for Q1,` are both context for the claim behind them, and neither
is a greeting, so Step 4 leaves both in. The reply is written from the claim;
the quote is written from the comment.

## Edge cases

**Two commenters say almost the same thing.** Each gets its own reply
referencing their own name and their own wording. Never write one reply and
address it to both.

**The same person commented twice.** Treat each comment as its own row in
Step 1, and draft a reply to each occurrence.

**A commenter's comment is entirely a compliment plus one real detail**
("Love this, we saw the same thing in our Q1 numbers"). This is `CONTENT`:
the detail carries the row, and the reply is written from the detail, not
the compliment.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a fact about the commenter, their company, or their situation
  beyond what their comment states.
- Never draft a reply to a `NO CONTENT` row.
- Never end a reply in a question anyone could answer; it must be traceable
  to that commenter's own words or their own stated situation.
- Never answer a commenter's factual question with an invented fact. Print
  `[NEEDS: ...]` instead.
- Never shorten a quoted comment past what Step 4 licenses. A quote that drops
  a clause the person wrote reads as their words and is not.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
