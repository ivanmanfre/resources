---
name: profile-03-experience-rewriter
description: "Use when the current-role entry on your profile reads like a job description written for HR. Takes the entry exactly as it stands on your profile and returns the description block rewritten as what you do for a buyer, five lines at most. Triggers on \"rewrite my experience section\", \"my current role description is terrible\", \"make my job description sound like an offer\", \"rewrite my LinkedIn job entry\", \"what should my current role say\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 03 of 30: the experience block

## What this does

Takes the current-role entry as it stands, pulls out every activity it actually
states, and writes those activities back as lines a buyer reads as work done for
somebody like them.

**The line only this unit produces:** the current-role description block, five
lines maximum, in offer language.

Offer language here has a fixed meaning, and there is nothing loose about it: the
line starts with the verb, names who the work is for using the entry's own word
for them, and stops where the entry stops.

## Required input

1. **The current-role entry, copied as it stands.** The header (title, company,
   dates, location) and the body, in full. Copy the body even if you think it is
   embarrassing. That is the material.
2. Optional: **the word your buyers use for themselves** (clients, accounts,
   customers, patients, a job title). Used only when the entry's own word is
   vague.

Nothing else. No performance figure, no revenue, no headcount you did not already
write in the entry.

## What it refuses

**Refusal 1, no activity in the entry.** Class every body line first (Step 2). If
the count of activities is zero, stop:

```
NOTHING TO REWRITE
lines in the entry body: <n>
activities found: 0

An activity is something you do that could be written in next week's diary. This
entry has <n> lines and none of them names one.
What it carries instead: <n> results, <n> lines describing you.

Supply three lines answering this: what did you do last week that somebody
outside your company would have paid for. Plain sentences, no polish.
```

This is the same refusal for the two shapes it fires on: an entry that is a title
and a set of dates with no body, and an entry that is a list of results with no
work behind them. Both give this unit nothing but a mood to work from.

**Refusal 2, no line ships with an open slot.** An activity whose beneficiary the
entry never names keeps `[NEEDS: who this work is for]` in the line. Print under
the block:

```
DO NOT PASTE LINES CARRYING [NEEDS: ...]. Name the buyer yourself first.
```

Never fill that slot from another line of the entry. `onboarding` in one line and
`client` in another is exactly where the wrong audience gets written in.

## Method

**Step 1, read the header.** Print `title`, `company`, `dates`, `location`, each
either quoted from the paste or `[NEEDS: <the field>]`. Quoted means the whole
header line as it stands, including anything sitting after a bullet character
(`Full-time`, `Hybrid`, `Self-employed`). LinkedIn prints those on the same line
as the field, so they are part of the field. No header field is trimmed and no
header field is trimmed in one place and kept in another. The header is not
rewritten. It is printed so the block can be checked against it.

**Step 2, split the body and class every line.** Split any line carrying two
facts before classing it, never after. Each half is classed on its own row, and
one line can produce two activities, or an activity and a result. The split
points are pinned, so that two runs on the same entry split the same way:

| Where | Split | Why |
|---|---|---|
| `and` joining two verbs that each carry their own object | Yes | Two things you do |
| `and` joining two objects of one verb (`client services and delivery`) | No | One thing you do, done to two things |
| `and` joining two verbs that share one object (`Built and rolled out a new onboarding process`) | No | One thing you do, named twice |
| `and` inside a fixed term (`P and L`, `research and development`) | No | The term is one word with a space in it |
| `that` introducing a change or a figure (`that cut the number of escalations`) | Yes | The clause after it is a result |
| `that` introducing a description (`that goes to every account`) | No | The clause after it describes the object |
| A comma joining two verbs that each carry their own object | Yes | Two things you do |

A split that leaves either half without a verb is not a split point. Test the
halves before you take the split, and where a half fails, class the line whole.

| Class | Test |
|---|---|
| `ACTIVITY` | Could be an entry in next week's diary |
| `RESULT` | A change in a number or a standing, with no work named |
| `NO ACTIVITY` | Describes you, your position on the chart, or a credential |

The five shapes that decide most entries, pinned so two runs class them the same:

| Line shape | Class | Why |
|---|---|---|
| `Responsible for <an area of work>` | `ACTIVITY` | The area names work that gets done |
| `Doubled / grew / increased <a number>` | `RESULT` | Nothing in it could go in a diary |
| `Passionate / trusted / recognised / award-winning` | `NO ACTIVITY` | It describes you |
| `Speaker at / member of / winner of <a thing>` | `NO ACTIVITY` | A credential, not work |
| `Reporting to <a person>` | `NO ACTIVITY` | A position on the chart |

**Step 3, the gate.** Activities at zero, fire Refusal 1 and stop.

**Step 4, rewrite each activity into an offer line.** Five rules, applied in
order:

- **R1** Start with the verb. `Responsible for`, `Leading`, `Tasked with` and
  `Duties included` come off the front, and a leading `I` comes off with them.
  Stripping one of those four phrases can leave the line with no verb at all,
  so what replaces it is pinned rather than chosen. Nothing outside this table
  may be substituted:

  | The line opens with | The rewritten line opens with | Why |
  |---|---|---|
  | `Leading` | `Lead` | The verb was already there, in the wrong tense |
  | `Responsible for` | `Own` | Names the same relation to the same work, adds no fact |
  | `Tasked with` | `Own` | Same |
  | `Duties included` | `Own` | Same |
  | Any verb of your own (`Built`, `Sit`, `run`) | That verb, in the tense the entry wrote it | The entry already started with the verb |

  The first word of the rewritten line takes a capital. No other word changes
  case. A verb that appears nowhere in the line being rewritten, and nowhere in
  the table above, is an invention, including a verb borrowed from another line
  of the same entry.
- **R2** Drop adjectives describing you or your team (`talented`, `dynamic`,
  `world-class`, `high-performing`). They survive nowhere in the block. An
  adjective describing the scope of the work rather than the people doing it
  (`full`, `weekly`, `monthly`, `new`) stays exactly as the entry wrote it. R2
  is not a licence to tighten a line.
- **R3** The line has to contain the entry's own word for who the work is for.
  If that word does not appear in the activity itself, print
  `[NEEDS: who this work is for]` at the end of the line.
- **R4** Keep every number exactly as the entry writes it. Never round it, never
  convert it, never add one.
- **R5** The line stops where the entry stops. Do not append what the work
  achieved. If the entry did not say, the line does not say.

**Step 5, order the lines.** Two groups, each in the order the activities appear
in the entry: first the lines that name who the work is for, then the lines
carrying `[NEEDS: who this work is for]`. That ordering is the whole ranking. It
is deterministic on purpose, so that two runs of this unit on the same entry
produce the same block.

**Step 6, cut to five and print what was cut.** The block is the first five lines
after Step 5. Every activity that did not make it is printed under `left out`,
quoted as Step 2 split it, in the entry's own casing. Nothing leaves this unit
silently.

Two different facts put an activity on that list, and they are printed in two
separate fields, never joined into one string. One is about the line: whether it
named who the work is for, which is what decided where Step 5 ranked it. The
other is about the block: the block holds five, which is true of every cut line
regardless of what the line said.

```
- "<activity>"   where Step 5 ranked it: <named who the work is for | no buyer named in the line>   why it is not in the block: cut by the five-line cap | says the same as line <n>
```

A reader looking at that row can tell whether an activity was cut for what it
lacked or purely for losing a place to the lines ahead of it.

**Step 7, hold the results out, in view.** Every `RESULT` from Step 2 is printed
in its own list, quoted from the entry, under a line saying it was kept out of
the block. It is kept out because this unit cannot see who it happened for, and a
result with no buyer attached to it reads as a claim. Paste them back yourself if
you can name the buyer they happened for.

**Step 8, print the counts.** Population, stated in words: the lines in the body
you pasted, and the activities they produced after splitting.

```
lines in the entry body: <n>
activities found after splitting: <n>
lines in the block: <n>
left out: <n>
results claimed in the entry, held out of the block: <n>
lines carrying no activity: <n>
```

No percentage is printed anywhere in this unit. The obvious one, activities
written over activities found, moves with the five-line cap this unit sets rather
than with anything in your entry, which makes it a measurement of this unit and
not of your profile.

## Output format

```
# Current-role block

## Header, unchanged
title: "<...>"    company: "<...>"    dates: "<...>"    location: "<...>"

## The block
1. <line>
2. <line>
3. <line>
4. <line>
5. <line>

## Left out
- "<activity>"   where Step 5 ranked it: <...>   why it is not in the block: <...>

## Results claimed in the entry, held out of the block
- "<quoted result>"

## Lines carrying no activity
- "<quoted line>"   <class>

## Counts
<the counts from Step 8>
```

## Worked case

This worked case is a literal run of `fixtures/current-role-entry.md`, checked
line by line against the steps above. It is the same input, not a similar one.

```
# Current-role block

## Header, unchanged
title: "Director of Client Services"          company: "Bramwell and Co  ·  Full-time"
dates: "Mar 2021 to Present"                  location: "Leeds, United Kingdom  ·  Hybrid"

## The block
1. Lead a team of 12 across client services and delivery.
2. Own the full client lifecycle from onboarding through to renewal.
3. Run the weekly account review.
4. Write the monthly client note that goes to every account.
5. Built and rolled out a new onboarding process. [NEEDS: who this work is for]

DO NOT PASTE LINES CARRYING [NEEDS: ...]. Name the buyer yourself first.

## Left out
- "Sit on the leadership team"   where Step 5 ranked it: no buyer named in the line   why it is not in the block: cut by the five-line cap
- "own the services P and L"   where Step 5 ranked it: no buyer named in the line   why it is not in the block: cut by the five-line cap

## Results claimed in the entry, held out of the block
- "cut the number of escalations in the first month"

## Lines carrying no activity
- "Passionate about service excellence and long-term partnerships."   describes you
- "Speaker at two industry events."                                   credential
- "Reporting to the Managing Director."                               position on the chart

## Counts
lines in the entry body: 8
activities found after splitting: 7
lines in the block: 5
left out: 2
results claimed in the entry, held out of the block: 1
lines carrying no activity: 3
```

Three body lines met a candidate split point and only two were split. `I run the
weekly account review and write the monthly client note that goes to every
account` split at the `and`, because `run` and `write` each carry their own
object, and did not split at the `that`, because `goes to every account`
describes the note rather than reporting a change. `Sit on the leadership team
and own the services P and L` split at the first `and` and not at the one inside
`P and L`. `Built and rolled out a new onboarding process that cut the number of
escalations in the first month` did not split at its `and`, because `Built` and
`rolled out` share the one object, and did split at its `that`, which is why the
same line appears in the block and in the held-out list carrying a different half
of itself each time.

Block line 1 opens `Lead` because R1's table turns `Leading` into `Lead`, and for
no other reason: `Run` belongs to line 4 of the entry and borrowing it here would
put a verb in the line that the entry never wrote there. Block line 2 keeps
`full`, which describes the scope of the lifecycle and not the person running it.
The header prints `Bramwell and Co  ·  Full-time` whole, on the same rule that
keeps `·  Hybrid` on the location.

## Edge cases

**The beneficiary is named in a different line of the same entry.** The bracket
stays. Fill it yourself. This unit does not carry a word across lines.

**The entry is for a role at your own company.** Class and rewrite it exactly the
same way. Founder entries are the commonest place Refusal 1 fires, because the
body is usually empty.

**A line names tools rather than an activity** (a list of software names).
Class it `NO ACTIVITY` and print it in that list. A tool is a thing you have, and
the block is what you do.

**The entry body is longer than twenty lines.** Class all of them, print all the
counts, and still cut the block to five. Print the full left-out list rather than
a summary of it. The reader is choosing from that list, so it has to be complete.

**Two activities say the same thing in different words.** Print both in Step 2,
put the earlier one in the block, and print the later one under `left out` with
the reason `says the same as line <n>`. Do not merge them into a new line neither
one said.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write an activity the entry did not state. This is the failure this unit
  exists to prevent, and a plausible duty for the title is still an invention.
- Never add a number, a percentage, a headcount, a budget, a client name or a
  date the entry did not carry.
- Never append what the work achieved to a line that did not carry it.
- Never move a result into the block.
- Never delete a line silently. Left out, held out, or in the block, with a
  reason on every one.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
