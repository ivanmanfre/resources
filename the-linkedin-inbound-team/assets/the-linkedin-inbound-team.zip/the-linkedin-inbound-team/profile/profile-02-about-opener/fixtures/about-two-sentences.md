# Fixture, an About section that was never filled in

Invented person. Exercises the sentence-count gate.

---

Founder at Pellamont Group. Open to interesting conversations.
