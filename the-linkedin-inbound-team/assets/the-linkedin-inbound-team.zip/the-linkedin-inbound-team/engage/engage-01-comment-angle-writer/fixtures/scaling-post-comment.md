# Fixture, a post to comment on

Invented for testing. Not a real post and not a record of any real person or
company.

Note: exercises the standard match path - one clear subject line in the post
for the first-hand fact to answer.

---

Posted by Delphine Rourke, COO at an invented logistics startup, Northbend
Freight.

We doubled headcount in Q2 and support tickets went up 40%, not down like I
expected.

I thought more people on the floor would mean faster answers. Instead the
first three weeks were slower, because everyone new was asking the people who
already knew things.

By week five it flipped. New hires stopped asking and started answering, and
the backlog cleared faster than it built.

The lesson I keep relearning: headcount is a cost before it is capacity, and
the gap between the two is measured in weeks, not days.

---

Your first-hand fact: "Same pattern here at 12 people: we added two support
hires in one month and first-response time got worse for three weeks before
it improved. The ramp cost showed up in speed, not ticket count."
