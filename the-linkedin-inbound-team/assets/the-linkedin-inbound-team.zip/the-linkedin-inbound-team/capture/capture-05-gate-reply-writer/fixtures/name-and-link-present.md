# Fixture, a full delivery input

Invented for testing. Not a real product or a real person.

---

## Magnet name
The Pre-Quote Vetting Checklist

## Link
https://priya.co/checklist

## Commenter's first name
Grace
