# Fixture, no link exists yet

Invented for testing. Exercises the no-link refusal.

---

## Magnet name
The Pre-Quote Vetting Checklist

## Link
(not made yet, still finishing the PDF)

## Commenter's first name
Tomasz
