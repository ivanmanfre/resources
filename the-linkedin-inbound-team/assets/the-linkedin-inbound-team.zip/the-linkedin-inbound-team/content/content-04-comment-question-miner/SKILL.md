---
name: content-04-comment-question-miner
description: "Use when you need the next post topic and would rather take it from what people already asked you. Takes the comment threads under your own posts, pasted as text, and returns the topics ranked by how many times the question appeared, with the commenters' words quoted. Triggers on \"what should I post about next\", \"mine my comments for topics\", \"what do people keep asking me\", \"pull post ideas from these threads\", \"which question comes up most\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 04 of 06: the comment question miner

## What this does

Reads the comment threads under posts you have already published, separates the
questions from everything else, and groups the questions into topics by what
they are asking about and what they are asking to be done with it.

**The line only this unit produces:** a topic label written as
`<object> + <operation>`, with the number of times it was asked and the number
of separate people who asked it printed side by side.

Both numbers are printed because they say different things. One person asking
twice is one person. The unit never collapses them into a single demand figure.

## Required input

1. **The comment threads**, pasted as text, from one or more of your own posts.
   Keep the commenter names and headlines as the screen shows them, keep your
   own replies in the paste, and mark where each post's thread starts.
2. **Your own name exactly as it appears on your comments.** Without it, your
   replies get counted as reader demand, which inverts the whole output.

Nothing else. No reaction counts, no impressions, no follower data. This unit
reads words people typed.

## What it refuses

**Refusal 1, nobody asked anything.** If no reader row classes as a question,
print this and rank nothing:

```
NO QUESTION FROM ANYBODY BUT YOU
Comments pasted: <n>   Your own rows: <n>   Reader rows: <n>
Reader questions: 0   Statements: <n>   Praise: <n>

There is no demand in this paste to rank. The one question in it is yours.

Ranking anything now would mean inventing a topic from praise, and a post
written to answer a question nobody asked reads exactly like one.
```

**Refusal 2, your name is missing.** Stop before classing anything:

```
[NEEDS: your name exactly as it appears on your own comments]
Without it your replies count as somebody else's demand and the ranking inverts.
```

**Refusal 3, ranking by anything except the count.** If asked which topic will
perform best, print this and stop:

```
NOTHING HERE MEASURES PERFORMANCE
This unit counts questions. It holds no reaction, view or follower data, and a
ranking by predicted performance would be a guess wearing a number.
```

## Method

**Step 1, the name gate.** Confirm your name is supplied. If not, Refusal 2.

**Step 2, split into rows.** One comment can carry several things. Split before
classing, and print the split:

- a comment with two questions becomes `C<n>a` and `C<n>b`
- a comment with a question and a statement becomes two rows
- a reply nested under a comment is its own row, with `reply to C<n>` printed

Print comments pasted and rows after splitting as two separate numbers. Every
count below is over rows.

**Step 3, mark your own rows.** Any row whose name matches the name you supplied
is `AUTHOR` and is printed, then excluded from everything after this step. Print
the excluded count. A question inside your own reply is still `AUTHOR`.

**Step 4, class every reader row.** Three classes, every row printed:

| Class | What it is |
|---|---|
| `QUESTION` | ends in a question mark, or asks for a thing ("would you share", "can you show", "send it over"), or states a wish to know ("I would love to know how you pick") |
| `STATEMENT` | says something without asking for anything |
| `PRAISE` | approval with no content: "love this", "great post", "saving this" |

**Step 5, name the topic of every question row.** The label is
`<object> + <operation>`, and both halves use the commenter's own nouns and
verbs. The object is the thing they are asking about. The operation is what they
want done with it or told about it.

If the commenter's words do not name an object, print
`[NEEDS: what <name> was asking about, in their words]` and leave the row
unranked. Never supply the object yourself from context.

**Step 6, group.** Two question rows share a topic only when they share the
object **and** the operation. Sharing one of the two is not enough:

- same object, different operation: two topics, printed separately
- same operation, different object: two topics, and each one prints
  `SAME OPERATION AS: <the other topic>` so you can merge them by hand if you
  decide they are one post

The unit never merges on your behalf. A merge you did not make is how a topic
count gets inflated.

**Step 7, count, two ways.** For every topic print:

```
asked <n> times by <n> people
```

Times counts question rows. People counts distinct names. Where the same person
asks the same topic twice **in the same thread**, the second row prints
`repeat by same person, counted once` and does not add to either figure. Across
two different threads it counts, and the people figure is what stops it reading
as two people.

**Step 8, rank and account.** Rank by times, then by earliest appearance in the
paste. Then print the accounting line:

```
question rows accounted for: <n> of <n>
```

The two numbers must match. If they do not, a question row was dropped or
counted twice, and the run is wrong. Print unranked rows underneath with their
`[NEEDS:]` note so the shortfall is visible rather than silent.

**Step 9, quote.** Under every topic, print each question verbatim with the
commenter's name and which post it came from. The quote is the artifact. A topic
label with no quote under it is this unit's own words wearing a reader's demand.

## Output format

```
# Topics already asked, from <n> of your posts

## Rows
C<n>a  QUESTION   <name>, <headline> (post <n>)
       "<verbatim>"
C<n>b  STATEMENT  <name>, <headline> (post <n>)
       "<verbatim>"
C<n>   AUTHOR     <your name> (post <n>)   excluded
...

comments pasted: <n>   rows after splitting: <n>
your own rows, excluded: <n>
reader rows: <n>   QUESTION: <n>   STATEMENT: <n>   PRAISE: <n>

## Topics, ranked
1. <object> + <operation>
   asked <n> times by <n> people
   > "<verbatim>"   <name>, post <n>
   > "<verbatim>"   <name>, post <n>
2. ...
   SAME OPERATION AS: <topic n>

question rows accounted for: <n> of <n>

## Unranked
C<n>  [NEEDS: what <name> was asking about, in their words]
```

## Worked case

This is the fixture run. It is `fixtures/threads-two-posts.md`, executed line by
line against the rules above.

```
## Rows
C1a  QUESTION   Tomas Berg, Founder at Kestrel Fit Studios (post 1)
     "Do you keep the file in one place or per client?"
C1b  STATEMENT  Tomas Berg, Founder at Kestrel Fit Studios (post 1)
     "Ours is scattered across three tools and I cannot find anything."
C2   AUTHOR     Dana Okoro (post 1)   excluded
C3a  QUESTION   Ines Vall, Head of New Business at Marlowe and Fenn (post 1)
     "How do you decide what makes it into the file?"
C3b  QUESTION   Ines Vall, Head of New Business at Marlowe and Fenn (post 1)
     "And do you ever take things out?"
C4   PRAISE     Ruth Alderman, Operations Lead at Halden Group (post 1)
     "Love this."
C5   QUESTION   Kwame Osei, Founder at Osei Digital (post 1)
     "What do you do when the same question comes from a client rather than a prospect?"
C6a  QUESTION   Tomas Berg, Founder at Kestrel Fit Studios (post 2)
     "Do you keep the note in one place or does each client get their own?"
C6b  STATEMENT  Tomas Berg, Founder at Kestrel Fit Studios (post 2)
     "Same question as last time, sorry."
C7   QUESTION   Ines Vall, Head of New Business at Marlowe and Fenn (post 2)
     "Would you share the four lines you use?"
C8   AUTHOR     Dana Okoro (post 2)   excluded
C9   STATEMENT  Nils Ostberg, Managing Partner at Ostberg and Co (post 2)
     "This is the second time I have seen this idea this week."
C10  QUESTION   Ruth Alderman, Operations Lead at Halden Group (post 2)
     "Can you show what the note looks like when there is nothing to report?"
C11a QUESTION   Marta Vine, Founder at Vine Studio (post 2)
     "Do you keep one file for everything or one per client?"
C11b STATEMENT  Marta Vine, Founder at Vine Studio (post 2)
     "Mine is one per client and it is a mess."

comments pasted: 11   rows after splitting: 15
your own rows, excluded: 2
reader rows: 13   QUESTION: 8   STATEMENT: 4   PRAISE: 1

## Topics, ranked
1. the file + one place or one per client
   asked 2 times by 2 people
   > "Do you keep the file in one place or per client?"   Tomas Berg, post 1
   > "Do you keep one file for everything or one per client?"   Marta Vine, post 2

2. the file + what goes into it
   asked 1 time by 1 person
   > "How do you decide what makes it into the file?"   Ines Vall, post 1

3. the file + taking things back out
   asked 1 time by 1 person
   > "And do you ever take things out?"   Ines Vall, post 1

4. a question from a client + handling it differently from a prospect
   asked 1 time by 1 person
   > "What do you do when the same question comes from a client rather than a prospect?"   Kwame Osei, post 1

5. the note + one place or one per client
   asked 1 time by 1 person
   > "Do you keep the note in one place or does each client get their own?"   Tomas Berg, post 2
   SAME OPERATION AS: topic 1

6. the four lines + showing them
   asked 1 time by 1 person
   > "Would you share the four lines you use?"   Ines Vall, post 2

7. the note + what it says on a week with nothing to report
   asked 1 time by 1 person
   > "Can you show what the note looks like when there is nothing to report?"   Ruth Alderman, post 2

question rows accounted for: 8 of 8

## Unranked
none
```

Topic 1 and topic 5 stay separate because the object differs, the file against
the note, and the cross-reference is printed under topic 5 for you to decide.
The second fixture, `fixtures/threads-no-questions.md`, fires Refusal 1 at
`Comments pasted: 5   Your own rows: 1   Reader rows: 4` and
`Reader questions: 0   Statements: 2   Praise: 2`, with the only question in the
paste marked `AUTHOR` and excluded.

## Edge cases

**A commenter tags somebody instead of asking.** Class it `STATEMENT`. A tag is
an invitation to a third party, and it is not demand for a topic.

**A question asked inside praise.** Split it. The praise half is `PRAISE`, the
question half is `QUESTION`, and both rows print.

**A question you already answered in the thread.** It still counts. The question
was asked in public, which means other readers had it too, and your answer sat
in a comment where almost nobody read it.

**A question addressed to another commenter, not to you.** Print it with
`ASKED OF <name>, not of you` and leave it out of the ranking. It is demand, and
it is not demand on you.

**The same person asks the same thing twice in one thread.** The second row
prints `repeat by same person, counted once` and adds nothing to either figure.

**A question whose object is a pronoun.** Resolve it from the post title only if
the title names the object. Otherwise print
`[NEEDS: what <name> meant by "<pronoun>"]` and leave the row unranked.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write the post. This unit returns topics and quotes.
- Never invent a commenter, a headline, a question or a count.
- Never merge two topics that share only the object or only the operation.
  Print the cross-reference and leave the merge to the reader.
- Never print one demand figure. Times and people are always printed together.
- Never rank on anything except times, then earliest appearance.
- Never treat your own rows as demand.
- Never infer what a commenter meant beyond the nouns they typed.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
