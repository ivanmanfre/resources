# Fixture, an offer sentence with nobody in it

Invented for testing. No real people, no real companies, no record of any
engagement.

What this input is designed to exercise: an offer sentence that names the work
and never names who it is for.

---

My offer sentence:
I make the invisible parts of the work visible.

How I ask for a reply, in words I already use:
send me a message

My draft:
An agency I sat with last Tuesday handed a new hire an eleven-page onboarding pack.
She read two pages and asked the person next to her if there was a shorter version.
There was one, in a Slack thread from March.
We spent the afternoon turning the Slack thread into a one-page card.
