# Fixture, a pitch-shaped opener that turns out to be a buyer question

Invented for testing. Not a real thread and not a record of any real person.
Exercises Refusal 1, the message is not actually a pitch.

Person: Halina Brookes

---

M1 THEM: "Loved your last post on onboarding. I've been trying to fix ours
for months and nothing sticks, do you take on projects like this or is your
calendar full."
