---
name: capture-05-gate-reply-writer
description: "Use when someone comments your gate keyword and you need the message that hands the asset over without turning it into a pitch. Takes the magnet name, its link, and the commenter's first name and returns the delivery message, nothing else attached. Triggers on \"write the reply for someone who commented my keyword\", \"what do I send when someone comments CHECKLIST\", \"draft the delivery DM\", \"send them the file without pitching\", \"what's my gate reply message\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 05 of 06: the gate reply writer

## What this does

Writes the one message that goes back to someone who commented the gate
keyword: their name, the asset, the link, and nothing else. No question, no
upsell, no second ask riding along with the delivery.

**The line only this unit produces:** the delivery message that hands over
the asset and asks nothing.

## Required input

1. **The magnet name**, exactly as titled.
2. **The link**, the actual URL or file location the reader will send.
3. **The commenter's first name**, as it appears on their comment or profile.

## What it refuses

**Refusal, there is nothing to deliver.** If no link exists yet, stop:

```
NO LINK TO DELIVER
The asset is not ready to send. A delivery message with no link attached is a
promise, not a delivery, and it puts the reader in the position of owing
someone a file that does not exist yet.

[NEEDS: the finished link or file location]
```

## Method

**Step 1, check the link.** If it is missing, unfinished, or described as
still in progress, the refusal fires and no message is written.

**Step 2, check the name.** If no first name was captured, the greeting slot
prints the gap notation instead of a name; see Output format. This is not a
refusal, since the asset can still be sent, only the greeting is missing a
word.

**Step 3, write the message.** Exactly three parts, in this order, and
nothing added to them:

1. a greeting using the first name (or the gap notation)
2. the magnet name and the link, handed over plainly
3. one closing line stating that is everything, with no question attached

**Step 4, check the message carries no ask.** Read the drafted message back
and confirm it contains no question mark and no second request of any kind
(no "let me know what you think", no "would love your feedback", no mention
of a call). If one crept in while drafting, cut it before shipping.

## Output format

```
# Delivery message

"<greeting>, here's <magnet name>: <link>. <closing line stating that's
everything>."

## Check
question marks in message: 0
second ask present: no
```

## Worked case

This is the fixture run. It is `fixtures/name-and-link-present.md`, executed
line by line against the rules above.

```
## Check
link present: yes
name present: yes

# Delivery message

"Hey Grace, here's the Pre-Quote Vetting Checklist: https://priya.co/checklist.
That's everything, no follow-up needed from you."

## Check
question marks in message: 0
second ask present: no
```

The second fixture, `fixtures/no-link-yet.md`, fires the refusal. Its Step 1
check reads `link present: no`, and `NO LINK TO DELIVER` is printed with no
message drafted.

The third fixture, `fixtures/no-first-name.md`, exercises the gap notation
without a refusal, since the link is present:

```
# Delivery message

"Hey [NEEDS: the commenter's first name], here's the Pre-Quote Vetting
Checklist: https://priya.co/checklist. That's everything, no follow-up
needed from you."

## Check
question marks in message: 0
second ask present: no
```

## Edge cases

**The commenter's name is a handle, not a first name** ("@growthwithkai").
Treat it the same as a missing name: print the gap notation rather than
greeting someone by their handle.

**The reader wants to add a line pointing to their newsletter or another
offer.** That line is cut. This unit hands over exactly what was asked for and
nothing else; a second ask riding on the delivery is the thing that makes the
gate feel like a funnel instead of a handoff.

**The link is a file attachment, not a URL.** Write `[the PDF attached to this
message]` in place of a URL and note it in the message the same way.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a delivery message with no link behind it.
- Never add a question, a call ask, or a second offer to this message.
- Never guess at a first name from a handle or a company name.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
