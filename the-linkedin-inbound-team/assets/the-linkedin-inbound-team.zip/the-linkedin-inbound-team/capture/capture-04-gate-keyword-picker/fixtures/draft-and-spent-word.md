# Fixture, a draft where the natural keyword is already spent

Invented for testing. Exercises the spent-keyword refusal.

---

## The post draft, as written

I built a one-page vetting checklist after losing a project to scope creep
last spring. Ten questions to ask before you quote a new client so you are
not the one holding the bag two months in.

## Keywords the reader has used before

CHECKLIST, TEMPLATE
