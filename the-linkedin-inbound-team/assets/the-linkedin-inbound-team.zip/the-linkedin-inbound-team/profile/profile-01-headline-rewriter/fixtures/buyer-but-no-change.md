# Fixture, a one-clause offer sentence

Invented person, invented company. Exercises the open-slot path on a one-clause
offer sentence.

---

## Current headline, copied exactly

Head of Delivery at Pellamont Group

## Offer sentence

I work with clinic owners.

## Words my buyers use for themselves

(not supplied)
