# Fixture, link exists but no first name was captured

Invented for testing. Exercises the [NEEDS] gap on the greeting, as distinct
from the no-link refusal.

---

## Magnet name
The Pre-Quote Vetting Checklist

## Link
https://priya.co/checklist

## Commenter's first name
(comment came from a page with no visible name, just a handle)
