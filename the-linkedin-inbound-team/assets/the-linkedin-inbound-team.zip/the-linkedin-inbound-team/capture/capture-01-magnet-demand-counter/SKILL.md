---
name: capture-01-magnet-demand-counter
description: "Use before you build a lead magnet, to find out what people have already asked you for instead of guessing. Takes the DM threads you already have and returns the magnet concept people asked for most, with every ask counted and quoted. Triggers on \"what lead magnet should I make\", \"have people actually asked me for anything\", \"count what my DMs are asking for\", \"what should my next freebie be\", \"is there real demand for this\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 01 of 06: the magnet demand counter

## What this does

Reads the DM threads you paste, finds every place someone asked you for
something, and groups those asks by what they actually named, so the magnet
you build is the one with a printed count of people who already asked for it.

**The line only this unit produces:** the magnet concept with the count of
times it was already asked for, ask by ask.

This is not an idea generator. If nobody asked for anything, it says so and
proposes nothing.

## Required input

1. **DM threads**, pasted as text, one or more, with something marking where
   one thread ends and the next begins (a name, a header, a blank line and a
   new name; any marker the reader already uses is fine).
2. Nothing else. No follower counts, no post analytics, and nothing exported
   out of another tool.

## What it refuses

**Refusal 1, nothing was asked for.** If zero requests are found across every
thread supplied, stop:

```
NO REQUEST FOUND
DM threads pasted: <n>
threads carrying at least one request: 0 / <n> = 0.0

Nobody in these threads asked you for anything. A magnet built now would be a
guess wearing a count. [NEEDS: a DM thread where someone asks you for
something, in their own words]
```

**Refusal 2, the ask has no nameable thing.** A request that names nothing
concrete does not get folded into a concept. It is printed on its own row as
`UNSPECIFIED` with `[NEEDS: their own words naming what they want]`, and it
counts toward the request population but never toward any concept's count.

## Method

**Step 1, split into threads.** Use the reader's own markers to divide the
paste into threads. Print how many threads were found.

**Step 2, per-instance split before classing.** Walk every thread and pull out
every message from the other person, in order. If one thread carries more than
one distinct ask, split it into separate ask-rows before classing anything.
One thread carrying two asks produces two rows, not one.

**Step 3, class each message as REQUEST or not.** `REQUEST` is a message that
asks the reader for something, directly ("do you have", "is there", "can you
send") or as a stated want ("I could use", "I wish I had"). A compliment, a
thank-you, or small talk is not a request and produces no row.

**Step 4, the thread-level gate, population stated.** The population is DM
threads pasted, counted once each. A thread counts as carrying a request if
any of its messages classed REQUEST in Step 3. Every thread lands on one side or
the other, and both sides are printed, so the two rows add back to the threads
you pasted:

```
population: DM threads pasted, counted once each
threads carrying at least one request: <n> / <n> = <decimal>
threads carrying none: <n>   <the thread labels> | none
```

If the numerator is 0, Refusal 1 fires and no further step runs.

**Step 5, name the concept per ask.** Step 6 groups asks by matching their
remainders as text, so the stripping has to land on the same text every time it
is run. It is a fixed recipe in a fixed order, not a tidy-up, and what came off
is printed beside what stayed.

**5a, find the ask sentence.** The ask sentence starts at the first framing
opener in the message and ends at the first question mark after it, or at the
first full stop after it where the person wrote no question mark. Everything
before the opener is a lead-in (`hey, saw your post about the client screening
thing.`, `quick one,`, `also, separate thing,`) and everything after the closing
mark is context (`trying to fix my intake process`, `mine is all over the
place`). Neither one is part of the ask. The ask sentence, and nothing else, is
what the `quote:` field prints.

**5b, strip the opener.** The openers, and only these: `do you have`,
`is there`, `have you got`, `got`, `can you send`, `could you send`,
`could you share`, `would you share`, `I could use`, `I wish I had`,
`any chance you have`. The opener comes off the front, and an article or
quantifier directly behind it (`a`, `an`, `the`, `any`) comes off with it.

**5c, strip the closer.** The closers, and only these: `anywhere`,
`by any chance`, `you use`, `you have`, `you'd be willing to share`,
`you would be willing to share`, `if you have one`, `if you have it`. Anything
matching comes off the end, along with a trailing comma or full stop.

**5d, the concrete-thing test.** What is left names a concrete thing when it
carries a noun that could go on the front of a file: a checklist, a template, a
script, a calculator, a swipe file, a guide. Where every noun left is a
placeholder (`anything`, `something`, `stuff`, `thing`, `things`, `it`, `that`),
the row is `UNSPECIFIED` (Refusal 2). Otherwise the remainder is the ask's
concept phrase.

Nothing outside 5b and 5c comes off. A word that survives the recipe stays, even
where it reads awkwardly, because the alternative is two runs of this unit
producing two different concept phrases from the same message.

**Step 6, group by identical concept phrase.** Two asks group under the same
concept only when their Step 5 remainders match as text, character for
character. Anything else is a separate row. Never group on a guess about what
someone probably meant.

**Step 7, count and rank.** For every concept, print how many asks it has and
quote each one with the thread it came from. The concept with the highest
count is the one the magnet gets built from. Ties are broken by which concept
was asked about in more distinct threads; if that also ties, print both and
say so rather than picking one.

## Output format

```
# Magnet demand count

## Threads read
<n> threads, split at the reader's own markers

## Requests found
population: DM threads pasted, counted once each
threads carrying at least one request: <n> / <n> = <decimal>
threads carrying none: <n>   <labels> | none

## Ask-level rows
1. thread: <thread label>   concept: "<phrase>" | UNSPECIFIED
   quote: "<the ask sentence, verbatim>"
   stripped: front: "<text>" | none   end: "<text>" | none
2. ...

## Concepts, ranked by count
- "<concept>": asked <n> time(s)
  - thread: <label>   quote: "<verbatim>"
  - thread: <label>   quote: "<verbatim>"
- "<concept>": asked <n> time(s)
  - thread: <label>   quote: "<verbatim>"
- UNSPECIFIED: <n>   [NEEDS: their own words naming what they want]   (not ranked)

## The magnet this points to
concept: "<winning concept>"   asked: <n> time(s) across <n> thread(s)
```

## Worked case

This is the fixture run. It is `fixtures/dm-threads-with-asks.md`, executed
line by line against the rules above.

```
## Threads read
4 threads, split at the "### Thread N, with <name>" headers

## Requests found
population: DM threads pasted, counted once each
threads carrying at least one request: 3 / 4 = 0.75
threads carrying none: 1   Thread 2, Farah K.

## Ask-level rows
1. thread: Thread 1, Denny R.   concept: "checklist for client onboarding"
   quote: "do you have a checklist for client onboarding you'd be willing to share?"
   stripped: front: "do you have a"   end: "you'd be willing to share"
2. thread: Thread 3, Owen T.    concept: "checklist for client onboarding"
   quote: "is there a checklist for client onboarding anywhere?"
   stripped: front: "is there a"   end: "anywhere"
3. thread: Thread 3, Owen T.    concept: "rate card template"
   quote: "do you have a rate card template you use?"
   stripped: front: "do you have a"   end: "you use"
4. thread: Thread 4, Bianca S.  concept: UNSPECIFIED
   quote: "got anything I could use for this kind of thing?"
   stripped: front: "got"   end: none

## Concepts, ranked by count
- "checklist for client onboarding": asked 2 times
  - thread: Thread 1, Denny R.   quote: "do you have a checklist for client onboarding you'd be willing to share?"
  - thread: Thread 3, Owen T.    quote: "is there a checklist for client onboarding anywhere?"
- "rate card template": asked 1 time
  - thread: Thread 3, Owen T.    quote: "do you have a rate card template you use?"
- UNSPECIFIED: 1   [NEEDS: their own words naming what they want]   (not ranked)

## The magnet this points to
concept: "checklist for client onboarding"   asked: 2 time(s) across 2 thread(s)
```

Row 4 is the one to read closely. `got` is an opener, so it comes off, and
nothing behind it is an article, so nothing else comes off with it. Neither
closer in 5c appears at the end, so `end` prints `none`. What is left,
`anything I could use for this kind of thing`, carries `anything` and `thing`
and no noun that could go on the front of a file, so 5d sends the row to
`UNSPECIFIED` rather than to a concept. Rows 1 and 2 group because their
remainders match character for character after the recipe ran, not because they
sound alike.

The second fixture, `fixtures/dm-threads-no-asks.md`, fires Refusal 1. Its
Step 4 line reads `threads carrying at least one request: 0 / 2 = 0.0`, and no
concept rows are printed.

## Edge cases

**The same person asks twice in two different threads.** Both asks count.
This unit counts asks, not people; a second fixture built later that needs
unique-people counting is a different unit.

**Two people phrase the same ask differently enough that Step 5's stripped
remainder does not match.** They stay as separate concept rows. A builder who
merges them on judgment is the exact fabrication this unit exists to block.

**A thread has a request buried after ten off-topic messages.** It still
counts. Read every message in the thread, not only the first or last.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent, merge, or round a count. A concept's count is exactly how many
  ask-rows named it after Step 5's stripping, no more.
- Never propose a magnet concept nobody asked for, even as a runner-up.
- Never derive a follower count, a market size, or a demand estimate from
  anything other than the pasted threads.
- Never rank concepts with equal counts against each other; print both.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
