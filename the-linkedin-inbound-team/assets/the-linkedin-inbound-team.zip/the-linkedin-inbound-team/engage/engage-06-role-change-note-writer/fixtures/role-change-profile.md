# Fixture, a connection's profile showing a role change

Invented for testing. Not a real person or company.

Note: exercises a NEW COMPANY seat change with a clean end date on the
earlier entry.

---

## Experience, most recent two entries

**Current**
Title: Director of Client Operations
Company: Harrow & Vance
Dates: Jul 2026 – Present

**Previous**
Title: Senior Client Operations Manager
Company: Fennimore Health
Dates: Feb 2023 – Jun 2026
