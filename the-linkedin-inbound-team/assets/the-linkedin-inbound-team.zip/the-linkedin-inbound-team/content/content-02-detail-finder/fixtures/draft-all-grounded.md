# Fixture, a draft whose claim is already carried by the account

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: a claim sitting beside a first-hand
sentence that names the same thing and shows the same happening.

---

A four-line note gets read. I know that because of what happened with two
clients in the same fortnight. In February I sent Halden Group a six-page
monthly report and nobody replied to it. In March I sent the same account a
four-line note on a Friday and their operations lead replied to the note within
the hour asking for the invoice. I have sent it every Friday since, four lines
each time.
