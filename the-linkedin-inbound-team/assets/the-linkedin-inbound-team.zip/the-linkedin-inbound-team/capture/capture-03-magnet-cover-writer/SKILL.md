---
name: capture-03-magnet-cover-writer
description: "Use when you need the cover card copy for a lead magnet image, and you want the item count on it to actually match what is inside. Takes the chosen title plus the contents list of the asset and returns the cover lines with the true, backed count. Triggers on \"write my lead magnet cover\", \"what goes on the cover card\", \"does my title's number match the contents\", \"check my magnet count before I post it\", \"write the cover copy for this checklist\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 03 of 06: the magnet cover writer

## What this does

Reads the chosen title and the contents list of the asset, counts the
contents list, and writes the cover card lines with the count the list can
actually back, never the count the title happens to claim.

**The line only this unit produces:** the cover card lines with the item
count that the contents list can actually back.

**The rule this unit exists to enforce:** a cover can never claim more items
than the contents list carries. If the title's number is higher than the
list, the cover prints the true, lower number and says why. This is not a
style preference; it is the one thing this unit refuses to do regardless of
what the title says.

## Required input

1. **The chosen title**, exactly as written. May or may not contain a number.
2. **The contents list of the asset**, one item per line, in the form the
   reader would actually paste it.

## What it refuses

**Refusal 1, nothing to write a cover for.** If the contents list carries zero
items, stop:

```
NO CONTENTS TO COVER
contents list carries: 0

A cover card claims what is inside the asset. There is nothing here to claim
yet. [NEEDS: at least one finished content item, one per line]
```

**Refusal 2, never pad the count.** If the title states a count higher than
the contents list carries, the cover is still written, but it never carries
the title's number. Print, and use, the true count:

```
COUNT REQUESTED EXCEEDS THE CONTENTS LIST
title claims: <requested> <item-type>
contents list carries: <actual> <item-type>

The cover prints <actual>, not <requested>. <requested> is what the title
says and it is wrong for this list; the title needs fixing separately, this
unit does not rewrite it.
```

This is the pack's count rule, applied here as a refusal: the honest count
never gets padded up to match a bigger-sounding title, on this unit or any
other in this pack.

## Method

**Step 1, count the contents list.** The population is lines in the pasted
contents list that name one distinct item; blank lines and section headers
are excluded from the count. Print:

```
population: lines in the contents list naming one distinct item
contents list carries: <n>
```

If the count is 0, Refusal 1 fires and no further step runs.

**Step 2, read the requested count from the title.** Look for a number in the
title immediately attached to a noun describing the item type ("20-Prompt",
"10 Templates", "5-Template"). If found, that is the requested count and that
noun is the item type. If the title carries no such number, there is no
requested count and no item type from the title, Step 3 has nothing to compare,
and the run goes straight to Step 4 with the actual count and the word `items`.

**How the item type is written.** One rule, and it holds in every slot that
prints the item type, not only on the eyebrow: the noun goes in lower case, in
the form that matches the number standing beside it. `20-Prompt` beside a count
of 20 prints `20 prompts`; the same noun beside a count of 1 prints `1 prompt`.
The eyebrow line takes a capital on its first character, because it opens a
line; nothing else changes case. Where the title named no item type, the word is
`items`, written the same way.

**Step 3, compare.** Four branches, printed in words. Every run lands on exactly
one of them:

- `requested == actual`: the title's number matches. No note needed beyond
  the confirmation line.
- `requested > actual`: Refusal 2 fires. The cover uses `actual`.
- `requested < actual`: the title undercounts. Not padding, so no refusal,
  but print `TITLE UNDERCOUNTS: title says <requested>, list carries <actual>;
  cover prints <actual>` so the reader can see the mismatch and choose whether
  to fix the title.
- no requested count at all, because Step 2 found no number attached to a noun:
  there is nothing to compare and nothing is wrong. The branch still prints, so
  that a reader can tell a title with no claim in it from a title whose claim
  was checked.

**Step 4, write the cover lines.** Three lines, all built only from the title
as given and the true count from Step 1:

- eyebrow: `<item type> inside: <n>`
- headline: the title exactly as supplied, never edited by this unit
- count line: `<n> <item type>`

**Step 5, print the padding check.** One line, always present, naming which of
the four Step 3 branches fired. The four values are the whole vocabulary, and
nothing outside them is ever printed on this line:

```
padding check: MATCH | OVER-CLAIM, padding refused | UNDER-CLAIM, title low | NO COUNT IN THE TITLE, nothing to compare
```

## Output format

```
# Cover card for "<title>"

## Count
population: lines in the contents list naming one distinct item
contents list carries: <n>

title claims: <n> <item-type> | none stated
padding check: MATCH | OVER-CLAIM, padding refused | UNDER-CLAIM, title low | NO COUNT IN THE TITLE, nothing to compare

## Cover lines
eyebrow: "<line>"
headline: "<title>"
count line: "<n> <item-type>"
```

## Worked case

This is the fixture run. It is `fixtures/title-overclaims-count.md`, executed
line by line against the rules above.

```
## Count
population: lines in the contents list naming one distinct item
contents list carries: 14

title claims: 20 prompts
padding check: OVER-CLAIM, padding refused

COUNT REQUESTED EXCEEDS THE CONTENTS LIST
title claims: 20 prompts
contents list carries: 14 prompts

The cover prints 14, not 20. 20 is what the title says and it is wrong for
this list; the title needs fixing separately, this unit does not rewrite it.

## Cover lines
eyebrow: "Prompts inside: 14"
headline: "The 20-Prompt Starter Pack for Freelance Copywriters"
count line: "14 prompts"
```

The eyebrow reads `Prompts inside: 14` and not `14 prompts inside`, because
Step 4's template puts the item type first and the number after the colon. The
noun is lower case wherever it appears except at the head of the eyebrow, which
is why the same word prints as `Prompts` on one line and `prompts` on the next.

The second fixture, `fixtures/contents-list-empty.md`, fires Refusal 1. Its
Step 1 line reads `contents list carries: 0`, and no cover lines are written.

The third fixture, `fixtures/title-no-number.md`, exercises the fourth Step 3
branch. Executed line by line, it prints:

```
## Count
population: lines in the contents list naming one distinct item
contents list carries: 6

title claims: none stated
padding check: NO COUNT IN THE TITLE, nothing to compare

## Cover lines
eyebrow: "Items inside: 6"
headline: "The Client Onboarding Swipe File"
count line: "6 items"
```

## Edge cases

**The title's number and the list count match exactly.** Print `MATCH` and
proceed with no refusal text at all.

**The contents list has near-duplicate lines** (two prompts that differ only
by one word). Each pasted line still counts as one distinct item; this unit
does not judge whether two items are similar enough to be the same one, since
that is a content-quality call outside a count.

**The title has no number in it at all.** Step 2 finds no requested count and
Step 3 lands on its fourth branch. `title claims:` prints `none stated`,
`padding check:` prints `NO COUNT IN THE TITLE, nothing to compare`, and the
cover still prints the true count from Step 1, since the count line does not
depend on the title carrying one.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never print a count on the cover higher than the contents list carries, for
  any reason, including a title that says otherwise.
- Never edit the title's wording; a mismatched title gets flagged, not
  rewritten, so the reader decides how to fix it.
- Never invent a content item to make a requested count true.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
