# Fixture, a comment request with no first-hand fact

Invented for testing. Not a real post and not a record of any real person or
company.

Note: exercises Refusal 1 - the fact field carries opinion, not a first-hand
event, number, or outcome.

---

Posted by Amadou Sissoko, Founder at an invented studio, Ferrous Design Co.

We switched our whole onboarding flow to async video walkthroughs this month
and I think it's already better than live calls.

---

Your first-hand fact: "I agree, this is such a smart move."
