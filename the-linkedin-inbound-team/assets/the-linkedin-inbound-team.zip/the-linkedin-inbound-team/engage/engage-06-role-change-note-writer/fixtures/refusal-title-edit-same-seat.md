# Fixture, a title edit inside the same seat

Invented for testing.

Note: exercises Refusal 1 - the only difference between the two entries is
a seniority word, same company, same function.

---

## Experience, most recent two entries

**Current**
Title: Senior Client Operations Manager
Company: Fennimore Health
Dates: Jan 2026 – Present

**Previous**
Title: Client Operations Manager
Company: Fennimore Health
Dates: Feb 2023 – Dec 2025
