---
name: engage-04-repeat-engager-tracker
description: "Use after you've posted a few times, to find the people who keep showing up in your comments. Takes the commenter lists from two or more of your own posts and returns the repeat-engager roster with each name's appearance count across the posts supplied. Triggers on \"who keeps commenting on my posts\", \"find my repeat commenters\", \"who's engaging with me consistently\", \"track repeat engagers\", \"who shows up on all my posts\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 04 of 30: the repeat engager tracker

## What this does

Reads the commenter lists from two or more of your own posts and finds the
people whose name appears in more than one of them.

**The line only this unit produces:** the repeat-engager roster with each
name's appearance count across the posts supplied.

## Required input

1. **Two or more commenter lists**, each labeled with which post it came
   from (`Post 1`, `Post 2`, and so on, in the order you post them), names
   and headlines as shown.

Nothing else is required. No post content, no reaction counts, no dates
beyond what the list itself carries.

## What it refuses

**Refusal 1, fewer than two lists.**

```
NOT ENOUGH LISTS
lists supplied: <n>

This unit finds people who appear across more than one post. One list
cannot show a repeat. Paste the commenter list from a second post.
```

**Refusal 2, the lists are identical.** Compare every list pasted against
every other, name for name, headline for headline, in the same order. If
any two lists match exactly:

```
DUPLICATE PASTE
Post <a> and Post <b> are identical, name for name, in the same order.

This almost always means the same list got pasted twice rather than two
different posts. If these really are two different posts whose commenters
happen to be identical in the same order, say so and resupply with a note
confirming it, because right now this reads as a paste error.
```

## Method

**Step 1, parse every list into rows.** One row per line: name, headline as
shown, source list label.

**Step 2, dedupe within each list first.** If the same name appears more
than once inside one list (they commented twice on the same post), collapse
it to one row for that list before counting across lists. State the rule: a
name showing up five times on one post counts as appearing on that ONE
post, not five.

**Step 3, count the population.** `total rows after within-list dedupe: <n>
across <n> lists`.

**Step 4, group by name.** Normalize case and whitespace only, nothing
else. For every unique name, list which post labels they appear in and
their headline (the most recent non-blank one, with the list it came from).

**Step 5, classify every name.** Two classes:

- `REPEAT`: appears in two or more distinct lists.
- `SINGLE`: appears in exactly one list.

Print both rows even when one is empty:

```
unique names: <n>
REPEAT: <n>
SINGLE: <n>
```

**Step 6, build the roster from `REPEAT` only, ordered by appearance count,
highest first.** Ties keep the order the names first appeared in the pasted
lists.

## Output format

```
# Repeat engagers
lists supplied: <n>
total rows after within-list dedupe: <n>
unique names: <n>
REPEAT: <n>   SINGLE: <n>

## Roster
### <name>
appears in: <n> of <n> posts (<Post 1>, <Post 3>, ...)
headline: "<most recent>"

## No repeat engagers found
<printed only when REPEAT = 0, with the count of single-post commenters
instead>
```

## Worked case

This worked case is a literal run of `fixtures/three-posts-commenters.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Repeat engagers
lists supplied: 3
total rows after within-list dedupe: 12
unique names: 8
REPEAT: 3   SINGLE: 5

## Roster
### Dario Kessling
appears in: 3 of 3 posts (Post 1, Post 2, Post 3)
headline: "Founder at Voss & Rye"

### Marisol Fenn
appears in: 2 of 3 posts (Post 1, Post 2)
headline: "Ops Lead at Thistlebrook"

### Priya Chandrasekaran
appears in: 2 of 3 posts (Post 1, Post 3)
headline: "RevOps at Brackwater"

Names that looked similar but were kept separate: "Priya Chandrasekaran" /
"Priya Chandrasekharan" (Post 3 only, SINGLE)
```

Post 1's raw list carries "Priya Chandrasekaran" twice; Step 2 collapses
that to one row for Post 1 before anything else runs, which is why her
appearance count reads 2 (Post 1, Post 3) and not 3.

## Edge cases

**A name is spelled slightly differently between two lists** (a middle
initial added, a suffix dropped, one letter different). Treat as two
different people. This unit does not guess at identity beyond exact name
matching on case and whitespace only; merging near-matches is a guess this
unit will not make. Print a note under the roster: `Names that looked
similar but were kept separate: "<name A>" / "<name B>"`.

**Three or more lists supplied, and someone appears on all of them.** Print
their full list of post labels alongside the count. The list of labels is
the part that shows whether they hit every post or only two out of five;
the count on its own cannot tell the two apart.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never merge two different-looking names into one person.
- Never count a name's within-list repeats as separate post appearances.
- Never invent a headline for a repeat engager beyond what one of the pasted
  lists carried.
- No em dashes anywhere. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
