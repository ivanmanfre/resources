# Fixture, a headline and an offer sentence written about organisations

Invented person. Exercises the buyer gate on an offer sentence written about
organisations.

---

## Current headline, copied exactly

Founder | Building things people want | Ex-Hallidane | Investor

## Offer sentence

I help businesses get more out of the data they already have.

## Words my buyers use for themselves

(not supplied)
