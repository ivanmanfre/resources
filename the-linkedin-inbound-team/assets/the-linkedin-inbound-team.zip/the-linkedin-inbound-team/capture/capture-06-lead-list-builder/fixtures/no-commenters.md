# Fixture, no commenters supplied

Invented for testing. Exercises the nothing-to-build-from refusal.

---

## Commenter names and headlines, from the gated post

(post is still up, nobody has commented the keyword yet)

## DM threads that followed

(none yet)
