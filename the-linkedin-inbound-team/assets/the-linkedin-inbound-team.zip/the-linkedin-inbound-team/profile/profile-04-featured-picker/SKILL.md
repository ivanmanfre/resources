---
name: profile-04-featured-picker
description: "Use when the Featured section is empty, stale, or holding three things that all do the same job. Takes the list of things you already have live plus your offer sentence and returns which three go in Featured, in which order, with a caption line each. Triggers on \"what should I put in my Featured section\", \"order my Featured tiles\", \"pick my featured posts\", \"my featured section is a mess\", \"which links go on my profile\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 04 of 30: the Featured picker

## What this does

Takes the things you already have live, sorts them by the job each one does for a
visitor, and fills the three Featured tiles in a fixed order, with a caption for
each one cut from the words you supplied.

**The line only this unit produces:** the ordered Featured slate, which three
assets, in which order, with a caption line each.

It never fills a tile with something that does not exist. Where there is nothing
honest for a tile, the tile prints empty with the reason, because an empty third
tile is a smaller cost than a third tile repeating the first.

## Required input

For each thing you already have live, four fields:

1. **Title**, exactly as it appears on the thing itself. Never derived from a URL.
2. **What it is** in plain words: a PDF, a post, a page on your site, a
   recording, a newsletter issue.
3. **The link.** If it is not published anywhere a stranger can open, write
   `not published anywhere yet` rather than leaving the field out.
4. **What a visitor gets from it**, one line. If you have not written one, write
   `not written`.

Plus **your offer sentence**, one sentence naming who you work with and what is
different for them afterwards.

Nothing here needs a view count, a download count, or any figure from a
dashboard.

## What it refuses

**Refusal 1, fewer than two things anybody can open.** Count the assets carrying
both a title and a link (Step 2). Under two, stop:

```
NOT ENOUGH LIVE TO ORDER
assets supplied: <n>
assets carrying a title and a link: <n>

Featured holds three tiles. With <n> that a visitor can open, this unit would be
choosing a placeholder for the other two, and a placeholder on a profile is a
tile that teaches a visitor to stop clicking.

Not published yet: <the titles>

Publish one of those anywhere a stranger can open it, then run this again.
```

**Refusal 2, no title invented from a link.** An asset supplied with a URL and no
title is never given one:

```
NO TITLE SUPPLIED
link: <the url>
[NEEDS: the title exactly as it appears on the thing itself]
```

A title read off a URL slug is this unit writing your asset's name for you, and
Featured prints that name at the top of the tile.

## Method

**Step 1, read the offer sentence for the buyer's words.** Print the buyer span
and the situation span, quoted. These are used only as a tie-break in Step 5, and
they never override the order in Step 4.

**Step 2, the placeable check.** An asset is `PLACEABLE` when it carries a title
and a link a stranger can open. Everything else is `NOT PLACEABLE`, printed with
its reason, and it never enters the slate. Count the placeable assets. Under two,
fire Refusal 1.

**Step 3, class every placeable asset by the job it does for a visitor.** Apply
the three tests in this order and print which one it passed:

| Class | Test, in order |
|---|---|
| `ASK` | Does it route a visitor to a conversation with you: a service page, a booking link, a form |
| `TEACH` | Can a visitor use it on their own, without talking to you |
| `PROOF` | Does it show work that was done, which a visitor cannot use themselves |

An asset whose `what a visitor gets` line reads `not written` is `UNCLASSED`. It
stays out of the slate and prints:

```
[NEEDS: one line saying what a visitor gets from "<title>"]
```

Never class an asset off its title alone. Two of the three tests ask what a
visitor can do with the thing, and a title does not say.

**Step 4, fill the tiles in the fixed order.** Tile 1 `TEACH`, tile 2 `PROOF`,
tile 3 `ASK`. The order is fixed because a visitor arrives owing you nothing, and
the tile that asks for a conversation is the one they get to last.

Where a class has no asset, take the next unused classed asset in the order
`TEACH`, `PROOF`, `ASK`, and print `slot filled from <class>` on that tile. Where
no unused classed asset remains, the tile prints:

```
TILE <n>: EMPTY, on purpose
[NEEDS: one live thing that does the <class> job, with its link]
Nothing you have live does this job. A repeat of tile 1 here costs you the slot
and tells a visitor there are only two things.
```

**Step 5, the tie-break, used only inside a class.** Two assets of the same class
competing for one tile: the one whose title or `what a visitor gets` line
contains a word from the buyer or situation span goes first. If both do, or
neither does, the one earlier in your list goes first. Print the tie-break you
used, in words.

**Step 6, write the caption for each filled tile.** The caption is a cut-down of
that asset's own `what a visitor gets` line: words may be removed and reordered,
and no word carrying a new claim may be added. One line. It says what the visitor
gets, and it never says what it will do for them.

**Step 7, print what did not make the slate.** Every asset, with its reason:
`not placeable`, `unclassed`, or `classed but the tile was taken by <title>`.
Nothing supplied to this unit disappears without a row.

**Step 8, print the census.** Population, stated in words: the assets you
supplied. Every class gets its own row, including the classes at zero:

```
assets supplied: <n>
PLACEABLE:      <n>
NOT PLACEABLE:  <n>
TEACH:          <n>
PROOF:          <n>
ASK:            <n>
UNCLASSED:      <n>
tiles filled:   <n> of 3      substitutions: <n>
```

`TEACH`, `PROOF`, `ASK` and `UNCLASSED` are counted over the placeable assets and
sum to the placeable count. No percentage is printed. Three tiles against however
many things you happen to have live is not a ratio that means anything.

## Output format

```
# Featured slate

buyer: "<span from the offer sentence>"
situation: "<span>"

## Tile 1
<title>
link: <url>
class: TEACH | slot filled from <class>
caption: <one line>

## Tile 2
<...>

## Tile 3
<...>   | TILE 3: EMPTY, on purpose + [NEEDS: ...]

## Not in the slate
- "<title>"   <reason>

## Census
<the census from Step 8>
```

## Worked case

This worked case is a literal run of `fixtures/live-assets-and-offer.md`, checked
line by line against the steps above. It is the same input, not a similar one.

```
# Featured slate

buyer: "operations directors at mid-size manufacturers"
situation: "the month-end close out of spreadsheets ... onto one system their own team can run"

## Tile 1
The month-end close checklist
link: https://kettleworth.example/close-checklist
class: TEACH   (a visitor can use it on their own)
caption: The steps we run at every close, with who signs off each one.

## Tile 2
Notes from rebuilding a close, week by week
link: https://linkedin.example/posts/rebuilding-a-close
class: PROOF   (shows work that was done, a visitor cannot run it themselves)
caption: What the rebuild looked like week by week, including the two weeks it went backwards.

## Tile 3
Work with me
link: https://kettleworth.example/work-with-me
class: ASK   (routes a visitor to a conversation)
caption: What the three-month engagement covers and how to start one.

tie-breaks used: none, one asset per class

## Not in the slate
- "The handover template"        not placeable, no published link
- "A talk I gave on process debt"  unclassed, [NEEDS: one line saying what a visitor gets from "A talk I gave on process debt"]

## Census
assets supplied: 5
PLACEABLE:      4
NOT PLACEABLE:  1
TEACH:          1
PROOF:          1
ASK:            1
UNCLASSED:      1
tiles filled:   3 of 3      substitutions: 0
```

All three captions are the supplied `what a visitor gets` lines, capitalised,
with no word added and none carrying a new claim. Nothing needed cutting on this
input, and the pronoun stayed as the reader wrote it. The talk stayed out with a bracket rather than being classed from its
title, because a recording could be teaching or it could be a record of a room,
and the title does not say which.

## Edge cases

**An asset is live but on a platform a stranger has to log into.** It is
`PLACEABLE` and prints one line saying the visitor will meet a login. This unit
does not judge that. It makes it visible before the tile goes up.

**Two assets are the same thing in two formats** (the PDF and the post announcing
it). Class both, and put whichever the tie-break selects in the tile. Print the
other under `not in the slate` with the reason `same thing as "<title>"`.

**Every placeable asset is `ASK`.** Tile 1 takes the first `ASK` with
`slot filled from ASK` printed, and tiles 2 and 3 print empty with their brackets.
A Featured row of three service pages is a row of three closed doors, and this
unit will print that rather than fill them.

**The reader wants a fourth tile.** Featured holds more than three, and this unit
orders three. Print the fourth-onward assets under `not in the slate` with the
reason `beyond the three this unit orders`, so the reader can add them knowing
what the first three were chosen to do.

**The offer sentence is missing.** Step 1 prints
`[NEEDS: your offer sentence, one line]` and the run continues. Step 5 then falls
back to list order for every tie, and prints that it did.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a title, a link, a format, or a line about what a visitor gets.
- Never put an asset in a tile because there was nothing else. Substitutions are
  printed by class, and empty tiles print empty.
- Never write a caption that claims what the asset will do for the visitor.
- Never put a number in a caption unless the supplied lines carried it.
- Never name a client or a company the input did not name.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
