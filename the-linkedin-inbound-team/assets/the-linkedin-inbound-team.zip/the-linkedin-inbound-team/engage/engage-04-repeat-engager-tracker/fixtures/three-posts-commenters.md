# Fixture, commenter lists from three of your own posts

Invented for testing. Not real posts and not a record of any real people.

Note: exercises the within-list dedupe rule (one name comments twice on the
same post), the repeat-across-lists count, and a near-miss name spelling
that must be kept as two separate people.

---

## Post 1
Marisol Fenn, Ops Lead at Thistlebrook
Dario Kessling, Founder at Voss & Rye
Priya Chandrasekaran, RevOps at Brackwater
Priya Chandrasekaran, RevOps at Brackwater
Tomasz Bilek, Head of Ops at Ferndale Metals

## Post 2
Dario Kessling, Founder at Voss & Rye
Selin Aydemir, RevOps Lead at Bramwell Co
Colm Ashworth, no headline shown
Marisol Fenn, Ops Lead at Thistlebrook

## Post 3
Dario Kessling, Founder at Voss & Rye
Devon Achebe, Support Manager at Kestrel Freight
Priya Chandrasekaran, RevOps at Brackwater
Priya Chandrasekharan, RevOps at Brackwater
