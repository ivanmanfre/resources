# Fixture, a draft with nothing in it to reshape

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: a paste that is under the line floor
whether you count its newlines or its sentences.

---

The file on my phone has nine entries in it now.

Six of them ask the same thing in different words.
