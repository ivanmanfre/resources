# Fixture, an experience entry with an empty body

Invented person, invented company. Exercises the activity gate on the commonest
shape a founder's own entry takes.

---

## Header, as it appears

Founder
Pellamont Group  ·  Self-employed
Jan 2019 to Present
Remote

## Body, as it appears

(nothing written)
