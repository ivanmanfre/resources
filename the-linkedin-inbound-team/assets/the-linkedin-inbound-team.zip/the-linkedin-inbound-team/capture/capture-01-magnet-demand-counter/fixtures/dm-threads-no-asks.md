# Fixture, DM threads carrying no requests

Invented for testing. Exercises the zero-request refusal branch.

---

### Thread 1, with Farah K.
Farah: loved the post today
Priya: thanks so much
Farah: keep them coming

### Thread 2, with Owen T.
Owen: congrats on the feature
Priya: appreciate it
Owen: well earned
