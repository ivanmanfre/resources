# Fixture, an asset that already exists

Invented for testing. Not a real product.

---

## The description, pasted as written

A one-page checklist, PDF. Ten yes/no questions a freelance designer runs
through before quoting a new client. Covers budget signals, decision-maker
access, scope creep risk, and timeline pressure. Built after losing a project
to scope creep last spring; started writing the questions down before every
call.

## The offer sentence

I help freelance designers avoid bad-fit clients by building a two-call
vetting process before they ever send a quote.
