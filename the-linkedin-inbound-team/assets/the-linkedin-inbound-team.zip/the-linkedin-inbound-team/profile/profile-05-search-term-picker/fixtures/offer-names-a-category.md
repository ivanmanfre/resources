# Fixture, an offer sentence written about a market

Invented person, invented company. Exercises the searcher gate on an offer
sentence written about a market.

---

## Offer sentence

I do fractional operations work for the mid-market.

## The noun I would use if a buyer asked what I am

Fractional COO

## Profile text

### Headline

Fractional COO | Mid-market | Ex-Verrow

### About

I partner with ambitious organisations to drive operational excellence across the mid-market.

Twenty years of experience across four sectors.

Open to conversations.

### Current role

title: Fractional COO
description: (not written)

### Skills

Operations, Strategy, Leadership

### Location

Manchester, United Kingdom
