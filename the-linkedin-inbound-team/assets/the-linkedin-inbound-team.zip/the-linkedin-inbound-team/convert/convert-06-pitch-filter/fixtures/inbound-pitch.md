# Fixture, a straightforward inbound pitch

Invented for testing. Not a real thread and not a record of any real person.

Person: Callan Reeve

---

M1 THEM: "Loved your last post on onboarding. I run a growth agency and we
help founders like you build out a full content system, want to grab 15
minutes so I can show you what we do."
