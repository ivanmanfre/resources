# Fixture, an About section pasted whole

Invented person, invented company. Exercises an About written in the order a
career happened rather than the order a visitor reads.

---

Fifteen years in operations and I still think the hardest part of any business is the handover.

I run Kettleworth, where we take the month-end close out of one person's head and put it into a system the rest of the team can run.

Most of that work is unglamorous.

Naming things, deciding who signs off, writing down the step everybody assumed was obvious.

Before this, nine years in finance transformation at a consultancy.

I work mainly with operations directors at manufacturers between fifty and two hundred people, usually at the point where the person who has always done the close wants a holiday.

I am passionate about building great teams and driving excellence.

If you want to talk about a close that does not depend on one person, my inbox is open.
