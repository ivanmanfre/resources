# Fixture, a title with no contents list behind it yet

Invented for testing. Exercises the zero-items branch.

---

## The chosen title

The 5-Template Onboarding Pack

## The contents list, as the reader pasted it

(nothing pasted here yet, still deciding what goes in it)
