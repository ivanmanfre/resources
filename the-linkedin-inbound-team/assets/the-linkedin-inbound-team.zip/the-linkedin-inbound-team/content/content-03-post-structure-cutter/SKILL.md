---
name: content-03-post-structure-cutter
description: "Use when a post is written and reads as a wall of text in the feed. Takes the draft at any length and returns it reformatted, with the see-more fold marked at a printed character count and the line-break map printed beside it. Triggers on \"format this post for LinkedIn\", \"where does the fold fall\", \"break this draft into lines\", \"this post is too long\", \"what should I cut from this\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 03 of 06: the post structure cutter

## What this does

Takes a finished draft and decides three things about its shape: what comes out,
where the see-more fold falls once it is out, and where the line breaks go.

**The line only this unit produces:** the reformatted draft with a fold marker
carrying the cumulative character count at the sentence it falls after.

Nothing is rewritten. Sentences are cut, trimmed of a leading transition word, or
moved between blocks, and the words that survive are the words you typed. A unit
that rewrote the sentences would be handing back its own post with your facts in
it.

## Required input

1. **The post draft**, pasted whole, at any length, with your paragraph breaks
   as you made them.
2. Optional: **a different fold budget**, in characters, if you want one. The
   default is 210 and it is printed on every run.

The fold budget is an assumption, printed so you can move it. LinkedIn shows a
different amount of a post before the see-more link depending on the device and
the post type, so 210 is a budget to write against, never a promise about where
the cut lands on any one screen. Every sentence gets its cumulative count
printed, so you can move the fold yourself without rerunning anything.

## What it refuses

**Refusal 1, nothing to reshape.** Counted two ways, and the refusal needs both
to be under four:

```
NOTHING TO CUT
Paragraphs: <n>   Sentences: <n>

A draft this short has no shape to work on. Every reformatting move available
here needs somewhere to put a break, and this paste has fewer than four
paragraphs and fewer than four sentences.

Write it out longer and run this again.
```

**Refusal 2, an opening sentence over the fold budget with nowhere to split.**
If the first sentence runs past the budget and carries no comma, semicolon or
colon inside it:

```
FIRST SENTENCE OVER BUDGET, NO BOUNDARY INSIDE IT
Opening sentence: <n> characters   Budget: <n>   Over by: <n>

Everything above the fold is one unbroken sentence, and this unit cuts at
boundaries you wrote rather than mid-clause.
[NEEDS: a shorter opening sentence, yours to write]

The rest of the post is reformatted below and the fold is marked at the end of
that sentence, with the overflow printed.
```

**Refusal 3, rewriting.** If asked to improve the sentences rather than the
shape, print this and stop:

```
THIS UNIT MOVES YOUR SENTENCES, IT DOES NOT WRITE THEM
What comes back would be my sentences under your name.
```

## Method

**Step 1, count and gate.** Print paragraphs (runs of text separated by a blank
line) and sentences. A raw newline count is not used, because most pastes have
been hard-wrapped by an editor and the newlines are an artefact of the window
width rather than a choice you made. If both counts are under four, Refusal 1
fires.

**Step 2, the cut list, read off your draft.** Number the sentences S1 upward.
Walk them and class each cut candidate. Four classes, and where a sentence fits
two, the more specific one wins, in this order: `REPEAT`, `OFF-SUBJECT`,
`SETUP`, `SCAFFOLD`.

| Class | What it is |
|---|---|
| `REPEAT` | says what an earlier sentence already said. Print the earlier id |
| `OFF-SUBJECT` | belongs to a different post. Print the subject it belongs to |
| `SETUP` | announces what you are about to say without saying it |
| `SCAFFOLD` | manages the reader through the post and names nothing new: "before I go on", "as I said", "here is the thing" |

There is a fifth move that is not a cut. `TRIM` removes a leading transition
word from a sentence you are keeping, and prints the exact string removed.

**Every class gets a printed row, including the ones at zero.** A class that
found nothing prints `0` and stays on the page, because a missing row reads as a
class that was never checked. Every cut candidate is printed verbatim with its
id, and nothing leaves the draft silently.

**No percentage is printed in this step.** A share of cut sentences would move
with how long you chose to write rather than with how the post reads, so this
step prints counts only. Kept and cut are both printed as counts of sentences.

**Step 3, the fold, on what survives.** Assemble the surviving sentences in
order and walk the characters from the first one, counting spaces and line
breaks. Print the cumulative count at every sentence end. The fold is marked
after the last sentence end at or before the budget.

Print:

```
fold budget: <n> characters
fold falls after: S<n>   cumulative: <n>
headroom to the budget: <n> characters
first sentence past the budget: S<n>, cumulative <n>
```

If the first surviving sentence alone is over the budget, split it at a comma,
semicolon or colon you already wrote, print the split point and the count, and
mark the fold there. With no boundary inside it, Refusal 2 fires and the run
continues from Step 4 with the overflow printed.

**Step 4, the block map.** Assign every surviving sentence to a block. A block
holds at most two sentences, with one exception: a list the draft wrote as
consecutive parallel sentences stays whole, however many it has, because a list
split across a break stops reading as a list.

A boundary goes at one of four places, and the reason is printed as one word:
`subject`, `list`, `turn`, `close`.

Print the map as a single line of ids, blocks separated by a pipe, with the
reason under each boundary.

**Step 5, print the reformatted post.** Blocks separated by a blank line,
sentences inside a block on their own lines, the fold marker inserted as its own
line. Words unchanged apart from the `TRIM` strings removed at Step 2.

## Output format

```
# Reshaped: <draft first three words>

## Counts
paragraphs: <n>   sentences: <n>

## Cut list
REPEAT (<n>)
  S<n> "<verbatim>"   repeats S<n>
OFF-SUBJECT (<n>)
  <rows, or none>
SETUP (<n>)
  S<n> "<verbatim>"
SCAFFOLD (<n>)
  S<n> "<verbatim>"
TRIM (<n>)
  S<n> remove "<string>", sentence kept

sentences kept: <n>   sentences cut: <n>
(no share is printed here; it would move with how long you wrote)

## Fold
fold budget: <n> characters
fold falls after: S<n>   cumulative: <n>
headroom to the budget: <n> characters
first sentence past the budget: S<n>, cumulative <n>
opening sentence length: <n> characters   (printed only when it is over budget)

## Line-break map
S<n>,S<n> | S<n>,S<n> | S<n> | ...
boundary 1: <subject|list|turn|close>
boundary 2: <...>

## The post
<block>

<block>
----- see-more fold, <n> characters -----
<block>
```

## Worked case

This is the fixture run. It is `fixtures/long-draft.md`, executed line by line
against the rules above. Every character count below was measured on the
assembled text, counting spaces and line breaks, with blocks separated by one
blank line.

```
## Counts
paragraphs: 6   sentences: 14

## Cut list
REPEAT (1)
  S9 "As I said, most of the file is about deciding."   repeats S7
OFF-SUBJECT (0)
  none
SETUP (1)
  S1 "I want to talk about something that took me a while to work out."
SCAFFOLD (1)
  S10 "Before I go on, it is worth saying this is a small sample."
TRIM (1)
  S11 remove "Anyway, ", sentence kept

sentences kept: 11   sentences cut: 3
(no share is printed here; it would move with how long you wrote)

## Fold
fold budget: 210 characters
fold falls after: S3   cumulative: 157
headroom to the budget: 53 characters
first sentence past the budget: S4, cumulative 226

## Line-break map
S2,S3 | S4,S5 | S6 | S7,S8 | S11,S12 | S13 | S14
boundary 1: subject
boundary 2: subject
boundary 3: list
boundary 4: turn
boundary 5: subject
boundary 6: close

## The post
I keep a file called "questions people ask twice".
It started as a note on my phone in January, after a third call in one week opened with the same sentence.
----- see-more fold, 157 characters -----

The sentence was, "how do you actually decide what to write about".
I wrote it down that afternoon.

By March the file had nine entries.

Six of the nine asked how to decide.
Three asked about the writing itself.

The file changed how I open a call.
The next call I ran, I opened on how the choice gets made.

She booked a second call before we hung up.

The file is still on my phone and it still gets entries.
```

The second fixture, `fixtures/short-draft.md`, fires Refusal 1 at
`Paragraphs: 2   Sentences: 2`. The third, `fixtures/draft-with-long-opener.md`,
runs Step 3's split branch rather than Refusal 2: its opening sentence measures
249 characters against the 210 budget and carries a comma boundary at 146
characters, so the fold is marked at that comma and the printed lines read
`opening sentence length: 249 characters` and
`fold falls after: S1, split at your comma   cumulative: 146`.

## Edge cases

**The draft has no blank lines at all.** Paragraphs counts as 1 and the gate
falls to the sentence count. The block map then does the whole job, and every
boundary in it is one you did not have before.

**A one-sentence paragraph you clearly wanted alone.** Keep it alone. A
paragraph break you made is a decision, and this unit only adds breaks and
removes sentences, so an existing break is never merged away without printing
`MERGED: your break between S<n> and S<n>` and the reason.

**A cut candidate you want to keep.** Every candidate is printed verbatim rather
than removed quietly, so keeping it costs one paste back. This unit never hands
back a shortened post with sentences missing from the list.

**The whole draft sits above the fold.** Print the cumulative total, print
`entire post above the fold`, and run the block map anyway.

**A list of more than four parallel sentences.** Keep it whole and print
`LIST OF <n> KEPT WHOLE`. If it runs past the fold, print the count of list
items above the fold, and leave the decision with you.

**The draft ends on a question to the reader.** Leave it exactly as written.
Closing lines are not this unit's business, and rewriting one here would collide
with the units that own the ask.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never rewrite, reword, merge or shorten a sentence. Cut it, trim a named
  leading string from it, or leave it alone.
- Never remove a sentence without printing it verbatim in the cut list with its
  class.
- Never invent a fact, a line, a transition sentence or a closing line to bridge
  a break you made.
- Never print a share, a percentage or a score of the draft. Counts only.
- Never state where the fold falls on a particular device, and never call the
  budget a rule. It is printed as an assumption on every run.
- Never claim what the reformatting will do to a post's performance.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
