# Fixture, an offer sentence and a draft with no link to it

Invented for testing. No real people, no real companies, no record of any
engagement.

What this input is designed to exercise: a draft that sounds like it is about
the offer and names none of the offer's parts.

---

My offer sentence:
I write the weekly client note for B2B agencies so the work they do stays
visible to the client.

How I ask for a reply, in words I already use:
send me a message

My draft:
I missed a train on Thursday and spent forty minutes on a platform bench with a
book about bridge maintenance.
The chapter I read is about inspection intervals.
Inspectors walk the same bridge on a schedule whether or not the work looks finished.
The interval is the whole method.
I have thought about that sentence every day since.
