# Fixture, too few headlines supplied

Invented for testing.

Note: exercises Refusal 1 - fewer than ten headlines pasted.

---

Offer sentence: "I help revenue operations leaders fix pipeline reporting
before it reaches the board."

Commenter headlines, from one post by the creator:

1. Director of Revenue Operations at Thistlebrook SaaS
2. VP Marketing at Solent Retail
3. Open to opportunities
4. Head of RevOps, Brackwater Analytics
5. Growth Lead at Ferring Health
6. 🚀🚀🚀
