---
name: content-05-offer-mention-placer
description: "Use when a post is about something else and you are wondering whether the offer can go at the bottom of it. Takes the draft plus your offer sentence and returns either one closing line with the line number it belongs after, or a printed decline saying the link is not there. Triggers on \"where do I mention my offer in this post\", \"should this post have a CTA\", \"add my offer to this draft\", \"how do I close this post\", \"is it too salesy to pitch here\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 05 of 06: the offer mention placer

## What this does

Runs three named tests between your draft and your offer sentence. Where one
holds, it writes a single flat closing line and prints the line number it goes
after. Where none holds, it writes nothing and prints why.

**The line only this unit produces:** one closing line carrying the offer, with
the name of the link that earns it and the line of the draft that carries that
link quoted beside it.

The decline is the main output of this unit, and it fires more often than the
line does. A closing line on a post with no link to the offer is an
advertisement under a story that does not lead to it, read by the people who
liked the story.

Nothing here is written to persuade. The line states what you do and how to
reach you, in words already present in the input.

## Required input

1. **Your offer sentence**, one sentence, as you would say it. It has to name
   three things: who it is for, what you do, and what is different afterwards.
2. **The post draft**, pasted whole.
3. **How you ask for a reply**, as a phrase you already use, for example
   `send me a message`. Without it the ask cannot be written in your words, and
   `[NEEDS: the words you use when you want a reply]` is printed in its place.

No audience data, no analytics, no past post performance.

## What it refuses

**Refusal 1, the offer sentence is missing a part.** Print the tokens found,
print the gap, and stop:

```
OFFER SENTENCE INCOMPLETE
BUYER:  [NEEDS: who this is for, named in your offer sentence]
WORK:   "<verbatim>"
CHANGE: "<verbatim>"

Two of the three link tests below run off the buyer, so with no buyer named
there is nothing to test the draft against. Write the offer sentence with the
buyer in it and run this again.
```

**Refusal 2, no honest link.** This is the one that carries the unit:

```
NO HONEST LINK, NO OFFER LINE
links holding: 0 of 3
SAME BUYER:  FAILS, the draft never names or addresses <BUYER>
SAME WORK:   FAILS, no line describes you doing <WORK>
SAME CHANGE: FAILS, the story does not end in <CHANGE>
thematic echo: L<n> "<quote>" shares "<word>" with your offer and is not a link

No closing line is written.

Two things would make a link, and both are edits to the draft rather than lines
to bolt on the end:
- name the people this post is for, inside the post
- tell the part of this story where you did <WORK>
```

**Refusal 3, asked to make it persuasive.** Print this and stop:

```
NOT THIS UNIT
Asked for: "<the request, verbatim>"
This unit places one flat line where a link already exists. A closing line
written to persuade turns everything above it into the setup for a pitch, and
everything above it is the reason anybody is still reading.
```

**Refusal 4, the offer is already in the draft.** If a line already states the
work or already asks the reader for something, print
`OFFER ALREADY PRESENT: L<n> "<quote>"` and write no second line. Two asks in one
post is one ask too many, and the second one is the one that gets ignored.

## Method

**Step 1, take three tokens off the offer sentence.** Quote each verbatim:

| Token | What it is | If it is not in the sentence |
|---|---|---|
| `BUYER` | who the offer is for | Refusal 1 |
| `WORK` | what you do, as a verb phrase | Refusal 1 |
| `CHANGE` | what is different after the work | `[NEEDS: what is different after, in your offer sentence]`, and the SAME CHANGE test is skipped and printed as `not testable` |

Never infer a buyer from the draft. The buyer comes off the offer sentence or
the run stops.

**Step 2, number the draft's lines.** One sentence per line, L1 upward. Print
the numbered draft, because the output names a line number and a reader has to
be able to find it.

**Step 3, name the subject of the draft.** The subject is the noun phrase
appearing in the most lines. On a tie, the one appearing in the later line wins,
and the rule is printed with the counts. If two phrases tie on both, print
`[NEEDS: which of "<a>" or "<b>" this post is about]` and stop.

**Step 4, the link test.** Three tests, all three printed with their verdict,
including the ones that fail:

| Link | It holds when | What is printed |
|---|---|---|
| `SAME BUYER` | a line names or addresses the `BUYER`, in any inflected form | the line quoted, and the matched words |
| `SAME WORK` | a line describes you doing the `WORK`, or one step of it, first hand | the line quoted |
| `SAME CHANGE` | the story ends in the `CHANGE` the offer names | the line quoted |

Print `links holding: <n> of 3`. At zero, Refusal 2 fires and no line is
written. Where more than one holds, the line is built on the strongest, and the
order of strength is printed: `SAME WORK`, then `SAME CHANGE`, then `SAME BUYER`.

**Step 5, the echo check, pointed at the draft.** Find any line sharing a content
word with the `CHANGE` or the `WORK` that did not pass a test. Print it as
`thematic echo`. An echo is the sentence that makes an unrelated post feel
related to the offer, and naming it is what stops it being mistaken for a link.
Print `thematic echo: none` when there is none.

**Step 6, the blocks.** Two checks against the draft, both printed:

- `offer already in the draft`: any line containing the `WORK` token. If yes,
  Refusal 4.
- `existing ask in the draft`: any line asking the reader to do something. If
  yes, the offer line is printed as `REPLACES L<n>` with that line quoted, never
  as an addition.

**Step 7, write the line.** Six constraints, all printed with the line:

1. one line, at most two sentences
2. at most twenty-four words, counted as whitespace-separated tokens and printed
3. contains the `WORK` token or the `BUYER` token verbatim, and prints which
4. contains the ask phrase you supplied, verbatim
5. no result, no time claim, no price, no number the input did not carry
6. every content word is sourced, and the sources are printed

**Step 8, the provenance table.** Print every word of the line with where it came
from: `OFFER`, `DRAFT L<n>`, `ASK PHRASE`, `FUNCTION` (article, preposition,
pronoun, auxiliary), or `ATTACHMENT`. `ATTACHMENT` is a closed list of four words
this unit may use to attach the ask, and the list is printed on every run:
`want`, `need`, `use`, `see`. A word that cannot be sourced comes out of the
line. Inflected forms are allowed and printed as such.

**Step 9, place it.** Print the line number it goes after, and one line saying
why that number. The default is after the last line of the story. Where an
existing ask was found, the placement is `REPLACES L<n>`.

## Output format

```
# Offer mention for <draft first three words>

## Tokens
BUYER:  "<verbatim>"
WORK:   "<verbatim>"
CHANGE: "<verbatim>"

## The draft, numbered
L1 <sentence>
...
subject of the draft: "<noun phrase>"   appears in: L<n>, L<n>

## Link test
SAME BUYER:  HOLDS | FAILS   <quote, matched words>
SAME WORK:   HOLDS | FAILS   <quote>
SAME CHANGE: HOLDS | FAILS | not testable   <quote>
links holding: <n> of 3
thematic echo: L<n> "<quote>" shares "<word>" | none

## Blocks
offer already in the draft: no | yes, L<n>
existing ask in the draft: no | yes, L<n>

## The line
"<the line>"
words: <n>   sentences: <n>
link used: <name>, earned by L<n> "<quote>"
place it: after line <n> | REPLACES L<n>
why there: <one line>

## Word provenance
<word>   OFFER | DRAFT L<n> | ASK PHRASE | FUNCTION | ATTACHMENT
attachment list: want, need, use, see
```

## Worked case

This is the fixture run. It is `fixtures/offer-and-linked-draft.md`, executed
line by line against the rules above.

```
## Tokens
BUYER:  "B2B agencies"
WORK:   "write the weekly client note"
CHANGE: "the work they do stays visible to the client"

## The draft, numbered
L1 An agency I sat with last Tuesday handed a new hire an eleven-page onboarding pack.
L2 She read two pages and asked the person next to her if there was a shorter version.
L3 There was one, in a Slack thread from March.
L4 We spent the afternoon turning the Slack thread into a one-page card.
L5 The card is what the next hire will get.
L6 Written things decay in the direction of longer.
subject of the draft: "the card"   appears in: L4, L5
   (tied on two lines with "the Slack thread" at L3, L4; the later line wins)

## Link test
SAME BUYER:  HOLDS   L1 "An agency I sat with last Tuesday"   matched: agency / agencies
SAME WORK:   FAILS   no line describes writing the weekly client note
SAME CHANGE: FAILS   the story ends on documents getting longer, not on work staying visible
links holding: 1 of 3
thematic echo: none

## Blocks
offer already in the draft: no
existing ask in the draft: no

## The line
"I write the weekly client note for agencies. Send me a message if you want one."
words: 16   sentences: 2
link used: SAME BUYER, earned by L1 "An agency I sat with last Tuesday"
place it: after line 6
why there: the draft carries no ask, so the line goes after the last line of the
story and nothing is displaced.

## Word provenance
I          FUNCTION
write      OFFER
the        FUNCTION
weekly     OFFER
client     OFFER
note       OFFER
for        FUNCTION
agencies   OFFER, and DRAFT L1 as "agency"
Send       ASK PHRASE
me         ASK PHRASE
a          ASK PHRASE
message    ASK PHRASE
if         FUNCTION
you        FUNCTION
want       ATTACHMENT
one        FUNCTION
attachment list: want, need, use, see
```

The second fixture, `fixtures/offer-and-unrelated-draft.md`, fires Refusal 2 at
`links holding: 0 of 3`, with
`thematic echo: L3 "Inspectors walk the same bridge on a schedule whether or not the work looks finished." shares "work" with your offer and is not a link`.
That line is the reason the draft feels like it is about the offer, and it names
inspectors and a bridge rather than the buyer, the work or the change.

The third fixture, `fixtures/offer-without-a-buyer.md`, fires Refusal 1: the
offer sentence carries `WORK: "make the invisible parts of the work visible"` and
no buyer, so `BUYER: [NEEDS: who this is for, named in your offer sentence]` is
printed and no test runs.

## Edge cases

**Two links hold.** Build the line on the stronger, in the printed order, and
print the other as `also holds`. One line, always.

**The draft is a client story.** The `SAME WORK` link holds and the line still
carries no result. This unit places a mention, and the outcome claims in the
story above it are yours and are not touched here.

**The draft ends on a question to the reader.** That is an existing ask.
`REPLACES L<n>` fires, the question is printed verbatim, and you decide which of
the two survives.

**The offer changed since the draft was written.** Run against the offer
sentence you would say today. The draft is the fixed input.

**You want the line above the fold.** Print `place it: after line <n>` as usual
and add one line saying the request was not applied and why: an offer line above
the fold reads before the story that earns it.

**The link is real and the ask phrase is missing.** Write the line up to the ask
and print `[NEEDS: the words you use when you want a reply]` in place of the
second sentence. Never invent a call to action.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a closing line when the link test holds at zero. There is no
  softer version of that decline, and a hedged mention is still a mention.
- Never name a buyer the offer sentence did not name.
- Never write a result, a number, a duration, a price or a promise into the line.
- Never use a content word that cannot be sourced in the provenance table.
- Never write two asks into one post.
- Never move the offer line above the fold on request.
- Never claim what the line will do to replies, calls or anything else.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
