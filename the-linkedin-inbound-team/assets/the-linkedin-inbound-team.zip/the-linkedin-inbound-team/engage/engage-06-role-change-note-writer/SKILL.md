---
name: engage-06-role-change-note-writer
description: "Use when a connection shows a new job or promotion on LinkedIn and you want to send a note that is actually about the change. Takes the connection's profile showing their previous and current role and returns the two-line note tied to the specific change, naming the old seat and the new one. Triggers on \"write a note for someone's promotion\", \"congratulate this connection on their new role\", \"draft a message for a job change\", \"someone I know just changed jobs\", \"write a role-change note\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 06 of 30: the role change note writer

## What this does

Reads the two most recent entries on a connection's profile and writes a
short note tied to what actually changed between them.

**The line only this unit produces:** the two-line note tied to the
specific role change, naming the old seat and the new one.

## Required input

1. **The connection's profile showing both the previous role and the
   current role**, pasted as it appears: company, title, and dates for each
   of the two most recent entries. If more than two entries are visible,
   paste at least the two most recent; earlier history is not used.

Nothing else is read. No mutual connections, no company size, no funding
news.

## What it refuses

**Refusal 1, the change is a title edit inside the same seat.** Run the
seat test in Step 2. If it fails:

```
SAME SEAT, NOT A CHANGE
previous: "<title>, <company>"
current:  "<title>, <company>"

The only difference is a seniority word (<the word>). There is no event
here to write a note to. A note about a title edit inside the same seat
reads as if you were not really paying attention to which one it was.
```

## Method

**Step 1, identify the two most recent entries.** If more than two are
pasted, use the top two and print: `entries used: "<title>, <company>"
(current) and "<title>, <company>" (previous). Earlier entries ignored:
<n>.` If exactly two were supplied, print `earlier entries ignored: 0`.

**Step 2, run the seat test.** A seat change is anything other than: same
company, and the title differs only by a seniority-tier word (`Junior`,
`Senior`, `Lead`, `Head`, `Principal`, `Staff`, `Associate`) added,
removed, or swapped, with everything else in the title identical. Anything
else - different company, different function or department word in the
title, a title going from individual-contributor language to a management
or director/VP word, or the reverse - counts as a seat change. If it is not
a seat change, fire Refusal 1 and stop.

**Step 3, classify the seat change.** Two classes:

- `NEW COMPANY`: the company name differs between the two entries.
- `INTERNAL MOVE`: same company, different function, department, or scope.

**Step 4, write the note.** Two lines. Line 1 names the old seat and the
new seat by their exact titles and, for `NEW COMPANY`, both companies. Line
2 is a short open line with no pitch, no offer mention, and no ask beyond
an implicit invitation to reply if they want to.

## Output format

```
# Role change note
entries used: "<title>, <company>" (current) and "<title>, <company>"
(previous)
class: NEW COMPANY | INTERNAL MOVE

Line 1: <the note's first line>
Line 2: <the note's second line>
```

This is a draft in neutral register, not a claim of your voice. Rewrite it
in your own words before you send it.

## Worked case

This worked case is a literal run of `fixtures/role-change-profile.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Role change note
entries used: "Director of Client Operations, Harrow & Vance" (current) and
"Senior Client Operations Manager, Fennimore Health" (previous)
class: NEW COMPANY

Line 1: You've moved from Senior Client Operations Manager at Fennimore
Health to Director of Client Operations at Harrow & Vance.
Line 2: Curious what pulled you toward Harrow & Vance, feel free to share
whenever you have a minute.
```

## Edge cases

**The current entry has no end date and the previous one also has none**
(looks like they are doing both at once). Print one line: `Both entries
show no end date on the earlier one; treat this as a possible dual-role
rather than a clean change, and say so in Line 1 instead of naming a move.`
Do not write the standard two-line note in this case; write the one-line
flag instead.

**The new title is a lateral move to a different function, same seniority
word.** Still `INTERNAL MOVE`, since the seat test only exempts a pure
seniority-word swap. A function change with identical seniority language is
still a seat change.

**The profile shows a return to a company the person left before** (their
current entry's company matches an entry further back than the two most
recent). This unit only reads the two most recent entries per Required
input, so it will not see that. Print nothing about it; it is out of scope
for what was pasted.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a reason for the move, a company detail, or a date the
  profile did not show.
- Never mention your offer, your services, or ask for a call. This is an
  engagement note, not an outreach message.
- Never write a note claiming to know how the person feels about the move.
- No em dashes anywhere. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
