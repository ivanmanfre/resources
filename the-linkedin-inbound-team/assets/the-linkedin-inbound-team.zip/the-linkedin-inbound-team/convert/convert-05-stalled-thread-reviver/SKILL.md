---
name: convert-05-stalled-thread-reviver
description: "Use when a DM thread you were part of has gone quiet and it is your turn to send the one follow-up. Takes the quiet DM thread, with the dates as the thread shows them, and returns the single revival message, two sentences, quoting their last concrete detail. Triggers on \"write a follow-up for this dead thread\", \"revive this stalled DM\", \"this conversation went quiet, what do I send\", \"one follow-up for a cold thread\", \"bump this conversation\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 29 of 30: the stalled thread reviver

## What this does

Writes one follow-up message for a thread where the last word was yours and
nothing came back. It never writes a general check-in; it quotes the last
real thing they said and asks about that.

**The line only this unit produces:** the single revival message, two
sentences, quoting their last concrete detail.

## Required input

1. **The quiet DM thread**, both sides, in order, with the dates as the
   thread shows them, whatever LinkedIn displays, even if it is relative,
   "3w" is a legal date.

## What it refuses

**Refusal 1, the last message is theirs.**

```
YOU OWE THE REPLY, NOT THEM
Last message in this thread: THEM, dated <date>, "<quoted>"
This thread did not stall on their side. The last word here is theirs, which
means the pending action is your reply, not a revival message to draw one out
of them. Answer what they said.
```

## Method

**Step 1, lay out the thread with dates.** Number every message, tag the
sender, print the date exactly as the thread showed it.

**Step 2, the last-message gate.** If the last message is from THEM, Refusal
1 fires. Otherwise the last message is YOU, and the thread qualifies for a
revival message.

**Step 3, find their last concrete detail.** Walking backward from the last
THEM message, find the most recent thing they said that is specific: a
number, a named thing, a stated situation, a date they mentioned, a plan they
described. A greeting or a one-word reply is not a concrete detail; keep
walking backward past those.

```
their last concrete detail: "<quoted span>"   from: M<n>, dated <date>
```

If no THEM message anywhere in the thread carries a concrete detail, print
`[NEEDS: one specific thing they said, anywhere in the thread]` and stop
before Step 4. There is nothing this unit can quote back.

**Step 4, the gap.** Print how much time sits between their last message and
today, using only the dates the thread shows:

```
gap: <their last message's date> to now, as the thread displays it
```

No day count is computed if the thread's own date format will not support
one. A relative label like "3w" is printed as-is, never converted into a
number of days that was not given.

**Step 5, write the two sentences.**

1. Names the concrete detail from Step 3, in language close to theirs, not a
   summary that drifts.
2. Asks one question that only makes sense if the detail is still current,
   not a generic "still interested" line.

No third sentence. No apology for following up. No mention of the gap length
inside the message itself; the gap is for the reader's own judgement about
whether to send it at all, not a line to put in front of them.

## Output format

```
# Revival for the thread with <their name>

## The thread, with dates
M1  YOU   <date>   "<message>"
M2  THEM  <date>   "<message>"
...

## Their last concrete detail
"<quoted>"   from: M<n>, dated <date>

## Gap
<the Step 4 line>

## The message
"<sentence one>"
"<sentence two>"
```

## Worked case

This is the fixture run. It is `fixtures/stalled-thread.md`, executed line by
line against the rules above.

```
## The thread, with dates
M1  THEM  6w   "Thanks for the file, I'm rebuilding our post-purchase flow this quarter and this is a good starting point."
M2  YOU   6w   "Glad it landed at the right time. What's the biggest gap in the flow right now."
M3  THEM  5w   "Probably the second email, nobody opens it, I think it's competing with our shipping notification."
M4  YOU   5w   "That's a fixable send-time problem most of the time. Want me to look at the sequence with you."

## Their last concrete detail
"Probably the second email, nobody opens it, I think it's competing with our
shipping notification."   from: M3, dated 5w

## Gap
gap: 5w to now, as the thread displays it

## The message
"You mentioned the second email in your post-purchase flow was getting buried
behind the shipping notification."
"Did you end up shifting the send time on it, or is it still sitting where it
was."
```

The last message in the thread is M4, from YOU, so Step 2 clears the thread
for a revival. The second fixture, `fixtures/thread-last-message-theirs.md`,
exercises Refusal 1: the final message is from THEM, and the run stops at
`YOU OWE THE REPLY, NOT THEM` before Step 3 runs.

## Edge cases

**Several concrete details sit recently in the thread, all from THEM.** Use
the most recent one only. A revival message built on two details reads as a
recap, and a recap is not what pulls a reply out of a quiet thread.

**The thread has only one message total, from YOU, nothing from THEM ever.**
The last message is YOU, so Step 2 clears it, but Step 3 then finds no THEM
message at all to search, so `[NEEDS: one specific thing they said, anywhere
in the thread]` fires. This is a different stop from Refusal 1: the thread
did not stall on their side because there is no "their side" yet, it stalled
before it started.

**Dates are missing entirely from the paste.** Print
`[NEEDS: the dates as the thread shows them]` beside the gap line and still
write the message; the message itself does not depend on the date.

**Their last concrete detail is a plan, not a problem** ("we're launching the
new flow in two weeks"). That still counts as concrete. The question in
sentence two asks about the plan's status, not about a problem, since the
unit quotes whatever specific thing they left, not only complaints.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a detail, a date, or a plan they did not state.
- Never mention how long it has been inside the message.
- Never write more than one follow-up.
- Never open with "just checking in" or "just following up," the generic form
  this unit exists to avoid, and never apologize for following up.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
