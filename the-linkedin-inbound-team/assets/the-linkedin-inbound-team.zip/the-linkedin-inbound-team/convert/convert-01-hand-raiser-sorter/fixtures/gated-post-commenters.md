# Fixture, gated post commenters

Invented for testing. Not a real post and not a record of any real people.
The gate keyword for this post is SWIPE. Pasted in the order the comments
appeared.

---

1. Dara Voss - Freelance copywriter for SaaS onboarding
   "SWIPE"

2. Marcus Iyer - Head of Content, Loft & Bramble
   "SWIPE, I've been rewriting our onboarding emails for three weeks and cannot get the second one right"

3. Priya Okonkwo - (no headline shown)
   "SWIPE please"

4. Callum Reyes - Operations Manager, Thistlewick Goods
   "SWIPE"

5. Naomi Shah - Founder, Birchfield Studio
   "Sending SWIPE now, also is this the same framework you used for the LinkedIn carousel post last month"

6. Ravi Chandran - Demand Gen Lead, Corvid Analytics
   "Can someone send me this, saw it on Priya's repost"

7. Dara Voss - Freelance copywriter for SaaS onboarding
   "SWIPE, appreciate it"
