# Fixture, names and headlines only, no comment text

Invented for testing. Exercises the input gap where only names and headlines
were copied from the post, and the comment text itself was left out.

---

1. Elin Roskam - Marketing Lead, Verrick Home
2. Tobias Ndlovu - Founder, Ashgrove Studio
3. Marguerite Sole - Ops Manager, Palladine Supply
