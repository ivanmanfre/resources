# Fixture, a comment thread with nobody asking anything

Invented for testing. No real people, no real companies, no record of any
engagement.

What this input is designed to exercise: a thread where the only question in the
paste was written by me.

---

My name as it appears on my own comments: Dana Okoro

## Post, "the four-line Friday note", posted 18 March

Ruth Alderman, Operations Lead at Halden Group
This is good.

Nils Ostberg, Managing Partner at Ostberg and Co
Agreed. We stopped sending the long one last year and nobody chased us for it.

Dana Okoro
Nils, what did you replace it with?

Tomas Berg, Founder at Kestrel Fit Studios
Saving this for Monday.

Marta Vine, Founder at Vine Studio
We send ours on Thursdays.
