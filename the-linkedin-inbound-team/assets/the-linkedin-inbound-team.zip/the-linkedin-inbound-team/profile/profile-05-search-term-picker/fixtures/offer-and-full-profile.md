# Fixture, an offer sentence and the whole profile text

Invented person, invented company. Exercises a full profile whose headline and
job title were written before the offer sentence was.

---

## Offer sentence

I get the month-end close out of spreadsheets for operations directors at
mid-size manufacturers, and onto one system their own team can run.

## The noun I would use if a buyer asked what I am

(not supplied)

## Profile text

### Headline

Founder & CEO @ Kettleworth | Helping businesses scale | Speaker | Ex-Verrow

### About

Fifteen years in operations and I still think the hardest part of any business is the handover.

I run Kettleworth, where we take the month-end close out of one person's head and put it into a system the rest of the team can run.

Before this, nine years in finance transformation at a consultancy.

I work mainly with operations directors at manufacturers between fifty and two hundred people.

If you want to talk about a close that does not depend on one person, my inbox is open.

### Current role

title: Founder, Kettleworth
description: We rebuild the month-end close so it runs on one system rather than a folder of spreadsheets. Mostly manufacturers, usually between fifty and two hundred people.

### Skills

Operations, Process Improvement, Financial Reporting, Team Leadership, Excel

### Licences and certifications

(none listed)

### Location

Leeds, United Kingdom
