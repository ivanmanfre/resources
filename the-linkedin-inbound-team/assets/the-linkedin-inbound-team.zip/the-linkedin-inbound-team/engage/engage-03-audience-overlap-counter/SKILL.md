---
name: engage-03-audience-overlap-counter
description: "Use before you invest time engaging under someone else's posts, to check whether their commenters are actually your buyer. Takes the visible commenter headlines from one of that creator's posts plus your offer sentence, and returns the buyer share of the sampled commenters with the division printed. Triggers on \"is this creator's audience my buyer\", \"check if these commenters match my ICP\", \"should I engage under this person's posts\", \"audience overlap check\", \"who's actually commenting on this post\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 03 of 30: the audience overlap counter

## What this does

Reads the headlines of the people who commented on one post by a creator
you are considering engaging under, and checks how many of them match the
buyer named in your offer sentence. This answers a different question from
whether the creator themselves is your buyer: it is a question about their
audience, not about them.

**The line only this unit produces:** the buyer share of the sampled
commenters, with the division printed.

## Required input

1. **The commenter headlines from one post**, one per line, exactly as they
   show on the comment list (name optional, headline required). At least
   ten.
2. **Your offer sentence.** One sentence naming who you work with and what
   changes for them.

Nothing else is read. No comment text, no reaction counts, no follower
counts for any commenter.

## What it refuses

**Refusal 1, fewer than ten headlines.**

```
SAMPLE TOO SMALL
headlines supplied: <n>

Ten is the floor because under that, one or two atypical commenters swing
the share by ten points or more. Paste more headlines from the same post,
or from a second post by the same creator, until you have at least ten.
```

**Refusal 2, no buyer named in the offer sentence.** Run the buyer test
(could you type this into LinkedIn's people search and get people back). If
the offer sentence fails it:

```
NO BUYER NAMED IN THE OFFER SENTENCE
offer sentence: "<as pasted>"

What was found instead: <the word that stood in for a buyer, e.g.
"businesses", "companies", "brands">

Nothing here can be matched against a headline until the buyer is a
searchable group. Supply one line: the job titles your buyer actually
holds.
```

## Method

**Step 1, extract the buyer descriptor.** Read the offer sentence for a job
title, function, or seniority band that passes the buyer test. Print:
`buyer descriptor: "<span>"`. If nothing passes, fire Refusal 2 and stop.

**Step 2, count the population.** `headlines pasted: <n>`. If under ten,
fire Refusal 1 and stop.

**Step 3, classify every headline.** Three classes, every headline gets
exactly one:

- `MATCH`: the headline names the same function as the buyer descriptor,
  within one seniority step (a Director, a Head of, a Manager, or a Lead in
  that same function all count as the same function at different levels).
- `NO MATCH`: the headline names a real function, clearly not the buyer
  descriptor's function.
- `UNREADABLE`: blank, or carries no function at all ("Open to
  opportunities", "Building something new", a name with no title, an
  emoji-only headline).

**Step 4, print the class rows.** Population stated above them:

```
headlines pasted: <n>
MATCH:       <n>   <list>
NO MATCH:    <n>   <list>
UNREADABLE:  <n>   <list>
```

Rows sum to the population stated in Step 2. No row is silently folded into
another.

**Step 5, the division.**

```
buyer share = MATCH / headlines pasted = <n> / <n> = <decimal> = <percent>
```

This denominator is every headline read, including the unreadable ones,
because an unreadable headline could not be confirmed either way and
folding it out would inflate the share. Read this number as a floor, not a
ceiling: some `UNREADABLE` rows may in fact be buyers whose headline just
does not say so.

Never divide by `MATCH + NO MATCH` only. That denominator excludes rows the
reader actually supplied, and the exclusion is exactly the counting error
this unit exists to catch.

## Output format

```
# Audience overlap
buyer descriptor: "<span>"
headlines pasted: <n>

## Classified
MATCH:       <n>
- "<headline>"
NO MATCH:    <n>
- "<headline>"
UNREADABLE:  <n>
- "<headline>"

## Share
buyer share = <n> / <n> = <decimal> = <percent>
read as a floor, not a ceiling: <n> UNREADABLE headlines could not be
confirmed either way
```

## Worked case

This worked case is a literal run of `fixtures/growth-creator-commenters.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Audience overlap
buyer descriptor: "revenue operations leaders"
headlines pasted: 12

## Classified
MATCH:       4
- "Director of Revenue Operations at Thistlebrook SaaS"
- "Head of RevOps, Brackwater Analytics"
- "Revenue Operations Manager at Kestrel Logistics"
- "RevOps Lead, Northbend Freight"
NO MATCH:    5
- "VP Marketing at Solent Retail"
- "Growth Lead at Ferring Health"
- "Founder, Voss & Rye"
- "Sales Ops Analyst, Delphine & Co"
- "Customer Success Manager at Ferndale Metals"
UNREADABLE:  3
- "Open to opportunities"
- "🚀🚀🚀"
- "Building something new"

## Share
buyer share = 4 / 12 = 0.33 = 33%
read as a floor, not a ceiling: 3 UNREADABLE headlines could not be
confirmed either way
```

`Sales Ops Analyst` is classed `NO MATCH`, not `MATCH`, because sales
operations and revenue operations are named as different functions on this
input; a title within one seniority step of the SAME function is what
qualifies, not an adjacent function.

## Edge cases

**All ten-plus headlines are UNREADABLE.** Print `MATCH: 0`, the share as
`0 / <n> = 0%`, and one line: `Every headline supplied was unreadable. This
share tells you nothing about this audience; it tells you the comment list
was pasted without expanding the headlines. Repaste with headlines
visible.`

**The offer sentence names two buyers.** Run the unit once per buyer, print
two full sections, one descriptor and one share each. Never merge two buyer
descriptors into one match test.

**The creator is also in the buyer descriptor's function.** Classify the
creator's own headline exactly like any commenter's, if it appears in the
pasted list. This unit answers a question about the audience, not about the
creator, and the creator's own row does not get special treatment.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a headline, a title, or a function a row did not carry.
- Never compute a share on fewer than ten headlines.
- Never divide by anything other than the full count of headlines pasted.
- Never state whether this creator is worth engaging under; this unit
  reports the audience only.
- No em dashes anywhere. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
