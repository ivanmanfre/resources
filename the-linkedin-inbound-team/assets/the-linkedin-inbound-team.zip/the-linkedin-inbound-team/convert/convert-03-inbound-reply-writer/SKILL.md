---
name: convert-03-inbound-reply-writer
description: "Use for the first reply back to someone who answered your delivery message with more than a thank-you. Takes the DM thread and the person's headline, and returns the first reply to a warm inbound message: one question, and no pitch. Triggers on \"how do I reply to this DM\", \"write my first reply to this lead\", \"what do I say back to this\", \"draft a reply to this inbound message\", \"reply to this warm DM\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 27 of 30: the inbound reply writer

## What this does

Writes exactly one reply to the most recent inbound message in a thread,
built around one question and nothing else. It never pitches on the first
reply, because a pitch this early is answering a question nobody has asked
yet.

**The line only this unit produces:** the first reply to a warm inbound
message, one question and no pitch.

## Required input

1. **The DM thread**, both sides, in order, up to and including their most
   recent message.
2. **Their headline**, copied from their profile or from how it shows under
   their name in the thread.

## What it refuses

**Refusal 1, nothing to reply to.** If the last message in the thread is from
YOU, i.e. there is no inbound message since your own last one, stop:

```
NOTHING TO REPLY TO YET
Last message in this thread: from YOU, "<quoted>"
There is no inbound message here to write a first reply to. If the thread has
gone quiet since your last message instead, that is Stalled Thread Reviver's
unit, not this one.
```

**Refusal 2, no pitch without a situation.** If their most recent message
states no situation of their own, only a thank-you, a greeting, or a
compliment with no content about their work, do not write a pitch. This is
not a stop; the unit still writes a reply, the situation question named in
Step 3, and prints why a pitch was not written:

```
NO SITUATION STATED YET
their message: "<quoted>"
Writing a pitch here would answer a question about your offer that they have
not asked. The reply below asks for the situation instead.
```

## Method

**Step 1, find the message being replied to.** The most recent message from
THEM. Quote it in full.

**Step 2, read what it carries.** Two facts, both printed:

```
situation stated: yes | no
if yes, quote: "<the span>"
question directed at you: yes | no
if yes, quote: "<the span>"
```

**Step 3, write the reply.** One of two shapes, chosen by what Step 2 found:

- **They asked you something directly.** Answer it in one plain sentence, no
  pitch attached, then close with one question about their situation. The
  answer comes first; leaving a direct question unanswered reads as dodging
  it.
- **They stated a situation with no direct question, or nothing at all.**
  Skip the answer sentence. Open by naming the one specific thing from their
  message the reply is responding to, then ask the situation question: what
  they are working on right now that the file or the post touches.

The question is always about them, never about booking a call and never about
your offer. Asking for a call belongs to Call Ask Writer, once there is a
stated problem to ask a call about.

**Step 4, check the pitch never entered.** Read the drafted reply back. If any
clause names what you sell, what you charge, or invites them into a service,
remove it and print `PITCH REMOVED: "<the clause>"`. This unit never ships a
pitch on the first reply, even when a pitch would have been easy to write.

**Step 5, name the headline's use.** Print one line saying whether the
headline changed anything about the reply, or `headline read, not used` when
it did not. The headline is required input so a stronger reply can use their
world when it is relevant, not so it can be repeated back at them.

## Output format

```
# First reply to <their name>

## What their message carries
situation stated: yes | no    "<span>" | none
question to you: yes | no     "<span>" | none

## The reply
"<the reply, as it would be sent>"

## Checks
pitch check: clean | PITCH REMOVED: "<clause>"
headline use: <one line>
```

## Worked case

This is the fixture run. It is `fixtures/inbound-reply-direct-question.md`,
executed line by line against the rules above.

```
## What their message carries
situation stated: yes    "our onboarding emails all get written by whoever has time that week"
question to you: yes     "is that something a swipe file actually fixes or do you need a system behind it too"

## The reply
"A swipe file fixes the sentences, not who is writing them each week. What
does the handoff look like right now when it's someone else's turn to write
the email."

## Checks
pitch check: clean, no offer sentence was supplied to check against
headline use: headline read, not used
```

The second fixture, `fixtures/inbound-reply-thanks-only.md`, exercises
Refusal 2. Their message is "Thank you, appreciate you sending it over," which
carries no situation and no question, so the reply written is the situation
question alone: "Glad it's useful. What are you working on with your
onboarding emails right now, the ones this would slot into." The file prints
`NO SITUATION STATED YET` above it.

## Edge cases

**Their message is a question unrelated to the file or the offer** (for
example, whether you are the same person who spoke at a conference). Treat it
as a direct question. Answer it only if the answer is inside the input;
otherwise print `[NEEDS: the answer to their question, in your own words]` in
place of the answer sentence, and still close with the situation question.

**They replied days after the delivery message went out.** The time gap is
not this unit's concern; a late reply to a delivery message is still a first
reply, and this unit runs on it the same as an immediate one. Timing a
follow-up on silence is Stalled Thread Reviver's job, not this one.

**Two headlines are available**, the one shown on their comment and a
different one now live on their profile. Use the one supplied and print which
source it came from.

**Their message states a situation but frames it as already solved**
("figured it out already, but thanks anyway"). That is `situation stated: yes`
with no open question. The reply still closes with a question, this time
about what fixed it, since a solved situation described in passing is still
the one specific thing the reply has to respond to.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a pitch on the first reply, regardless of how warm the message
  reads.
- Never invent a situation the message did not state.
- Never ask two questions. One reply, one question.
- Never claim what asking this question will produce.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
