# Fixture, thread carrying two problem statements

Invented for testing. Not a real thread and not a record of any real person.

Person: Etta Marchetti

---

M1 YOU: "Hey, here's the file."

M2 THEM: "Thanks, this is useful. I've been trying to fix our welcome
sequence for two months and every version I write gets a worse open rate than
the last one."

M3 YOU: "What have you changed between versions."

M4 THEM: "Mostly the subject lines. I'm honestly not sure if it's the subject
line, the send time, or the list itself at this point."
