---
name: profile-06-rival-claim-mapper
description: "Use when you want to know what a buyer holding your profile and a competitor's beside each other actually sees as different. Takes your profile text and one competitor's public profile text and returns the two-column claim ledger, the claim only they make and the claim only you make. Triggers on \"compare my profile to a competitor\", \"what does my rival claim that I do not\", \"how am I different from this person on LinkedIn\", \"map my claims against theirs\", \"why would a buyer pick me over them\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 06 of 30: the rival claim mapper

## What this does

Reduces both profiles to their claims, normalises the wording out of each claim
so that two sentences saying the same thing collapse into one key, and prints
what is left in each column.

**The line only this unit produces:** the two-column claim ledger, the claim only
they make and the claim only you make.

The result this unit is built to survive is an empty column. Where two profiles
sit in the same category, the claim sets often match, and an honest run returns
`YOU ONLY: empty`. That output is printed in full, with its own block, and it is
a finding rather than a failure. A run that fills the column with a difference of
wording has produced nothing, and the reader will act on it.

## Required input

1. **Your profile text.** Headline and About at minimum. Current role
   description if you have it. Paste it, do not summarise it.
2. **One competitor's public profile text**, the same fields, copied from their
   public page. One competitor per run.

Never a list of competitors, never a category. The whole unit is a comparison of
two texts, and three texts produce three ledgers, not one.

## What it refuses

**Refusal 1, their side is a headline.** Count the claims on their side after
Step 2. If everything they supplied is one headline line with no About and no
role description, stop:

```
HEADLINE ONLY, NO CLAIM SET
their headline: "<the line as pasted>"
their About: (not supplied)
claims found on their side: <n>

A headline is a label. It says what they call themselves, and it does not say who
they say the work is for, what they say they do, or what they say you are left
with.

Built from this, every claim of yours would land in YOU ONLY, and that column
would be a fact about how much of their page got copied rather than a fact about
them.

Go back to their profile and copy the About section, or the description under
their current role. Either one is enough.
```

**Refusal 2, no claim is written for either side.** This unit maps what the two
texts say. It never writes a claim to fill a column, never suggests one, and
never rewrites yours to make it distinct:

```
NO CLAIM WRITTEN
This unit reads two profiles and sorts what is in them. The column stays as it
came out.
```

Where a column is empty, the unit prints the empty block and a bracket naming
what the reader would have to go and get. Filling the bracket is the reader's
work, and it happens outside this unit.

## Method

**Step 1, split every line into one claim per assertion, before classing
anything.** A profile line usually carries three. `I build the forecast, run the
monthly meeting, and sit in on pricing` is three claims and gets three rows. A
headline splits at its separators, and a segment holding a list splits again into
one claim per item, so a two-segment headline routinely produces five. Never
class a line as a whole. Every claim carries its own status through the rest of this unit, and a
line that produced three claims can end with one in each column.

**Step 2, class each claim by type.** Five types, and nothing else is a claim:

| Type | What it asserts |
|---|---|
| `AUDIENCE` | Who the work is for, or the situation they are in |
| `SERVICE` | What is done |
| `OUTCOME` | What the buyer is left with |
| `METHOD` | How the work is run, including commercial terms |
| `STANDING` | Who is saying it: years, seats held, sales, qualifications |

A sentence asserting nothing (a hobby line, a hello, a quote) is not a claim.
Print it under `not a claim` with one word of reason, so nothing vanishes.

**Step 3, normalise each claim into a key.** The key is `<type>: <object in plain
words>`. Strip everything that is decoration:

| Strip | What goes in the key |
|---|---|
| Adjectives and intensifiers | `genuinely ambitious founders` becomes `founders` |
| Brand and product names | a named method becomes the thing the method does |
| Counts of years | `fifteen years in agency finance` becomes `years in agency finance` |
| Hedges | `I tend to help with` becomes `help with` |
| The company form of an audience | `agencies` becomes `agency owners` |
| Role synonyms | founder, owner, principal all become owner |
| Verb synonyms | help, support, partner with, work with all become help |

A key appearing twice inside the same profile counts once. Print the second
occurrence as `duplicate of <key>` and carry it no further.

**Step 4, match keys across the two profiles.** Two claims match when their keys
match, whether or not the sentences share a single word. Where the keys are not
identical, apply the mirror test before splitting them apart:

> If both lines were shown to your buyer with the names taken off, would they
> read them as promising the same thing. If yes, one key, and it is `SHARED`.

**Wording differences are not claim differences.** `sit in on pricing decisions`
and `being in the room when you set prices` are one key. This is the single place
this unit gets faked, so the rule is stated as a prohibition: a claim may not
enter an `ONLY` column on the strength of its phrasing.

**Step 5, the difference test, run on every claim before it enters an `ONLY`
column.** A claim is `YOU ONLY` when you can write this as a factual statement
about their supplied text:

```
Their profile makes no claim about <the object>.
```

If you cannot write that sentence, because their text does say something about
that object in other words, the claim is `SHARED`. Where one side's object sits
inside the other's, the keys do not match and both claims go to their own `ONLY`
column, each printing:

```
overlap note: narrower than their "<key>" | wider than their "<key>" | none
```

**Step 6, print the ledger.** Two columns, plus the shared list underneath them,
because the two columns cannot be read without knowing how big the shared set is.

**Step 7, the empty-column block.** Where an `ONLY` column comes out empty, print
this block in full rather than a dash:

```
YOU ONLY: empty
Claim keys your profile carries: <n>. All <n> have a match on theirs.

This is a finding. On the text alone, a buyer holding both profiles has nothing
in your wording to choose you by.

What it does not say: it does not say you do the same work. It says the two
pages say the same things. Anything that separates you is in work that is not
written down on your profile.

[NEEDS: one thing you did for a buyer that is written nowhere on your profile,
in one sentence, with the buyer's seat named]
```

The same block, with the sides swapped, prints where `THEY ONLY` is empty.

**Step 8, the counts.** Population, stated in words: the distinct claim keys
across both profiles after Step 3, counted once each. Every class gets its own
row, including a class at zero:

```
distinct claim keys across both profiles: <n>
SHARED:    <n> / <n> = <decimal>
THEY ONLY: <n> / <n> = <decimal>
YOU ONLY:  <n> / <n> = <decimal>
```

The three rows sum to the population. Print the raw division before the decimal.
No benchmark is printed and none exists: there is no share of shared claims that
is the right one, and naming one would be this unit inventing the standard it
then measures you against.

**The zero branch, in words.** Where either profile carries no claim at all after
Step 2, print the counts and no division, and name the side that carried nothing.
A ledger with an empty side is a fact about the paste. Refusal 1 catches the
commonest cause of it before this step runs.

## Output format

```
# Claim ledger

## THEY ONLY, the claim only they make
- <type>: <object>
  their line: "<verbatim>"
  overlap note: none | narrower than your "<key>" | wider than your "<key>"

## YOU ONLY, the claim only you make
- <type>: <object>
  your line: "<verbatim>"
  overlap note: <...>
  | the empty-column block from Step 7

## SHARED
- <type>: <object>
  yours:  "<verbatim>"
  theirs: "<verbatim>"

## Not a claim
- "<line>"   <reason>

## Counts
<the counts from Step 8>
```

## Worked case

This worked case is a literal run of `fixtures/two-profiles-same-category.md`,
checked line by line against the steps above. It is the same input, not a similar
one. It is the fixture chosen for the worked case because it produces the empty
column.

```
# Claim ledger

## THEY ONLY, the claim only they make
- AUDIENCE: studio owners
  their line: "Fractional CFO to agencies and studios"
  overlap note: none
- STANDING: finance director of a studio group
  their line: "latterly as FD of a studio group"
  overlap note: none

## YOU ONLY, the claim only you make
YOU ONLY: empty
Claim keys your profile carries: 9. All 9 have a match on theirs.

This is a finding. On the text alone, a buyer holding both profiles has nothing
in your wording to choose you by.

What it does not say: it does not say you do the same work. It says the two
pages say the same things. Anything that separates you is in work that is not
written down on your profile.

[NEEDS: one thing you did for a buyer that is written nowhere on your profile,
in one sentence, with the buyer's seat named]

## SHARED
- SERVICE: fractional CFO
  yours:  "Fractional CFO for creative agencies"
  theirs: "Fractional CFO to agencies and studios"
- AUDIENCE: agency owners
  yours:  "I work with creative agency owners"
  theirs: "I partner with agency founders"
- AUDIENCE: profitable and worried about payroll
  yours:  "profitable on paper and stressed about payroll"
  theirs: "look profitable and still worry about making payroll"
- SERVICE: cash flow
  yours:  "Cash flow"
  theirs: "cash"
- SERVICE: forecast
  yours:  "I build the forecast"
  theirs: "My work is the forecast"
- SERVICE: pricing
  yours:  "sit in on pricing decisions"
  theirs: "being in the room when you set prices"
- SERVICE: monthly finance meeting
  yours:  "run the monthly numbers meeting"
  theirs: "the monthly finance meeting"
- STANDING: years in agency finance
  yours:  "Fifteen years in agency finance"
  theirs: "Sixteen years in agency finance"
- METHOD: rolling monthly, no lock-in
  yours:  "No long tie-ins. Monthly, cancel any time."
  theirs: "Rolling monthly engagements, no lock-in."

## Not a claim
none

## Counts
distinct claim keys across both profiles: 11
SHARED:    9 / 11 = 0.818
THEY ONLY: 2 / 11 = 0.182
YOU ONLY:  0 / 11 = 0.000
```

Three of the shared rows are the rule in Step 4 doing its work, and each one is
where a run that read wording instead of claims would have manufactured a
difference: the forecast line, the pricing line, and the terms line share no
phrasing at all and carry the same key. `Fifteen` and `Sixteen` years is a
number, and the key strips it, so seniority is not a difference here either.

Both headlines split twice. Yours has two segments, and the second is a list, so
it produced five claims: `fractional CFO`, `agency owners`, `cash flow`,
`forecast` and `pricing`. Theirs produced the same five plus `studio owners`,
which is the claim that put a row in their column. The two About sections each
carry a sentence naming three services, and each of those produced three rows.

## Edge cases

**Both columns come out empty.** Print both empty blocks and the counts. Two
profiles with an identical claim set is the strongest version of this unit's
finding, and it survives being said plainly.

**Their profile makes a claim yours contradicts.** It is still `THEY ONLY` if
your profile makes no claim about that object, and `SHARED` if it makes the
opposite claim about the same object. Print `contradicts yours` on the row. A
contradiction is not a difference in what is claimed about, and a buyer scanning
two pages sees both of you talking about the same thing.

**A claim of theirs is an outcome yours never states.** That is a real `THEY
ONLY` row and it goes in the column. This unit does not tell you to add one. An
outcome claim you cannot stand behind is a worse position than an empty column.

**Their About is in another language.** Stop and say so in one line. A translated
claim is a claim this unit wrote, and every key in the ledger would then be built
on a translation nobody checked.

**Their profile is much longer than yours.** Print the counts and nothing else
about length. Their column being longer is a fact about how much they wrote, and
this unit prints no verdict on it.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write, suggest or rewrite a claim for either side. This unit sorts.
- Never put a claim in an `ONLY` column on the strength of its wording. The
  difference test in Step 5 has to pass in writing first.
- Never fill an empty column. Print the empty-column block.
- Never invent a claim their text does not carry, and never read a claim off
  their photo, their banner, their follower count or their job title alone.
- Never name a benchmark, a healthy share, or a target for any of the three
  counts.
- Never carry a claim forward from an earlier run against a different
  competitor.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
