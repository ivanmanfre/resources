---
name: convert-02-dm-intent-reader
description: "Use when a DM thread has come in and it is not yet obvious what the other person actually wants from you. Takes the DM thread, both sides, in the order it happened, and returns the intent verdict for the thread: asking for the file, asking for help, or selling, with the line that decided it quoted. Triggers on \"what does this person actually want\", \"read this DM for me\", \"is this a pitch or a real question\", \"what is this thread asking for\", \"decide what this DM is asking\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 26 of 30: the DM intent reader

## What this does

Reads a DM thread in order and states, in one verdict, what the sender is
doing right now: asking for the file, asking for help with a real situation,
or selling something of their own. Where one message carries more than one of
those at once, all of them are printed, and the verdict names the one that
decides how the reader replies next.

**The line only this unit produces:** the intent verdict for the thread, with
the line that decided it quoted.

## Required input

1. **The DM thread**, both sides, in the order the messages happened, with a
   marker for who sent which line, their name or "YOU".
2. Nothing else. No profile data beyond what is inside the thread itself, no
   company research, no follower count.

## What it refuses

**Refusal 1, one message from them cannot carry an intent.**

```
ONE MESSAGE, NO VERDICT
messages from them in this thread: 1
"<their one message, quoted>"

One line is not enough to tell asking-for-the-file apart from asking-for-help
apart from selling. All three can open with a sentence that reads politely.
Reply to it, let the thread run one more message, and read it again.
```

This fires on the count of messages FROM THEM only, regardless of how many the
reader has sent. A thread where the reader sent three messages and they sent
one still fires Refusal 1.

## Method

**Step 1, lay out the thread in order.** Number every message, tag the sender
YOU or THEM. The name in the title comes from the thread and from nowhere else:
the sender markers where they carry a name, or the name the thread is addressed
to inside a message. Where the markers are generic and no message names them,
print `[NEEDS: their name]` in the title rather than picking one.

**Step 2, tag every message from THEM, not only the most recent one.** Four
tags, closed list, and a single message can carry more than one:

| Tag | What it means | What it is not |
|---|---|---|
| `ASK-FILE` | asking for the asset, a link, a resend | thanking for a file already received |
| `ASK-HELP` | describing a situation of their own and asking about it, including asking whether you take on work like theirs | a compliment on the post with nothing about their own work |
| `SELLING` | offering their own product, service, content, platform, or a meeting to discuss any of those | asking whether YOU offer something |
| `SOCIAL` | a thank-you, a greeting, or an acknowledgment carrying no ask | n/a |

`SOCIAL` can sit alongside another tag on the same message. The other three
are mutually exclusive within one message: a message that reads as carrying
two of `ASK-FILE` / `ASK-HELP` / `SELLING` is split at the sentence where the
topic changes, and each half is tagged and printed on its own line under that
message number.

On its own line means literally that. A split message occupies two rows of the
thread layout, both carrying the same message number, each holding one half of
the text and that half's tag. It never occupies one row carrying both tags with
a note saying which half each belongs to: that row reads as one thing the person
said, and they said two.

**Step 3, the verdict rule.** Walk THEM's messages from the most recent
backward. The verdict is the tag of the first message, read backward, that
carries `ASK-FILE`, `ASK-HELP`, or `SELLING`. A message tagged only `SOCIAL`
is skipped for this purpose; a plain thank-you says nothing about what happens
next.

Where the deciding message was split into two halves under Step 2, the
verdict is decided by whichever half comes **last** inside that message. The
thread ends on that sentence, and the reader is replying to whatever the
sender left them with, not to the sentence before it.

If no message from THEM carries anything but `SOCIAL`, print instead of a
verdict:

```
VERDICT: SOCIAL ONLY
Every message from them in this thread is an acknowledgment. There is nothing
here that asks for anything, so there is nothing yet for this unit to route.
```

**Step 4, quote the deciding line.** Print the exact sentence, not the whole
message, that carries the tag named in the verdict.

**Step 5, print what the verdict did not carry, in two separate places.** A
verdict names one tag, and a thread usually carried more than one. Both of the
things it left behind get their own printed section, because they are different
things and folding them together is how the reader loses one of them.

- **Also in the deciding message.** Where Step 2 split the deciding message, the
  half that did not decide the verdict prints here with its own tag, quoted
  whole. This is not an earlier message. It arrived in the same breath as the
  one that won, and a reader who misses it replies to half of what was said.
  Where the deciding message was never split, this section prints `none`.
- **Earlier messages from them.** Every THEM message that came before the
  deciding message, with its tags, quoted whole as they wrote it. The deciding
  message is not one of them, in either half. Where the deciding message is
  their first, this section prints `none`.

## Output format

```
# Intent read for the thread with <their name> | [NEEDS: their name]

## The thread
M1  YOU   "<message>"
M2  THEM  "<message>"   tags: <tag, tag>
M<n>  THEM  "<first half>"    tags: <tag>
M<n>  THEM  "<second half>"   tags: <tag>
...

## Verdict
VERDICT: ASK-FILE | ASK-HELP | SELLING | SOCIAL ONLY
deciding line: "<quoted sentence>"   from: M<n>

## Also in the deciding message
M<n>: tags <...>   "<the half that did not decide it, quoted whole>"   | none

## Earlier messages from them
M<n>: tags <...>   "<the message, quoted whole>"   | none
```

## Worked case

This is the fixture run. It is `fixtures/thread-blended-intent.md`, executed
line by line against the rules above.

```
## The thread
M1  YOU   "Hey Renata, here's the swipe file: <link>. Let me know if it's useful."
M2  THEM  "Got it, thank you, this is exactly the kind of thing I never have time to build myself."   tags: SOCIAL
M3  YOU   "Glad it's useful. What are you working on at the moment."
M4  THEM  "Honestly I'm stuck on the onboarding sequence for a coaching cohort I run, open rates dropped by half after week two and I can't tell if it's the subject lines or the send time."   tags: ASK-HELP
M4  THEM  "Also, if you ever want a guest spot on my podcast about creator tools, I'd love to have you."   tags: SELLING

## Verdict
VERDICT: SELLING
deciding line: "Also, if you ever want a guest spot on my podcast about creator tools, I'd love to have you."   from: M4

## Also in the deciding message
M4: tags ASK-HELP   "Honestly I'm stuck on the onboarding sequence for a coaching cohort I run, open rates dropped by half after week two and I can't tell if it's the subject lines or the send time."

## Earlier messages from them
M2: tags SOCIAL   "Got it, thank you, this is exactly the kind of thing I never have time to build myself."
```

M4 carries both `ASK-HELP` and `SELLING`, so it takes two rows of the thread
layout, both numbered M4. Per Step 3's split rule the verdict follows the half
that comes last in the message, the podcast pitch, so the verdict is `SELLING`
even though the help request reads as the more urgent line. The ASK-HELP half
sits under "Also in the deciding message" rather than under "Earlier messages
from them", because M4 is the most recent message from her and nothing about it
is earlier. Both sections print, and between them the reader sees every fact the
verdict did not carry.

The second fixture, `fixtures/thread-single-message.md`, exercises Refusal 1.
It carries exactly one message from THEM ("Thanks so much, appreciate you
sending it over"), and the run stops at `ONE MESSAGE, NO VERDICT` before any
tagging happens.

## Edge cases

**A message asks only whether you take on new clients, no situation attached.**
Tag it `ASK-HELP` anyway and print `no situation stated` beside it. `ASK-HELP`
covers every message asking about working with you, whether or not it arrives
with a situation attached. A missing situation is a fact for Call Ask Writer
(convert-04) to work with later, not a reason to leave this message untagged.

**They send two messages back to back before you reply.** Number each one
separately; they are two rows, not one, even with no YOU message between them.
The verdict walk still starts from the most recent of the two.

**A message tagged `SELLING` is actually an invitation, not a sale** (a
podcast slot, a panel, a guest post). Tag it `SELLING` regardless. The tag
means "offering something of theirs", and an invitation with no dollar amount
attached still routes the reader into deciding whether to accept a pitch, not
into answering a question.

**Every message from them is `ASK-FILE`, repeated.** They asked for the file
more than once because the first reply never landed. The verdict is still
`ASK-FILE`, and the earlier-messages list shows the repetition so the reader
knows a resend, not a fresh reply, is what is actually owed.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a tag on a message the printed text does not support.
- Never collapse a message's two halves into a single tag when the sentences
  point in different directions, and never onto a single printed row either. Two
  halves, two rows, one tag on each.
- Never file the deciding message, or any half of it, under earlier messages.
  The half that did not decide the verdict has its own section.
- Never produce a verdict from a thread with fewer than two messages from
  THEM. Refusal 1 fires instead.
- Never state what the verdict means the reader should do next. That belongs
  to whichever unit the verdict routes to, not to this one.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
