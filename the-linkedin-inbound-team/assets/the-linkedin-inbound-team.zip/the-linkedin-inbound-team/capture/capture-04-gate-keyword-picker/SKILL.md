---
name: capture-04-gate-keyword-picker
description: "Use when a post is about to go up gated behind a comment keyword and you need the word plus the exact sentence that arms it. Takes the post draft and the keywords you have already used and returns the new keyword and the arming sentence, placed in the draft. Triggers on \"what comment keyword should I use\", \"pick a gate word for this post\", \"write the comment-reply arming line\", \"is this keyword already spent\", \"add the comment CTA to this draft\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 04 of 06: the gate keyword picker

## What this does

Reads a post draft, finds the concrete noun the draft already uses to name
the thing being given away, turns it into a comment keyword, checks it
against the words already run, and writes the exact sentence that arms it
inside the post body.

**The line only this unit produces:** the gate keyword plus the exact sentence
that arms it inside the post body.

## Required input

1. **The post draft**, pasted whole, exactly as written. The draft has to
   already name the asset somewhere in its own words; this unit does not
   invent what the asset is called.
2. **The keywords the reader has used before**, as a list.

## What it refuses

**Refusal, the word is already spent.** A gate word runs once and stays spent
forever, even on a different post. If the candidate keyword matches a used
keyword (case-insensitive), stop:

```
GATE KEYWORD ALREADY SPENT: <WORD>
This word was already run as a gate. A spent gate word is never reused,
because a reader who commented it before gets no signal that this is a new
post.

Other concrete nouns naming the asset in this draft: <list, or none>
[NEEDS: a concrete noun from the draft that is not on the used list, or a
revised draft]
```

This unit does not pick a second candidate on its own. Picking one would be a
guess about which unused word best represents the asset, and that guess
belongs to the reader.

## Method

**Step 1, find the sentence that names the asset.** Read the draft in order
and find the first sentence where the reader states they made, built, put
together, or are giving away a specific thing. Print that sentence, numbered.

**Step 2, list the concrete nouns in it.** From that sentence only, list every
concrete noun or short noun phrase naming the asset itself (not its topic, not
its benefit): a format word like "checklist", "template", "guide", "sheet",
"list". A word describing what the asset is about, rather than what it is,
does not count.

**Step 3, choose the candidate.** The candidate keyword is the shortest
single-word concrete noun from Step 2, uppercased. If Step 2 found more than
one single-word noun of equal length, print both and stop for the reader to
choose; this unit does not break that tie on its own, since both are equally
valid words already in the draft.

**Step 4, check against the used list.** Compare the candidate to every word
on the used list, case-insensitive, exact match only. A match fires the
refusal. No match, proceed.

**Step 5, write the arming sentence.** Exactly one sentence, in this shape:
`Comment <WORD> and I will send it over.` Insert it immediately after the
sentence found in Step 1, never at the top or bottom of the post regardless of
where those would read better, since the arming line has to sit next to the
thing it is arming.

**Step 6, print the full draft with the insertion marked.** So the reader can
see exactly where the line lands before they post it.

## Output format

```
# Gate keyword for this draft

## Asset-naming sentence
S<n>: "<sentence>"

## Concrete nouns found
<list>

## Keyword
<WORD>
checked against: <used list>
result: new, not on the used list | GATE KEYWORD ALREADY SPENT

## Arming sentence
"Comment <WORD> and I will send it over."
inserted after: S<n>

## Draft with insertion marked
<full draft text, with [ARMING SENTENCE INSERTED HERE] on its own line at the
insertion point>
```

## Worked case

This is the fixture run. It is `fixtures/draft-and-unused-word.md`, executed
line by line against the rules above.

```
## Asset-naming sentence
S1: "I built a one-page vetting checklist after losing a project to scope
creep last spring."

## Concrete nouns found
checklist

## Keyword
CHECKLIST
checked against: TEMPLATE, GUIDE, SWIPE
result: new, not on the used list

## Arming sentence
"Comment CHECKLIST and I will send it over."
inserted after: S1

## Draft with insertion marked
I built a one-page vetting checklist after losing a project to scope creep
last spring.
[ARMING SENTENCE INSERTED HERE]
Ten questions to ask before you quote a new client so you are not the one
holding the bag two months in. I have used it on every intake call since.
```

The second fixture, `fixtures/draft-and-spent-word.md`, fires the refusal.
Its used list carries `CHECKLIST`, the same word Step 3 selects, so the output
reads `GATE KEYWORD ALREADY SPENT: CHECKLIST`, and Step 2 found no second
single-word concrete noun in that draft, so the alternate line prints `Other
concrete nouns naming the asset in this draft: none`.

## Edge cases

**The draft names the asset with a two-word phrase and no single word works
alone** ("vetting checklist" split apart reads oddly as a comment word). Use
the full phrase as the candidate, with spaces removed, and print the
transformation: `"vetting checklist" -> VETTINGCHECKLIST`.

**The draft never says what the asset is, only that one exists** ("I made
something for this"). Step 2 finds no concrete noun. Print `NO ASSET NAMED IN
THIS DRAFT` and `[NEEDS: the sentence in the draft that names the asset]`.

**The reader already has an arming sentence in the draft.** Do not add a
second one. Print `ARMING SENTENCE ALREADY PRESENT: "<the existing line>"` and
stop, since two comment prompts in one post split the signal.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never propose a keyword that is not built from a word the draft itself
  already uses.
- Never reuse a spent keyword, on this post or a future one.
- Never insert the arming sentence anywhere other than immediately after the
  sentence that names the asset.
- Never invent what the asset is if the draft does not say.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
