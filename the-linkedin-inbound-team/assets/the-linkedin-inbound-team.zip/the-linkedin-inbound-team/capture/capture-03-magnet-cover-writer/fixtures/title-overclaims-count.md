# Fixture, a title that claims more than the contents list carries

Invented for testing. Not a real product. Exercises the padding refusal.

---

## The chosen title

The 20-Prompt Starter Pack for Freelance Copywriters

## The contents list, as the reader pasted it

1. Discovery call prompt
2. Scope-narrowing follow-up prompt
3. Objection-handling prompt, price
4. Objection-handling prompt, timeline
5. Revision-request prompt
6. Late-payment nudge prompt
7. Testimonial-ask prompt
8. Referral-ask prompt
9. Kickoff-brief prompt
10. Scope-creep flag prompt
11. Contract-renewal prompt
12. Project-close prompt
13. Case-study-ask prompt
14. Cold-outreach opener prompt
