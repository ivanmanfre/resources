# Fixture, two identical commenter lists

Invented for testing.

Note: exercises Refusal 2 - the same list pasted twice, name for name, in
the same order.

---

## Post 1
Marisol Fenn, Ops Lead at Thistlebrook
Dario Kessling, Founder at Voss & Rye
Tomasz Bilek, Head of Ops at Ferndale Metals

## Post 2
Marisol Fenn, Ops Lead at Thistlebrook
Dario Kessling, Founder at Voss & Rye
Tomasz Bilek, Head of Ops at Ferndale Metals
