---
name: content-01-first-line-writer
description: "Use when you have written a post and the opening line is the part you cannot get right. Takes the draft exactly as you wrote it and returns five opening lines, each under twelve words and each traceable to a numbered sentence of your own draft. Triggers on \"write me a better first line\", \"fix the opening of this post\", \"give me hook options for this draft\", \"my first line is weak\", \"what should this post open with\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 01 of 06: the first line writer

## What this does

Reads a draft you have already written, inventories the facts inside it, and
writes five opening lines that each point back at one of those facts by number.

**The line only this unit produces:** an opening line with a sentence id printed
beside it, naming the sentence of your own draft that the line is drawing on.

Nothing here invents material. If the five lines cannot be written from what the
draft carries, fewer than five are written and the shortfall is printed. An
opening line the body cannot pay off is the one failure this unit exists to stop,
so every line is tied to a sentence that pays it off.

## Required input

1. **The post draft**, pasted whole, exactly as written. Not a summary, not a
   description of it. The unit reads sentences and cannot read a paraphrase.
2. Nothing else. No audience data, no past post performance, no analytics.

If you want a fact used that is not in the draft, put it in the draft first.
A fact you say in the request and did not write in the post is not a legal
source, and Refusal 3 fires on it.

## What it refuses

**Refusal 1, no fact to open on.** If Step 2 finds zero facts in the whole
draft, print this and stop:

```
NO FACT IN THIS DRAFT
Sentences read: <n>   Sentences carrying a fact: 0

Every sentence in this draft asserts, and none of them report. There is nothing
here for an opening line to point at, so any line written now would be a claim
the body does not pay off.

What would change that, in your own words, one of:
[NEEDS: one thing that happened, with who was there and when]
[NEEDS: one number the draft can state]
[NEEDS: one thing somebody said, in their words]
[NEEDS: one named thing a reader could ask to see]

Add one of those to the draft and run this again.
```

**Refusal 2, nothing to read.** If the paste holds no complete sentence, print
`NO DRAFT SUPPLIED` and stop. No division is printed in this branch, because the
denominator would be zero.

**Refusal 3, an outside fact.** If a fact is offered in the request rather than
in the draft, print this and do not use it:

```
FACT NOT IN THE DRAFT: "<the fact as you gave it>"
An opening line built on it would promise something the post never delivers.
Put the sentence in the draft, then run this again.
```

## Method

**Step 1, number the sentences.** First mark where the draft starts, because
every count in this unit is a count of draft sentences and a paste often carries
more than the draft. A heading line opening with `#`, a horizontal divider line
(`---`), a file name, and every line sitting above the last divider in the paste
are scaffolding, not draft. They are not numbered and they are not counted
anywhere. Print one line naming what was set aside:

```
set aside before numbering: <n> non-blank lines above the last divider | none
```

Blank lines are not counted, so the figure is the same whichever way the paste
was wrapped. Where the paste carries no divider and no heading, nothing is set
aside and the line prints `none`.

Then split what remains at sentence ends and number them S1 upward. Print the
numbered list. Every later step cites these ids, so a run that skips the
numbering cannot be checked by anyone, including you. The denominator in Step 3
is fixed here, by a rule printed in this unit, and never by how much explanatory
prose happened to sit above the post.

**Step 2, the fact inventory.** Walk the sentences in order. Four fact types,
and only these four:

| Type | What counts | What does not |
|---|---|---|
| `EVENT` | something that happened, with an actor and a time or a place | a thing that generally happens |
| `NUMBER` | a figure the draft states | a quantity word with no figure, such as "several" |
| `OBJECT` | a thing a reader could ask to see, specific enough to point at: the pack they handed her, the file on your phone, the room | a bare category with no owner and no name, such as "a document", "processes", "the tools" |
| `QUOTE` | words the draft puts in somebody's mouth | your own summary of what they meant |

**Every sentence gets a printed row**, including the ones carrying nothing,
which print `FACT: none`. An `OBJECT` counts on the sentence that first names
it and nowhere after, so a thing mentioned four times is one fact, not four.
A sentence carrying two fact types prints both on its row; one row never
swallows a second fact.

**Step 3, the gate, with the population stated.** The population is every
sentence Step 1 numbered, counted once each, including the ones carrying no
fact. It is the sentences of the post and nothing that sat above the divider, so
the denominator cannot be moved by the length of a note wrapped round the paste.
Print:

```
population: sentences in the draft, after Step 1 set the scaffolding aside
sentences carrying at least one fact: <n> / <n> = <decimal>
```

If the numerator is 0, Refusal 1 fires. If the denominator is 0, Refusal 2 has
already fired and no division is printed. No benchmark is printed for this
figure, because there is no honest one; it is here so you can see how much of
the draft is reporting and how much is asserting.

**Step 4, the five shapes.** Write one candidate per shape, in this order:

| Shape | What it is | Source it needs |
|---|---|---|
| `THE EVENT` | the thing that happened, stated flat | an `EVENT` row |
| `THE NUMBER` | the figure, standing on its own | a `NUMBER` row |
| `THE OBJECT` | the named thing, in place | an `OBJECT` row |
| `THE WORDS` | what somebody said, verbatim | a `QUOTE` row |
| `THE MOMENT BEFORE` | the situation the event walked into | an `EVENT` row plus one other row |

Every candidate prints the sentence id it draws on. Every noun in a candidate
must appear somewhere in the draft; a noun that does not appear is an invention
and the candidate is rewritten.

`THE WORDS` ships the words of the `QUOTE` row and nothing else, in the draft's
own wording, with a capital on the first word and a full stop at the end. It
carries no quotation marks of its own. The output format puts quotation marks
round all five lines, and on this one line those marks are what show the sentence
is theirs and not yours.

**Step 5, when a shape has no source.** A shape with no matching row is not
filled with something adjacent. Two legal moves, in this order:

1. If another fact of a type already used is still unused, write a second
   candidate of that type from a different sentence and print
   `SHAPE UNAVAILABLE: no <type> in the draft, second <type> line written from S<n>`.
2. If every fact in the draft has been used and there are still fewer than five
   candidates, stop at the number you have and print
   `[NEEDS: one more fact from you, of any of the four types]`
   with the count you shipped. Four honest lines beat five with a made-up one.

**Step 6, word count each candidate.** Words are whitespace-separated tokens. A
hyphenated compound is one word. A figure is one word. Punctuation attached to a
word adds nothing. Print the count beside every candidate. A candidate over
eleven words is cut down or dropped, and it is never shipped over the cap with
the count hidden.

**Step 7, read your own opening back.** Quote S1 verbatim. Print whether it
carries a fact, from the Step 2 row. If any candidate draws on the same sentence
as S1, print `SAME FACT AS YOUR OPENING` beside that candidate, so you know it is
a rewording of what you have rather than a different opening.

This step reads your draft, not the lines this unit wrote, which is why it can
return something you did not already know.

## Output format

```
# Opening lines for <draft first three words>

set aside before numbering: <n> lines above the last divider | none

## The draft, numbered
S1  <sentence>
S2  <sentence>
...

## Fact inventory
S1  FACT: none
S2  EVENT: <the event>   NUMBER: <the figure>
S3  NUMBER: <the figure>   OBJECT: <the thing>
...

population: sentences in the draft, after Step 1 set the scaffolding aside
sentences carrying at least one fact: <n> / <n> = <decimal>

## The five
1. THE EVENT          "<line>"   words: <n>   from: S<n>
2. THE NUMBER         "<line>"   words: <n>   from: S<n>
3. THE OBJECT         "<line>"   words: <n>   from: S<n>
4. THE WORDS          "<line>"   words: <n>   from: S<n>
5. THE MOMENT BEFORE  "<line>"   words: <n>   from: S<n>, S<n>

shapes unavailable: <list, or none>
lines shipped: <n>

## Your current opening
S1: "<verbatim>"
carries a fact: yes | no
candidates drawing on the same fact: <list, or none>
```

## Worked case

This is the fixture run. It is `fixtures/draft-with-facts.md`, executed line by
line against the rules above, and every count below was recounted from the
fixture text rather than remembered.

```
set aside before numbering: 5 non-blank lines above the last divider

## The draft, numbered
S1  There is something worth saying about how service businesses handle handover.
S2  Last Tuesday I sat with a nine-person studio while they walked a new hire through their client onboarding.
S3  The pack they handed her ran to eleven pages.
S4  She read two of them and then asked the person next to her.
S5  Her exact words were, "is there a shorter version of this somewhere".
S6  There was.
S7  It lived in a Slack thread from March.
S8  We spent the afternoon pulling the Slack thread into a one-page card and deleting the rest.
S9  The next new hire will get the card.
S10 Handover is a document problem before it is a people problem.

## Fact inventory
S1  FACT: none
S2  EVENT: sat with a studio, last Tuesday   NUMBER: nine-person
S3  NUMBER: eleven pages   OBJECT: the pack
S4  EVENT: she read two pages and asked the person next to her   NUMBER: two
S5  QUOTE: "is there a shorter version of this somewhere"
S6  FACT: none
S7  OBJECT: a Slack thread from March
S8  EVENT: spent the afternoon making a one-page card   OBJECT: the one-page card
S9  FACT: none   (the card was first named at S8)
S10 FACT: none

population: sentences in the draft, after Step 1 set the scaffolding aside
sentences carrying at least one fact: 6 / 10 = 0.6

## The five
1. THE EVENT          "Last Tuesday I sat in on a handover."               words: 8   from: S2
2. THE NUMBER         "The onboarding pack ran to eleven pages."           words: 7   from: S3
3. THE OBJECT         "The shorter version was in a Slack thread from March."  words: 10   from: S7
4. THE WORDS          "Is there a shorter version of this somewhere."     words: 8   from: S5
5. THE MOMENT BEFORE  "A new hire read two pages of an eleven-page pack."  words: 10   from: S4, S3

shapes unavailable: none
lines shipped: 5

## Your current opening
S1: "There is something worth saying about how service businesses handle handover."
carries a fact: no
candidates drawing on the same fact: none
```

The second fixture, `fixtures/draft-with-no-facts.md`, fires Refusal 1. Its Step
3 line reads `sentences carrying at least one fact: 0 / 5 = 0.0`, and no
candidates are written.

## Edge cases

**The draft is one sentence long.** Run it. One sentence can carry a fact, and a
one-sentence draft with a fact in it gets however many candidates that fact
supports, printed with the shortfall note.

**Two sentences carry the same event.** Cite the earlier one and print
`also in S<n>`. The later mention is not a second fact.

**A figure appears inside a quote.** It counts as `NUMBER` on that row and the
row also prints `QUOTE`, so both shapes can draw on it.

**The draft is somebody else's writing.** Stop. This unit rewrites your own
opening, and an opening line built over another person's account puts their
sentence under your name.

**A candidate is stronger at thirteen words.** Ship it at eleven or drop it. The
cap is the only thing keeping the line from becoming the first paragraph, and a
cap you move on request is not a cap.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent an event, a number, a name, a date, a quote or an object the
  draft did not carry.
- Never write an opening line whose sentence id you cannot print.
- Never make a fact sharper than the draft made it. If the draft says "a few
  pages", the line says "a few pages", and `[NEEDS: the page count]` is printed
  beside it.
- Never rank the five or name a winner. The reader picks; a ranking here would be
  a guess about their audience, and no audience data went into this unit.
- Never claim what an opening line will do to a post's performance.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
