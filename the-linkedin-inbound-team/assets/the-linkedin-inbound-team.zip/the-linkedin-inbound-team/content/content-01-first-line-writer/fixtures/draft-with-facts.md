# Fixture, a post draft with facts in it

Invented for testing. Not a real post, not a real company, not a record of any
engagement.

Exercises the fact inventory, the five shapes and the read-back of your own
opening.

---

There is something worth saying about how service businesses handle handover.
Last Tuesday I sat with a nine-person studio while they walked a new hire
through their client onboarding. The pack they handed her ran to eleven pages.
She read two of them and then asked the person next to her. Her exact words
were, "is there a shorter version of this somewhere". There was. It lived in a
Slack thread from March. We spent the afternoon pulling the Slack thread into a
one-page card and deleting the rest. The next new hire will get the card.
Handover is a document problem before it is a people problem.
