# Fixture, a post draft with nothing in it to open on

Invented for testing. Not a real post and not a record of any engagement.

Exercises Refusal 1.

---

Handover is one of those areas where good intentions go to die. Everybody
agrees it matters and almost nobody treats it as real work. The result is
predictable enough that it barely needs saying. New people arrive, they are
given a document, and the document does the job of a conversation that nobody
had time for. The fix is a decision about what somebody needs in their first
week, and that decision is the part nobody schedules.
