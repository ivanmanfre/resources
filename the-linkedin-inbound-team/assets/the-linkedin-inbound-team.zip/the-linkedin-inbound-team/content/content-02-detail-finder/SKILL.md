---
name: content-02-detail-finder
description: "Use when a draft reads well and says nothing you could be held to. Takes the post draft you wrote and returns one question per claim the draft never grounds, with the claim quoted verbatim above it. Triggers on \"this post feels vague\", \"what am I asserting without proof\", \"make this draft specific\", \"which lines here are hand-waving\", \"what questions should I answer in this post\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 02 of 06: the specific detail finder

## What this does

Splits a draft into rows, separates the sentences that report from the sentences
that assert, and for every assertion the draft never carries, writes the one
question whose answer would carry it.

**The line only this unit produces:** a question addressed to the writer,
printed under the verbatim claim it belongs to, naming which of five kinds of
grounding it is asking for.

This unit writes no post copy, no rewrite and no softened version of your claim.
Softening a claim you cannot ground produces a sentence you also cannot ground,
in weaker language. The output is a short list of things to go and remember.

## Required input

1. **The post draft**, pasted whole, as written.
2. Nothing else. No audience data, no analytics, no past performance.

## What it refuses

**Refusal 1, every claim is already carried.** If Step 4 leaves no ungrounded
claim, print this and write no questions:

```
NOTHING UNGROUNDED HERE
Claim rows: <n>   Ungrounded: 0

Every claim in this draft has an account behind it in the same draft. The rows
that carry each one are printed above. No questions are written, because a
question written now would be asking you for something the post already says.
```

**Refusal 2, no claim in the paste.** If Step 3 produces zero claim rows, print
this and stop. No division is printed, because the denominator is zero:

```
NO CLAIM ROWS IN THIS DRAFT
Rows: <n>   Claim rows: 0   Account rows: <n>   Aside rows: <n>

This draft reports and does not assert. There is nothing here for this unit to
question. If you expected a claim in it, the claim is in your head and not on
the page, which is its own finding.
```

**Refusal 3, answering for you.** If asked to fill in the answers, print this
and stop:

```
THE ANSWERS ARE NOT IN THE INPUT
A detail supplied here would be one I made up, printed in your voice, in a post
with your name on it. Answer the questions from memory and paste the draft again.
```

## Method

**Step 1, number the sentences.** Split at sentence ends, number S1 upward,
print the list.

**Step 2, split before classing.** A sentence carrying two separate facts joined
by "and", "but", a semicolon or a comma splice is split into `S<n>a` and
`S<n>b` before anything is classed. Print the split rows. One row never carries
two statuses, and one status never swallows a second fact. Every later count is
over rows, never over sentences, and the two totals are printed separately so
the difference is visible.

**Step 3, class every row.** Three classes, every row printed:

| Class | What it is | Test |
|---|---|---|
| `CLAIM` | asserts something true beyond this draft's own story | it would still be asserting if you deleted every other sentence |
| `ACCOUNT` | reports a specific thing that happened, with an actor | you could be asked "when was that" and have an answer |
| `ASIDE` | neither: a transition, an address to the reader, a note about the draft | nothing is asserted and nothing is reported |

A claim that appears inside a `QUOTE` belongs to the person quoted. Route it out
with one line, `SPOKEN BY <who>, not audited here`, and leave it alone.

**Step 4, the grounding test, run per claim row.** Two parts, both printed, and
both must pass:

1. **The subject noun.** Print the head noun of the thing the claim asserts
   about. Then list every `ACCOUNT` row containing that noun, in singular or
   plural form. If none contains it, the verdict is `UNGROUNDED` and the printed
   reason is `no account names <noun>`.
2. **The happening.** Of the accounts that name it, does any show the thing the
   claim says happens? Print the account id and the fragment that shows it, or
   print `shares the noun, does not carry the happening` with one line saying
   what the account shows instead.

`GROUNDED` needs both. Anything else is `UNGROUNDED`. Print the verdict on every
claim row, including the grounded ones, so the count below has a printed row
behind every unit of it.

**Step 5, the count, with the population stated.** The population is the claim
rows after splitting, counted once each. Accounts and asides are counted and
printed, and they sit outside the division, because they are not claims and can
never reach the numerator:

```
population: claim rows after splitting, counted once each
claim rows: <n>
UNGROUNDED: <n> / <n> = <decimal>
GROUNDED:   <n> / <n> = <decimal>
account rows: <n>   aside rows: <n>   (counted, outside the division above)
```

If claim rows is 0, Refusal 2 has already fired and no division is printed. No
benchmark is printed for this figure. There is no correct share of ungrounded
claims, and inventing one would be the same move this unit exists to find.

**Step 6, one question per ungrounded claim.** Quote the claim verbatim above
its question. Every question:

- asks for exactly one of five kinds of grounding, and prints which:
  a named person or company, a dated or sequenced event, a number, a quoted
  line, a named object
- names the claim's own subject noun, so the answer lands on that claim
- is answerable from memory in one sentence
- never asks why you believe it, never asks how you feel about it, and never
  offers a candidate answer

One question per claim row. Two questions on one claim is a sign the claim was
two claims, in which case go back to Step 2 and split it.

**Step 7, the repeat check, pointed at the draft.** If two claim rows assert the
same thing in different words, print both and mark the pair `SAME CLAIM TWICE`.
One question covers the pair. A claim stated twice reads as emphasis and is
questioned once.

## Output format

```
# Ungrounded claims in <draft first three words>

## Rows
S1   CLAIM     "<verbatim>"
S2   ACCOUNT   "<verbatim>"
S3a  ACCOUNT   "<verbatim>"
S3b  ACCOUNT   "<verbatim>"
...
sentences pasted: <n>   rows after splitting: <n>

## Grounding
S<n>  subject noun: <noun>
      accounts naming it: <ids, or none>
      happening carried: yes, S<n> "<fragment>" | no, <what it shows instead>
      verdict: GROUNDED | UNGROUNDED
...

## Counts
<the block from Step 5>

## The questions
> "<claim, verbatim>"   S<n>
asks for: <one of the five kinds>
Q: <the question>

...

## Routed out
- "<quoted claim>"   SPOKEN BY <who>, not audited here
```

## Worked case

This is the fixture run. It is `fixtures/draft-mixed-claims.md`, executed line by
line against the rules above.

```
## Rows
S1   CLAIM     "Client work goes quiet in month three."
S2   ACCOUNT   "In March a client asked me what the retainer had bought her."
S3   ACCOUNT   "I did not have a page to send back."
S4a  ACCOUNT   "Since then we send a Friday note listing the week's work"
S4b  ACCOUNT   "it takes about twenty minutes"
S5   ACCOUNT   "She replied to the second note asking for the invoice a week early."
S6   CLAIM     "The note gets read."
S7   CLAIM     "Visibility is what keeps a retainer alive."
S8   CLAIM     "Nobody reads a monthly report anyway."
sentences pasted: 8   rows after splitting: 9

## Grounding
S1  subject noun: work
    accounts naming it: S4a
    happening carried: no, S4a shows a note going out and nothing going quiet in it
    verdict: UNGROUNDED
S6  subject noun: note
    accounts naming it: S4a, S5
    happening carried: yes, S5 "She replied to the second note"
    verdict: GROUNDED
S7  subject noun: visibility
    accounts naming it: none
    happening carried: no account names visibility
    verdict: UNGROUNDED
S8  subject noun: report
    accounts naming it: none
    happening carried: no account names report
    verdict: UNGROUNDED

## Counts
population: claim rows after splitting, counted once each
claim rows: 4
UNGROUNDED: 3 / 4 = 0.75
GROUNDED:   1 / 4 = 0.25
account rows: 5   aside rows: 0   (counted, outside the division above)

## The questions
> "Client work goes quiet in month three."   S1
asks for: a dated or sequenced event
Q: On the engagement you have in mind, what was the last thing you sent before
the work went quiet, and which month was that?

> "Visibility is what keeps a retainer alive."   S7
asks for: a quoted line
Q: What did a client say to you at the point the work became visible to them,
in their words?

> "Nobody reads a monthly report anyway."   S8
asks for: a named person or company
Q: Who told you they had not read your monthly report?

## Routed out
none
```

The second fixture, `fixtures/draft-all-grounded.md`, fires Refusal 1: it splits
to 8 rows, its one claim row is grounded by S4b ("their operations lead replied
to the note within the hour"), and the count line reads
`UNGROUNDED: 0 / 1 = 0.0`. The third, `fixtures/draft-no-claims.md`, fires
Refusal 2: rows 5, claim rows 0, and no division is printed.

## Edge cases

**A claim about yourself.** Class and question it the same way. "I am slow at
this" is an assertion, and the question asks for the dated instance.

**A claim in the form of a question.** A rhetorical question that asserts is a
claim. Print it as a claim row and note `ASKED, NOT STATED`.

**The subject noun is a pronoun.** Resolve it to the noun it stands for, print
the resolution, and if two nouns are equally available print
`[NEEDS: which of <noun> or <noun> this line is about]` and do not guess.

**A claim carrying a number.** It still needs an account. A number inside the
claim sentence is the claim, and a number inside an account row is what carries
it. Do not let the claim ground itself.

**An account that grounds a claim it never names.** If you are certain an
account is the instance and it does not contain the subject noun, the honest
output is `UNGROUNDED` and a question asking you to name the thing in the post.
That missing noun is why the reader could not see the connection either.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never answer your own question, never suggest a likely answer, never write an
  example answer.
- Never rewrite a claim. This unit questions, it does not draft.
- Never soften a claim into a hedge. A hedged claim needs the same account.
- Never invent an account, a date, a name, a number or a quote the draft did not
  carry.
- Never count sentences where the format asks for rows, and never print one
  status on a row carrying two facts.
- Never claim what answering the questions will do to a post's performance.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
