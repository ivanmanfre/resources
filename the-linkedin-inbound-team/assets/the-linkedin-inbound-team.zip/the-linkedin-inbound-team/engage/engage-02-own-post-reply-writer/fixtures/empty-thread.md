# Fixture, an empty comment thread

Invented for testing.

Note: exercises Refusal 1.

---

## Comment thread

(no comments yet)
