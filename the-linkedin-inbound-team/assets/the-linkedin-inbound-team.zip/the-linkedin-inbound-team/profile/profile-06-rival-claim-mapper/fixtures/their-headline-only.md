# Fixture, a full profile of yours against a competitor's headline

Invented people, invented companies. Exercises the case where the competitor's
page was screenshotted from a search result and nothing below the name was
copied.

---

## YOUR PROFILE

### Headline

Fractional CFO for creative agencies | Cash flow, forecasting, pricing

### About

I work with creative agency owners who are profitable on paper and stressed about payroll.

I build the forecast, run the monthly numbers meeting, and sit in on pricing decisions.

Fifteen years in agency finance before going independent.

No long tie-ins. Monthly, cancel any time.

---

## THEIR PROFILE

### Headline

Fractional CFO | Agencies and studios

### About

(not copied)

### Current role

(not copied)
