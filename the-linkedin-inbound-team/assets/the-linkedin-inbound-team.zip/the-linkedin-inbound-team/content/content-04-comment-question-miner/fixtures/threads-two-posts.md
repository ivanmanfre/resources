# Fixture, comment threads under two of my own posts

Invented for testing. No real people, no real companies, no record of any
engagement.

What this input is designed to exercise: one comment carrying two questions, one
person asking on both posts, and my own replies sitting in the same paste.

---

My name as it appears on my own comments: Dana Okoro

## Post 1, "the file of questions people ask twice", posted 4 March

Tomas Berg, Founder at Kestrel Fit Studios
Do you keep the file in one place or per client? Ours is scattered across three
tools and I cannot find anything.

Dana Okoro
One file, one phone note.

Ines Vall, Head of New Business at Marlowe and Fenn
How do you decide what makes it into the file? And do you ever take things out?

Ruth Alderman, Operations Lead at Halden Group
Love this.

Kwame Osei, Founder at Osei Digital
What do you do when the same question comes from a client rather than a
prospect?

## Post 2, "the four-line Friday note", posted 18 March

Tomas Berg, Founder at Kestrel Fit Studios
Do you keep the note in one place or does each client get their own? Same
question as last time, sorry.

Ines Vall, Head of New Business at Marlowe and Fenn
Would you share the four lines you use?

Dana Okoro
Ines, four lines: what shipped, what is next, what I need from you, what
changed. Does that answer it?

Nils Ostberg, Managing Partner at Ostberg and Co
This is the second time I have seen this idea this week.

Ruth Alderman, Operations Lead at Halden Group
Can you show what the note looks like when there is nothing to report?

Marta Vine, Founder at Vine Studio
Do you keep one file for everything or one per client? Mine is one per client
and it is a mess.
