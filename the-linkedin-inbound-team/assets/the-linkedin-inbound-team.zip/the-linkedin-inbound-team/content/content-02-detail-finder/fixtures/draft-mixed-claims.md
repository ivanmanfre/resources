# Fixture, a draft mixing claims with an account

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: a sentence carrying two facts joined by
"and", which has to be split before anything is classed.

---

Client work goes quiet in month three. In March a client asked me what the
retainer had bought her. I did not have a page to send back. Since then we send
a Friday note listing the week's work, and it takes about twenty minutes. She
replied to the second note asking for the invoice a week early. The note gets
read. Visibility is what keeps a retainer alive. Nobody reads a monthly report
anyway.
