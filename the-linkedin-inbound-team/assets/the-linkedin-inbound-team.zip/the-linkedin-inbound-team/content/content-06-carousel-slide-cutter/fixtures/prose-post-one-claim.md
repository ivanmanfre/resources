# Fixture, a post that says one thing five times

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: prose with nothing in it that happened,
so there is no sequence to cut along.

---

Consistency is what makes any of this work. If you show up every week, people
expect you. If you disappear, they forget. That is the whole thing. Consistency
beats intensity and it always has.
