---
name: profile-05-search-term-picker
description: "Use when buyers who need exactly what you do never arrive on your profile from LinkedIn search. Takes your offer sentence and your full profile text and returns ten search phrases a buyer types, each mapped to the profile field it has to appear in. Triggers on \"what keywords should be on my LinkedIn profile\", \"how do buyers find me on LinkedIn search\", \"SEO for my LinkedIn profile\", \"what words am I missing on my profile\", \"where do I put my keywords\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 05 of 30: the search term picker

## What this does

Works out what a buyer types into LinkedIn search when they are looking for the
thing you do, then says which field of your profile each phrase has to sit in.

**The line only this unit produces:** the ten search phrases a buyer types, each
mapped to the profile field it must appear in.

This unit makes no claim about how LinkedIn orders search results. Nobody outside
LinkedIn can see that, and a unit that printed a ranking rule would be printing an
invention. What it does instead is smaller and checkable: it maps each phrase to
the field where a person who searched that phrase and landed on you would expect
to read it, and where you can write it without lying.

## Required input

1. **Your offer sentence.** One sentence naming who you work with and what is
   different for them afterwards.
2. **Your profile text, all of it.** Headline, About, current role title, current
   role description, skills, licences and certifications, location. Where a
   section is empty, write `(not written)` rather than leaving it out, because the
   difference between empty and not supplied changes the status this unit prints.
3. Optional: **the noun you would use if a buyer asked what you are.** One word or
   two. Supplying it fills two of the ten slots that nothing else can fill.

## What it refuses

**Refusal 1, no searcher.** Run the buyer test on the offer sentence. A buyer is
a group of people you could type into LinkedIn's people search and get people
back. `operations directors at mid-size manufacturers` passes. `the mid-market`,
`ambitious organisations`, `SMEs`, `businesses`, `the sector` and `the industry`
all fail, because a market is not somebody with a seat. If nothing in the offer
sentence passes:

```
NO SEARCHER NAMED
offer sentence: "<the sentence as pasted>"
what stood in for a buyer: "<the words>"

Search phrases are typed by a person. This sentence names a market, and a market
does not open a search box.

Supply one line: the job title of the last person who asked you about this work,
written the way it appears on their own profile.
```

Do not proceed by picking the likeliest job title in that market. That guess
becomes ten phrases and five field placements, and every one of them inherits it.

**Refusal 2, no phrase invented to fill a slot.** A slot whose words are not in
your input prints its own bracket and stays empty:

```
NOT BUILT
[NEEDS: <the exact word to supply>]
```

Ten slots exist because there are ten distinct things a buyer searches on. The
count is not a quota to be met.

## Method

**Step 1, read the offer sentence into spans.** Print the buyer span, the work
span and the situation span, each quoted. Fire Refusal 1 on a missing buyer.

**Step 2, walk the ten slots, in this order.** Each slot has a fixed job, a fixed
home field, and one rule for what may fill it. Words may only come from the
offer sentence, the profile text, or the optional noun.

| Slot | What a buyer is searching for | Home field |
|---|---|---|
| 1 | what you are, one noun | Headline |
| 2 | what you are, plus who it is for | Headline |
| 3 | the work, named | Current role title |
| 4 | the work, plus who it is for | About |
| 5 | the problem, in the words it gets called | About |
| 6 | the buyer's own job title, plus the work | Current role description |
| 7 | the tool or system, by name | Skills |
| 8 | the qualification a buyer filters on | Licences and certifications |
| 9 | the place, where the work is done in person | About |
| 10 | the second name for the work, used by buyers who call it something else | Current role description |

**Step 3, the noun test on slot 1.** A noun fills slot 1 only if it survives
this: could it be followed by `for <your buyer>` and still name somebody they
would hire. `Founder for manufacturers` fails. `Consultant for manufacturers`
passes. Print every noun in the profile you tested and rejected, with the test
result, so the reader can see their own title was considered. A former employer
is never a qualification and never fills slot 8.

**Step 4, the presence check, per slot.** For each built phrase, look in its home
field's supplied text. A phrase is `PRESENT` when every content word in it
appears somewhere in that field, adjacent or not. Otherwise `ABSENT`, and print
the exact words that are missing. Where the field's text was not supplied, print
`UNCHECKABLE` and `[NEEDS: the text of <field>]`.

**Step 5, the length rule.** A phrase over five words prints
`long: a buyer is more likely to type the first two or three words` and the short
form under it. Both stay printed. The long form is what your profile has to be
able to answer; the short form is what gets typed.

**Step 6, the field cap.** No field takes more than three phrases. A fourth
phrase landing on a full field prints `PARKED, <field> already carries three` and
names the field it would go to second. A field stuffed with every phrase reads to
a human as a field stuffed with every phrase, and a human is who arrives after
the search.

**Step 7, the Skills note.** The Skills field holds single items rather than
sentences, so a phrase mapped there enters as its separate words. Print that once
under any slot mapped to Skills.

**Step 8, print the census.** Population, stated in words: the ten slots this
format walks. Every status gets its own row, including the ones at zero:

```
slots: 10
BUILT, PRESENT in the home field:  <n>   <slot numbers>
BUILT, ABSENT from the home field: <n>   <slot numbers>
NOT BUILT, carries a bracket:      <n>   <slot numbers>
UNCHECKABLE, field not supplied:   <n>   <slot numbers>
```

The rows sum to ten. No percentage is printed anywhere in this unit. The
denominator would be ten because this format asks for ten, and not because your
profile has ten of anything, so a share of it would measure the format.

## Output format

```
# Search phrases and where they go

buyer: "<span>"   work: "<span>"   situation: "<span>"

## Slot <n>: <what a buyer is searching for>
phrase: "<the phrase>"      | NOT BUILT [NEEDS: <the word to supply>]
built from: "<span>" (<where in your input>)
home field: <field>
status: PRESENT | ABSENT, missing "<words>" | UNCHECKABLE

## Nouns tested for slot 1
- "<noun>"   <test result>

## Census
<the census from Step 8>
```

## Worked case

This worked case is a literal run of `fixtures/offer-and-full-profile.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Search phrases and where they go

buyer: "operations directors at mid-size manufacturers"
work: "get the month-end close out of spreadsheets"
situation: "onto one system their own team can run"

## Slot 1: what you are, one noun
phrase: NOT BUILT   [NEEDS: the one noun you would use if a buyer asked what you are]
home field: Headline

## Slot 2: what you are, plus who it is for
phrase: NOT BUILT   [NEEDS: the noun from slot 1] for mid-size manufacturers
home field: Headline

## Slot 3: the work, named
phrase: "month-end close"
built from: "the month-end close" (offer sentence, current role description)
home field: Current role title
status: ABSENT, missing "month-end close". The title reads "Founder, Kettleworth".

## Slot 4: the work, plus who it is for
phrase: "month-end close for manufacturers"
built from: "month-end close" (About), "manufacturers" (About)
home field: About
status: PRESENT

## Slot 5: the problem, in the words it gets called
phrase: "close depends on one person"
built from: "a close that does not depend on one person" (About)
home field: About
status: PRESENT

## Slot 6: the buyer's own job title, plus the work
phrase: "operations director month-end close"
built from: "operations directors" (About), "month-end close" (current role description)
home field: Current role description
status: ABSENT, missing "operations director"

## Slot 7: the tool or system, by name
phrase: "month-end close Excel"
built from: "Excel" (Skills), "month-end close" (offer sentence)
home field: Skills
status: ABSENT, missing "month-end close"
note: Skills holds single items, so this phrase enters as its separate words.

## Slot 8: the qualification a buyer filters on
phrase: NOT BUILT   [NEEDS: the qualification a buyer would filter on, or the word "none" if you hold none]
home field: Licences and certifications

## Slot 9: the place, where the work is done in person
phrase: "month-end close Leeds"
built from: "month-end close" (About), "Leeds" (Location)
home field: About
status: ABSENT, missing "Leeds". The location field carries it and the About does not.

## Slot 10: the second name for the work
phrase: "financial reporting for manufacturers"
built from: "Financial Reporting" (Skills), "manufacturers" (About)
home field: Current role description
status: ABSENT, missing "financial reporting"

## Nouns tested for slot 1
- "Founder"      "Founder for manufacturers" does not name somebody a buyer hires. Rejected.
- "Ex-Verrow"    a former employer, not a noun for what you are. Rejected.

## Census
slots: 10
BUILT, PRESENT in the home field:  2   slots 4, 5
BUILT, ABSENT from the home field: 5   slots 3, 6, 7, 9, 10
NOT BUILT, carries a bracket:      3   slots 1, 2, 8
UNCHECKABLE, field not supplied:   0
```

Three fields carry their cap or less: About takes slots 4, 5 and 9, which is
three, so nothing parked. The two empty slots are both empty for the same reason,
which is that this profile never says what its owner is, only who employs them.

## Edge cases

**Your job title is set by your employer and you cannot change it.** Slot 3 keeps
the current role title as its home field and prints one line saying the phrase
moves to the current role description if the title is fixed. Print both
placements. The reader knows which one they control.

**The work is entirely remote.** Slot 9 prints
`NOT BUILT [NEEDS: nothing, this work is not local]` and says so in one line.
A place phrase on remote work pulls in searchers who wanted somebody down the
road.

**Two phrases come out identical.** Print both slots with the same phrase and one
line saying the slots collapsed. Two slots wanting the same words is a finding
about the offer, and hiding it by inventing a variant for the second slot is the
padding this unit refuses.

**A phrase is already `PRESENT` in the wrong field.** Print `PRESENT` for the
field it belongs to only. Where the words appear in a different field instead,
print one line naming where they currently are. A phrase in the About that
belongs in the headline is not placed.

**The profile is in one language and the buyer searches in another.** Print the
phrases in the language of the input and one line saying the second language was
not supplied. Never translate a phrase. A translated search phrase is a guess
about what a buyer types, in a language this unit was not given.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a phrase to fill a slot. Ten slots is the shape of the format,
  never a quota.
- Never invent a job title for the buyer, a qualification, a tool, a place or a
  second name for the work.
- Never claim how LinkedIn orders search results, and never claim a phrase will
  produce a search position.
- Never write a phrase into a field where it would not be true of the reader.
- Never print a phrase without the span it was built from and where that span was.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
