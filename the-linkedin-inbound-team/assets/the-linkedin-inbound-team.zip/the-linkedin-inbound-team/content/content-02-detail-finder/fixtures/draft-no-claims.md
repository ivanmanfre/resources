# Fixture, a draft that reports and asserts nothing

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: a paste with no claim row at all, so
the denominator of the count is zero.

---

On Tuesday I sat in the back of a handover at a nine-person studio. The new hire
was given an eleven-page pack and she read two pages of it. She asked the person
next to her whether there was a shorter version somewhere. There was one, in a
Slack thread from March.
