# Fixture, a full About section made of career history and self-description

Invented person, invented employers. Exercises a full-length About written
entirely about its owner.

---

Award-winning commercial leader with a track record of delivering across complex, matrixed organisations.

I began my career at Hallidane, moving through commercial roles in three countries before joining Verrow as regional director.

Since then I have held senior positions across retail, logistics and professional services.

I am a builder of high-performing teams and a firm believer in servant leadership.

Outside work you will find me on a bike, usually going uphill slowly.

Always happy to connect with like-minded professionals.
