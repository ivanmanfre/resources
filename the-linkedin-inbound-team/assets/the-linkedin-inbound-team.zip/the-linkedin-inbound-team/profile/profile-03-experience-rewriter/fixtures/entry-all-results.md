# Fixture, an experience entry written as a list of achievements

Invented person, invented company. Exercises the activity gate on a long entry.

---

## Header, as it appears

VP Growth
Hallidane  ·  Full-time
Jun 2022 to Present
London, United Kingdom

## Body, as it appears

Doubled the size of the commercial function.
Best performing region two years running.
Recognised internally as a top-quartile leader.
Consistently exceeded targets across every quarter in post.
Trusted adviser to the executive team.
