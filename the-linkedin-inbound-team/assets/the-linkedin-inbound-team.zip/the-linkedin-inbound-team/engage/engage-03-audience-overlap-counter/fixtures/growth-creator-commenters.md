# Fixture, commenter headlines from a creator's post

Invented for testing. Not a real post, not a real creator, not a record of
any real person or company.

Note: exercises the standard classification path - a mix of MATCH, NO MATCH,
and UNREADABLE headlines, with the population at exactly the ten-headline
floor plus two.

---

Offer sentence: "I help revenue operations leaders fix pipeline reporting
before it reaches the board."

Commenter headlines, from one post by the creator, in the order they appear
on the comment list:

1. Director of Revenue Operations at Thistlebrook SaaS
2. VP Marketing at Solent Retail
3. Open to opportunities
4. Head of RevOps, Brackwater Analytics
5. Growth Lead at Ferring Health
6. 🚀🚀🚀
7. Revenue Operations Manager at Kestrel Logistics
8. Founder, Voss & Rye
9. Building something new
10. Sales Ops Analyst, Delphine & Co
11. Customer Success Manager at Ferndale Metals
12. RevOps Lead, Northbend Freight
