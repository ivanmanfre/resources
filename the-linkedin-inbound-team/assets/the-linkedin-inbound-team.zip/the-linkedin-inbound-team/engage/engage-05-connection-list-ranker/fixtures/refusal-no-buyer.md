# Fixture, an offer sentence with no nameable buyer

Invented for testing.

Note: exercises Refusal 1 - the offer sentence names a category, not a
searchable buyer.

---

Offer sentence: "I help businesses run better."

Connections, copied from the connections list screen:

1. Jonah Petrakis - Owner, Fenwick Family Dental
2. Aurelia Danesh - (no headline shown)
3. Btissam Kharrat - Practice Manager, Rourke Physiotherapy
