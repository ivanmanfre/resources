# Fixture, your profile and one competitor's, same category

Invented people, invented companies. Exercises a pair drawn from one category,
including a line on each side that names three services in one sentence.

---

## YOUR PROFILE

### Headline

Fractional CFO for creative agencies | Cash flow, forecasting, pricing

### About

I work with creative agency owners who are profitable on paper and stressed about payroll.

I build the forecast, run the monthly numbers meeting, and sit in on pricing decisions.

Fifteen years in agency finance before going independent.

No long tie-ins. Monthly, cancel any time.

---

## THEIR PROFILE

### Headline

Fractional CFO to agencies and studios | Forecasting, pricing, cash

### About

I partner with agency founders who look profitable and still worry about making payroll.

My work is the forecast, the monthly finance meeting, and being in the room when you set prices.

Sixteen years in agency finance, latterly as FD of a studio group.

Rolling monthly engagements, no lock-in.
