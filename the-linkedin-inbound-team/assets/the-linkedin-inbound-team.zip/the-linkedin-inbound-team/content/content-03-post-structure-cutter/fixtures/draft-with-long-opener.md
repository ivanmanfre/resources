# Fixture, a draft whose first sentence is longer than the fold budget

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: an opening sentence that runs past the
fold on its own, with a clause boundary inside it.

---

The thing nobody tells you about running a small studio is that the work you are
paid for and the work that keeps you paid are two different jobs, and the second
one only ever gets done in the gaps between the first one, usually late, usually
badly.

I have tried three ways of fixing that and only one of them held. The one that
held was a Thursday hour with the phone in another room. It is in the calendar
as a meeting with myself and nobody has ever asked what it is.
