# Fixture, blended intent

Invented for testing. Not a real thread and not a record of any real person.
Person: Renata Solis. Exercises a message that carries two tags at once.

---

M1 YOU: "Hey Renata, here's the swipe file: <link>. Let me know if it's useful."

M2 THEM: "Got it, thank you, this is exactly the kind of thing I never have time to build myself."

M3 YOU: "Glad it's useful. What are you working on at the moment."

M4 THEM: "Honestly I'm stuck on the onboarding sequence for a coaching cohort I run, open rates dropped by half after week two and I can't tell if it's the subject lines or the send time. Also, if you ever want a guest spot on my podcast about creator tools, I'd love to have you."
