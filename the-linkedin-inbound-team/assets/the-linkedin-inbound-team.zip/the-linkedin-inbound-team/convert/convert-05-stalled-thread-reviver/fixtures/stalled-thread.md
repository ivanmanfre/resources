# Fixture, a thread that stalled after your last message

Invented for testing. Not a real thread and not a record of any real person.
Dates are as the thread would display them, relative labels only.

Person: Idris Falk

---

M1 THEM, 6w: "Thanks for the file, I'm rebuilding our post-purchase flow this
quarter and this is a good starting point."

M2 YOU, 6w: "Glad it landed at the right time. What's the biggest gap in the
flow right now."

M3 THEM, 5w: "Probably the second email, nobody opens it, I think it's
competing with our shipping notification."

M4 YOU, 5w: "That's a fixable send-time problem most of the time. Want me to
look at the sequence with you."
