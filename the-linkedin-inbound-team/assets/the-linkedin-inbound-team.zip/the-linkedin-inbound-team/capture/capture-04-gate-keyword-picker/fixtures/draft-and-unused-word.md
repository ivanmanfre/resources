# Fixture, a draft with a fresh keyword available

Invented for testing. Not a real post.

---

## The post draft, as written

I built a one-page vetting checklist after losing a project to scope creep
last spring. Ten questions to ask before you quote a new client so you are
not the one holding the bag two months in. I have used it on every intake
call since.

## Keywords the reader has used before

TEMPLATE, GUIDE, SWIPE
