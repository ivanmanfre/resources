# Fixture, gated post commenters plus the DM threads that followed

Invented for testing. Not real people or a real account.

---

## Commenter names and headlines, from the gated post

1. Grace Whitfield, headline: Freelance brand designer
2. Tomasz Lund, headline: (blank)
3. Grace Whitfield, headline: Freelance brand designer
4. Marisol Vega, headline: Ops lead, small agency

## DM threads that followed

### Thread, with Grace Whitfield
Grace: thanks, got it
Priya: anytime

### Thread, with Marisol Vega
Marisol: thanks, I run ops at Fieldstone Studio, this is perfect timing.
reach me at marisol@fieldstonestudio.com if easier
Priya: glad it's useful
