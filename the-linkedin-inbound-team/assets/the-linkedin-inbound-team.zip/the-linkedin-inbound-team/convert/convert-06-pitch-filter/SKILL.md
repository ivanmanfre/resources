---
name: convert-06-pitch-filter
description: "Use when an inbound DM is selling to you instead of asking you something, and it is time to close it out without opening a negotiation. Takes the inbound DM thread and returns the decline message for a thread that is selling to you, two lines. Triggers on \"decline this pitch\", \"someone is selling to me in my DMs\", \"write a polite no to this pitch\", \"close out this sales DM\", \"is this person pitching me or asking me something\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 30 of 30: the pitch filter

## What this does

Reads an inbound thread and, where the other person is the one doing the
selling, writes the two-line decline that closes it without leaving an
opening for a counter-pitch. Where the thread only looks like a pitch on its
first line and turns out to be a buyer asking a question, it says so instead
and writes no decline.

**The line only this unit produces:** the decline message for a thread that
is selling to you, two lines.

## Required input

1. **The inbound DM thread**, from them, in order. Your own replies if any
   exist; otherwise the thread can be their opening message alone.

## What it refuses

**Refusal 1, this is a buyer question wearing a pitch's opening.**

A pitch opens with a compliment or a shared-interest line and then offers
something of theirs. A buyer question can open with the identical line and
then ask about your offer instead. What follows the opener decides the class,
never the opener on its own. Where the thread ultimately asks whether you do
something, whether you take on people like them, or what your process is, and
never offers something of theirs in return, print:

```
VERDICT: BUYER QUESTION, NOT A PITCH
opening line: "<quoted>"
what follows: "<quoted>"
The opener reads like a pitch. What follows asks about your work, not theirs.
Writing a decline here would turn away someone with a real question. Route
this to Inbound Reply Writer or Call Ask Writer instead, whichever fits what
they asked.
```

No decline is written when this fires.

## Method

**Step 1, read the whole thread, not the first line.** A message that opens
with praise and then makes an ask is only classed by where the ask points.

**Step 2, the direction test.** One question, applied to the ask in the
message: who benefits if you say yes. If the ask hands them a customer, a
guest spot on their thing, a partnership on their terms, a purchase of their
product, or a meeting to hear their pitch, the direction is THEM. If the ask
is about whether you do something, take on someone like them, or have room
for a project, the direction is YOU, and Refusal 1 fires.

Where a message carries two asks, one in each direction, print both, and if
either ask points YOU, Refusal 1 fires. A message that rides a real question
in on a pitch-shaped opener still routes to a real answer, not a decline.

**Step 3, name what is being sold.** One line, plain: what the message is
offering, in their own terms, not a paraphrase that makes it read worse than
it is.

**Step 4, write the decline.** Exactly two lines:

1. A direct no, with no reason attached that invites a counter-offer. No
   "not right now", no "maybe later", no hedge that reads as a soft yes for
   another day.
2. A close that does not ask them anything and does not wish them well in a
   way that reads as an opening for a reply.

## Output format

```
# Decline for the thread with <their name>

## Direction check
what is offered: "<quoted or named plainly>"
who benefits if you say yes: THEM | YOU
verdict: PITCH, decline below | NOT A PITCH, see Refusal 1

## The decline
"<line one>"
"<line two>"
```

## Worked case

This is the fixture run. It is `fixtures/inbound-pitch.md`, executed line by
line against the rules above.

```
## Direction check
what is offered: "a 15-minute call to walk through their content system service"
who benefits if you say yes: THEM
verdict: PITCH, decline below

## The decline
"No thanks, I'm not looking for a content system right now."
"Good luck with the agency."
```

The second fixture, `fixtures/pitch-opener-buyer-question.md`, exercises
Refusal 1. The opening line compliments the reader's post, the same shape a
pitch uses, but what follows asks "do you take on projects like this or is
your calendar full," which points YOU. The run prints
`VERDICT: BUYER QUESTION, NOT A PITCH` and writes no decline.

## Edge cases

**The message offers something free with no ask attached at all** (a shared
resource, no call requested, no reply asked for). Step 2 finds no ask to test
a direction on. Print `NO ASK IN THIS MESSAGE, NOTHING TO DECLINE` and stop; a
decline written for a message that asked for nothing would be answering a
question nobody put to the reader.

**The pitch arrives disguised as a survey or a piece of research** ("quick
question for an article I'm writing, do you have five minutes"). Read what
the "quick question" turns out to be for. If it resolves into an offer of
their content, their newsletter, or a call to pitch something, direction is
THEM and it is a pitch.

**Your own prior reply already engaged with the pitch** before you caught what
it was. This unit still runs on the inbound message itself; it does not judge
or rewrite your own earlier reply, only the decline that closes the thread
from here.

**The pitch includes a specific dollar figure or a time-bound offer.** Ignore
it for the direction test; a number attached to their offer does not change
who benefits if you say yes. Name the figure in Step 3's plain description
and leave it out of the decline itself.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent what is being offered; use their own words.
- Never add a reason to the decline that was not necessary. A decline is two
  lines, not a debate.
- Never write a decline when Refusal 1's test says this is a buyer question.
- Never state or imply a price, a discount, or a counter-offer in the decline.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
