# Fixture, inbound reply with a stated situation and a direct question

Invented for testing. Not a real thread and not a record of any real person.

Person: Oskar Lindqvist
Headline: Ops Lead, Marrow & Vane

---

M1 YOU: "Hey Oskar, here's the swipe file: <link>."

M2 THEM: "Thanks, this is close to a problem I've had for months, our
onboarding emails all get written by whoever has time that week, is that
something a swipe file actually fixes or do you need a system behind it too."
