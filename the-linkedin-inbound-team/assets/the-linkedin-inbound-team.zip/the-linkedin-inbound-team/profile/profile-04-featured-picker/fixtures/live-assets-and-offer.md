# Fixture, the assets a reader already has live, plus the offer sentence

Invented person, invented company, invented links. Exercises a list where one
asset has no link and one has no description line.

---

## Offer sentence

I get the month-end close out of spreadsheets for operations directors at
mid-size manufacturers, and onto one system their own team can run.

## What I already have live

**1. The month-end close checklist**
what it is: a PDF, nine pages
link: https://kettleworth.example/close-checklist
what a visitor gets: the steps we run at every close, with who signs off each one

**2. Notes from rebuilding a close, week by week**
what it is: a series of six posts on my own profile
link: https://linkedin.example/posts/rebuilding-a-close
what a visitor gets: what the rebuild looked like week by week, including the two weeks it went backwards

**3. Work with me**
what it is: a page on my site
link: https://kettleworth.example/work-with-me
what a visitor gets: what the three-month engagement covers and how to start one

**4. The handover template**
what it is: a document I send people who ask
link: (not published anywhere yet)
what a visitor gets: the format we use to hand a close over to somebody new

**5. A talk I gave on process debt**
what it is: a recording
link: https://kettleworth.example/process-debt-talk
what a visitor gets: (not written)
