# Fixture, an asset that does not exist yet

Invented for testing. Exercises the does-not-exist-yet refusal.

---

## The description, pasted as written

I want to build a checklist for vetting clients before I quote them. Haven't
started it yet, but I think freelance designers would use it.

## The offer sentence

I help freelance designers avoid bad-fit clients by building a two-call
vetting process before they ever send a quote.
