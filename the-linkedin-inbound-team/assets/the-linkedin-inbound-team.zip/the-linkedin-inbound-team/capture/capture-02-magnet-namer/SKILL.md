---
name: capture-02-magnet-namer
description: "Use when the asset itself is finished and it still has a working title nobody would click. Takes a plain description of what already exists plus your offer sentence and returns five title candidates and one subtitle for the strongest of the five. Triggers on \"name my lead magnet\", \"help me title this checklist\", \"what should I call this freebie\", \"this title is boring\", \"give me title options for this guide\"."
---

# The LinkedIn Inbound Team, CAPTURE, unit 02 of 06: the lead magnet namer

## What this does

Reads a plain description of an asset that already exists, pulls out the
words that describe what is literally in it, and writes five title
candidates, each one traceable to those words, plus a subtitle for the
strongest candidate.

**The line only this unit produces:** five title candidates plus one subtitle
for the winning title.

This does not invent what the asset covers. Every word in every candidate
title has to trace back to the description or the offer sentence.

## Required input

1. **A plain description of the asset**, in the reader's own words, describing
   something that already exists in finished form: what it is, what it
   contains, roughly how it came about.
2. **The offer sentence**, one sentence naming who the reader helps and how.

## What it refuses

**Refusal, the asset does not exist yet.** If the description uses future or
conditional language about the asset ("I want to build", "planning to make",
"haven't started", "should probably put together"), stop:

```
ASSET DOES NOT EXIST YET
what the description says: "<the future-tense or conditional phrase, quoted>"

A title names something a reader can hand over today. Describe the finished
asset: what it is, what is in it, in the form it exists in right now.
```

This unit never names a plan. It points back to the contents, not to a build
step, because naming the plan produces a title for something that is not
there to send.

## Method

**Step 1, confirm existence.** Scan the description for future or conditional
markers (see Refusal above). If any are found, the refusal fires and no
further step runs.

**Step 2, pull the traceable words.** Read the description and the offer
sentence and list every concrete word or short phrase that names a piece of
the asset, its format, its scope, or its buyer: a format word ("checklist",
"template", "PDF"), a count ("ten"), a named element ("budget signals"), a
buyer noun ("freelance designers"). Print the list. A word only counts if it
appears in the description or the offer sentence, verbatim or as an obvious
inflection of the same word (question / questions).

**Step 3, write five title candidates.** Each candidate is built only from
words on the Step 2 list. Beside every candidate, print which Step 2 words it
traces to and how many. A candidate whose count is 0 is not shipped.

**Step 4, pick the winning title.** The winner is the candidate with the
highest traced-word count. Ties are broken by the shorter candidate, counted
in characters including spaces, printed. This is a rule about the input's own
words, never a guess about which title would perform better; no audience data
went into this unit and none is used here.

**Step 5, write the subtitle.** One line, built only from Step 2 words, naming
the buyer (from the offer sentence) and the concrete benefit the description
states. If the description states no benefit beyond what the title already
carries, the subtitle repeats the strongest untitled Step 2 phrase rather than
inventing a new claim.

## Output format

```
# Title options for <asset, three words>

## Traceable words
<the Step 2 list>

## The five
1. "<title>"   traces to: <words>   count: <n>
2. "<title>"   traces to: <words>   count: <n>
3. "<title>"   traces to: <words>   count: <n>
4. "<title>"   traces to: <words>   count: <n>
5. "<title>"   traces to: <words>   count: <n>

## Winner
"<title>"   count: <n>   chars: <n>
tie-break used: yes, against "<other title>" | no

## Subtitle
"<subtitle>"   traces to: <words>
```

## Worked case

This is the fixture run. It is `fixtures/existing-checklist.md`, executed
line by line against the rules above.

```
## Traceable words
one-page, checklist, PDF, ten, questions, budget signals, decision-maker
access, scope creep, timeline pressure, freelance designers (offer),
bad-fit (offer), vetting (offer), quote / quoting (offer + description)

## The five
1. "The 10-Question Checklist Before You Quote"
   traces to: ten, questions, checklist, quote   count: 4
2. "Ten Questions Before You Quote"
   traces to: ten, questions, quote   count: 3
3. "Budget Signals, Decision-Maker Access, Timeline Pressure: The Checklist"
   traces to: budget signals, decision-maker access, timeline pressure, checklist
   count: 4
4. "The One-Page Checklist for Freelance Designers"
   traces to: one-page, checklist, freelance designers   count: 3
5. "The Vetting Checklist Before You Quote"
   traces to: vetting, checklist, quote   count: 3

## Winner
"The 10-Question Checklist Before You Quote"   count: 4   chars: 42
tie-break used: yes, against "Budget Signals, Decision-Maker Access, Timeline
Pressure: The Checklist" (chars: 71)

## Subtitle
"Ten questions freelance designers ask before they send a quote to a client
who might be a bad-fit."
traces to: ten, questions, freelance designers, quote, bad-fit
```

The second fixture, `fixtures/asset-not-built-yet.md`, fires the refusal on
`"I want to build a checklist for vetting clients before I quote them.
Haven't started it yet"`, and no titles are written.

## Edge cases

**Two candidates tie in both count and length.** Print both as the winner and
say the tie was not broken, rather than picking one arbitrarily.

**The description names no format at all** (no "checklist", "template",
"guide", "PDF", or similar). Titles are still written from whatever concrete
words exist; the format slot in each candidate prints
`[NEEDS: what format this asset is]` if a candidate's natural phrasing needs
one and none is available.

**The offer sentence names no buyer.** The subtitle's buyer slot prints
`[NEEDS: who this is for]` rather than borrowing a buyer word from the
description alone.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never put a word in a title or subtitle that does not trace to the
  description or the offer sentence.
- Never rank or pick a winner on anything other than the printed count and
  length rule. No claim about which title would get more clicks.
- Never invent a number the description did not state.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
