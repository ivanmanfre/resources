# The LinkedIn Inbound Team, manifest

**30 agents. 5 stages. One job each.**

Every agent is one `SKILL.md` that runs on its own. Every agent takes an input you already
have and returns a line no other agent returns. The count is checkable: count the
directories.


## PROFILE (6 agents)

| Agent | What it returns |
|---|---|
| `profile-01-headline-rewriter` | three headline candidates with the character count printed against the 220 limit |
| `profile-02-about-opener` | the two lines that sit above the fold, cut from sentences you already wrote |
| `profile-03-experience-rewriter` | the description block rewritten as what you do for a buyer, five lines at most |
| `profile-04-featured-picker` | which three go in Featured, in which order, with a caption line each |
| `profile-05-search-term-picker` | ten search phrases a buyer types, each mapped to the profile field it has to appear in |
| `profile-06-rival-claim-mapper` | the two-column claim ledger, the claim only they make and the claim only you make |

## CONTENT (6 agents)

| Agent | What it returns |
|---|---|
| `content-01-first-line-writer` | five opening lines, each under twelve words and each traceable to a numbered sentence of your own draft |
| `content-02-detail-finder` | one question per claim the draft never grounds, with the claim quoted verbatim above it |
| `content-03-post-structure-cutter` | it reformatted, with the see-more fold marked at a printed character count and the line-break map printed beside it |
| `content-04-comment-question-miner` | the topics ranked by how many times the question appeared, with the commenters' words quoted |
| `content-05-offer-mention-placer` | either one closing line with the line number it belongs after, or a printed decline saying the link is not there |
| `content-06-carousel-slide-cutter` | slide-by-slide text with the hand-off sentence printed at every cut, plus the boundaries it rejected |

## ENGAGE (6 agents)

| Agent | What it returns |
|---|---|
| `engage-01-comment-angle-writer` | the comment text with the exact line of their post it answers |
| `engage-02-own-post-reply-writer` | one reply per commenter, each ending in a question only that commenter could answer |
| `engage-03-audience-overlap-counter` | the buyer share of the sampled commenters with the division printed |
| `engage-04-repeat-engager-tracker` | the repeat-engager roster with each name's appearance count across the posts supplied |
| `engage-05-connection-list-ranker` | the speak-to order with the headline phrase that ranked each connection |
| `engage-06-role-change-note-writer` | the two-line note tied to the specific change, naming the old seat and the new one |

## CAPTURE (6 agents)

| Agent | What it returns |
|---|---|
| `capture-01-magnet-demand-counter` | the magnet concept people asked for most, with every ask counted and quoted |
| `capture-02-magnet-namer` | five title candidates and one subtitle for the strongest of the five |
| `capture-03-magnet-cover-writer` | the cover lines with the true, backed count |
| `capture-04-gate-keyword-picker` | the new keyword and the arming sentence, placed in the draft |
| `capture-05-gate-reply-writer` | the delivery message, nothing else attached |
| `capture-06-lead-list-builder` | one row per captured name, unknown fields marked unknown |

## CONVERT (6 agents)

| Agent | What it returns |
|---|---|
| `convert-01-hand-raiser-sorter` | the two-bucket split of who gets a conversation and who gets the file and nothing else |
| `convert-02-dm-intent-reader` | the intent verdict for the thread: asking for the file, asking for help, or selling, with the line that decided it quoted |
| `convert-03-inbound-reply-writer` | the first reply to a warm inbound message: one question, and no pitch |
| `convert-04-call-ask-writer` | the call-ask sentence, attached to the sentence of theirs that earns it |
| `convert-05-stalled-thread-reviver` | the single revival message, two sentences, quoting their last concrete detail |
| `convert-06-pitch-filter` | the decline message for a thread that is selling to you, two lines |

---

Counted from disk on assembly: **30 agent directories, 30 SKILL.md files**.
