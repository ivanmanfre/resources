# Fixture, DM threads carrying real requests

Invented for testing. Not a real inbox and not a record of any real people.
Pasted the way a reader would paste a run of threads in one block, separated by
headers.

---

### Thread 1, with Denny R.
Denny: hey, saw your post about the client screening thing. do you have a
checklist for client onboarding you'd be willing to share?
Priya: not yet, still refining it
Denny: no worries, let me know if you ever put one together

### Thread 2, with Farah K.
Farah: loved the post today
Priya: thanks so much
Farah: keep them coming

### Thread 3, with Owen T.
Owen: quick one, is there a checklist for client onboarding anywhere? trying
to fix my intake process
Priya: working on it
Owen: also, separate thing, do you have a rate card template you use? mine is
all over the place
Priya: I have a rough one, not polished

### Thread 4, with Bianca S.
Bianca: hey, love your content. got anything I could use for this kind of
thing?
Priya: depends what you mean, what are you trying to solve
Bianca: just generally, the client stuff you post about
