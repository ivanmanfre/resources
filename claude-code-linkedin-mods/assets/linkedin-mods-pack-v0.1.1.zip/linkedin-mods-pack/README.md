# Claude Code mods for LinkedIn

Five free mods for people who write LinkedIn posts with Claude. Each one installs on its own, and they share the same look and keys.

| Mod | What it does |
|---|---|
| `linkedin-preview` | Shows each draft the way the feed shows it, cut at "…see more", with the markdown LinkedIn won't render flagged |
| `linkedin-hook-score` | Scores every hook from 1 to 10 against your own best posts, with one plain reason |
| `linkedin-voice-guard` | Flags the phrases that make a draft sound AI-written, and rewrites only those lines on one key |
| `linkedin-next-post` | Offers the next 3 content steps after a draft: carousel, objection replies, a hook that fits the fold |
| `linkedin-pipeline` | A pane with your leads, replies and booked calls, from your LinkedIn data export or a CRM CSV |

They work in the Claude Code terminal and in the Code tab of the Claude Desktop app, on Claude Code 2.1.287 or newer. They do not run in the claude.ai chat.

## Install

In a Claude Code session (terminal or Desktop Code tab), add the marketplace once:

```
/plugin marketplace add ivanmanfre/manfredi
```

Then install the ones you want:

```
/plugin install linkedin-preview@manfredi
/plugin install linkedin-hook-score@manfredi
/plugin install linkedin-voice-guard@manfredi
/plugin install linkedin-next-post@manfredi
/plugin install linkedin-pipeline@manfredi
```

Run `/plugin` to check: each installed mod is listed as active.

To try them for one session from this zip, without installing:

```
claude --plugin-dir ./linkedin-preview --plugin-dir ./linkedin-hook-score --plugin-dir ./linkedin-voice-guard --plugin-dir ./linkedin-next-post --plugin-dir ./linkedin-pipeline
```

## 2-minute setup in the Claude Desktop app

1. Open the Claude Desktop app and click the **Code** tab. Pick a folder for your LinkedIn work (any folder; a new empty one is fine) and say yes when it asks if you trust it.
2. In the message box, type `/plugin marketplace add ivanmanfre/manfredi` and press Enter.
3. Type `/plugin install linkedin-hook-score@manfredi` and press Enter. Do the same for each mod you want (the list is above).
4. Start a new session in the Code tab so the mods load. Type `/plugin` to see them listed as active.
5. Ask for a post: `Write a LinkedIn post about <your topic>`. When Claude finishes, the preview, the score, the flags and the next steps show up in the Code tab.
6. For the hook score, put your LinkedIn exports in that folder (or leave them in Downloads) and type `/hook-score-learn`. No exports yet? The same command makes a `top-posts.md` file for you to paste your best posts into. The `linkedin-hook-score` README says where LinkedIn keeps the exports.

## Keys

The bands above the prompt and the panes each have their own keys, and no two mods share one. In a band, click it or press `ctrl+x` then `tab` first; clicking a button works too.

| Mod | Keys |
|---|---|
| linkedin-preview (pane) | `1`-`9` drafts, `m` mobile/desktop, `f` see more, `c` copy |
| linkedin-voice-guard (band) | `r` rewrite flagged lines, `v` show all flags |
| linkedin-next-post (band) | `a` `s` `d` send a step, `x` hide |
| linkedin-pipeline (pane) | `w` 7/30/90 days, `l` read the files again |
| linkedin-hook-score (band) | none |

## What they send where

- `linkedin-hook-score` asks your own Claude, through Claude Code, to score hooks: one short request per draft turn. No API key, and nothing else leaves your machine.
- `linkedin-voice-guard` and `linkedin-next-post` send a prompt to Claude in your session only when you press a key, and you see it in the transcript.
- `linkedin-preview` and `linkedin-pipeline` send nothing anywhere.
- None of them make network calls. `claude plugin validate <folder>` lists every event and call a mod uses, so you can check before you install.

Made by [Ivan Manfredi](https://ivanmanfredi.com). We run LinkedIn inbound for agency founders: the posts, the comments and the DMs. See how it works: **[ivanmanfredi.com/start](https://ivanmanfredi.com/start/)**
