---
name: content-06-carousel-slide-cutter
description: "Use when a post you wrote as prose should be a carousel and you need to know where the slides break. Takes the draft written straight through and returns slide-by-slide text with the hand-off sentence printed at every cut, plus the boundaries it rejected. Triggers on \"turn this post into a carousel\", \"cut this into slides\", \"how many slides should this be\", \"where do the slide breaks go\", \"make a document post out of this\"."
---

# The LinkedIn Inbound Team, CONTENT, unit 06 of 06: the carousel slide cutter

## What this does

Cuts a written post into slides, and at every cut writes the sentence that
carries the reader across it.

**The line only this unit produces:** the hand-off block at each slide boundary,
carrying the sentence that ends the slide, the term that crosses to the next
one, the thing left open, and the sentence on the next slide that resolves it.

The hand-off is what decides the cut, not decoration printed after the cut was
made. A boundary that cannot produce one is rejected and the two slides are
merged, and the rejection is printed. This is the difference between a carousel
and a paragraph chopped into squares, and it is the only thing this unit is for.

Text only. No design, no cover art, no colour, no font.

## Required input

1. **The post draft**, written straight through as prose, pasted whole. Prose,
   because the cuts have to be made against sentences you wrote for continuity;
   a draft already in bullet points has had its hand-offs deleted before this
   unit ever sees it.
2. Nothing else. No audience data, no analytics.

If the paste is already a list of slides, print
`[NEEDS: the prose version, before it was cut]` and stop.

## What it refuses

**Refusal 1, one beat is not a deck.** If Step 3 counts fewer than three moves:

```
NOT ENOUGH HERE TO CUT
Rows: <n>   Moves: <n>

A slide boundary needs something on one side that the other side answers. This
draft states one thing and restates it, so every cut available would be a line
break with a border around it.

[NEEDS: one thing that happened, with a date, a number or a name in it]

Moves found:
<the move rows, or "none">
```

**Refusal 2, a slide count you picked.** If asked for a fixed number of slides:

```
THE MOVE COUNT SETS THE SLIDE COUNT
Asked for: <n> slides   Moves in the draft: <n>

Slides above the move count are slides with nothing on them, and slides below it
put two beats on one card. Add or cut material in the prose and run this again.
```

**Refusal 3, no boundary survives.** If every boundary is rejected and the merges
leave one slide:

```
ONE BEAT, NOT A DECK
Boundaries tested: <n>   Boundaries rejected: <n>   Slides left: 1

Nothing in this draft crosses from one part of it to another, which is why every
cut collapsed. It is a post, and it stays a post.
```

## Method

**Step 1, split into rows.** Number the sentences S1 upward. A sentence carrying
two separate facts joined by "and", "but", a semicolon or a comma splice is split
into `S<n>a` and `S<n>b` before anything else. Print both counts:
sentences pasted, rows after splitting. Rows split from one sentence stay on the
same slide, because they were one sentence in your prose.

**Step 2, mark the moves.** A row is a `MOVE` when it introduces at least one of
these that no earlier row carried:

- a thing that happened, with an actor and a time or a sequence
- a figure
- a thing a reader could ask to see, named
- a step you took
- words somebody said, quoted

Every row is printed with `MOVE` or `no move` and, for the moves, which of the
five it carries. A row that restates an earlier row is `no move`, with the
earlier id printed.

**Step 3, the move gate.** Print `moves: <n>`. Under three, Refusal 1 fires.
Slides can never outnumber moves, and that ceiling is printed with the count.

**Step 4, first cut, one move per slide.** Two exceptions, both printed:

- rows split from one sentence stay together
- a list the draft wrote as consecutive parallel sentences stays whole, however
  many items it has, because a list split across a cut stops reading as a list

**Step 5, the hand-off, at every boundary, before the cut is accepted.** For each
boundary between slide k and slide k+1, produce all four lines. A boundary with
fewer than four is not a boundary:

```
carried term: "<term>"   on slide k in "<sentence>"   on slide k+1 in "<sentence>"
hand-off source: from your draft, S<n> | moved, S<n> from slide k+1 | written
left open: <the thing slide k does not answer>
resolved on slide k+1 by: "<sentence>"
```

The carried term is a content word or its inflected form, and it has to mean the
same thing in both places. A coincidental match on an unrelated sense is printed
and rejected, in these words: `term "<word>" matches by spelling only, rejected`.

The term sits in the last sentence of slide k and appears anywhere on slide k+1
as slide k+1 will ship. One exception on the slide k side: where slide k is a
list kept whole under Step 4, the term may sit in any item of the list, because a
list reads as one block. Print which item carries it.

The two checks run at different moments and the difference decides which term
carries. A `written` hand-off draws its words from slide k+1 **before** any trim,
because that is the text you have in front of you. The carried term is checked
against slide k+1 **after** the trim, because that is the slide a reader sees. A
term that only exists in the trimmed lead-in does not carry, and picking one is
the commonest way a deck ends up with a hand-off that points at nothing.

The three legal sources, in this order:

1. `from your draft`: the last sentence of slide k already carries the term.
2. `moved`: a sentence from the top of slide k+1 moves to the end of slide k.
   Print which sentence moved.
3. `written`: you write one sentence, built only from words already present on
   slide k and slide k+1. Print the word list with the slide each word came
   from. Where the written sentence restates a row already on slide k, it
   replaces that row and prints `replaces S<n>`. Where slide k+1 then opens on a
   duplicate lead-in, trim it and print `trimmed from slide k+1: "<text>"`.

**Step 6, reject and merge.** If none of the three sources produces all four
lines, print:

```
BOUNDARY REJECTED between slide <k> and slide <k+1>: <no term crosses it |
nothing is left open>
merged into one slide
```

Then renumber the slides and test the boundaries again from Step 5, because a
merge changes which sentence ends the slide. Print how many passes it took.

**Step 7, the count check.** Print:

```
moves: <n>
slides: <n>            (never more than moves)
boundaries: <n>        (always slides minus one)
hand-offs written: <n>
boundaries rejected: <n>
```

`hand-offs written` must equal `boundaries`. If it does not, print
`CUT NOT FINISHED` and name the boundary with no hand-off. A deck shipped with a
missing hand-off is the failure this unit exists to prevent, so the count is
printed even when it matches.

**Step 8, print the deck.** Slide by slide, in order, with the hand-off block
printed between each pair. The words are yours apart from the sentences marked
`written`, and each of those prints its word sources.

## Output format

```
# Slides from <draft first three words>

## Rows
S1   MOVE: an event   "<verbatim>"
S2a  MOVE: a figure   "<verbatim>"
S2b  no move, restates S1   "<verbatim>"
...
sentences pasted: <n>   rows after splitting: <n>   moves: <n>

## Counts
moves: <n>   slides: <n>   boundaries: <n>   hand-offs written: <n>
boundaries rejected: <n>   passes: <n>

## The deck

### Slide 1
<text>

--- hand-off 1 ---
carried term: "<term>"   slide 1: "<sentence>"   slide 2: "<sentence>"
hand-off source: <source>
words used: <word> (slide 1), <word> (slide 2)      (written source only)
left open: <the thing>
resolved on slide 2 by: "<sentence>"

### Slide 2
<text>

...

## Rejected boundaries
between slide <k> and slide <k+1>: <reason>, merged
```

## Worked case

This is the fixture run. It is `fixtures/prose-post-sequence.md`, executed line
by line against the rules above, including two boundaries that the rules reject.

```
## Rows
S1   MOVE: an event, a named thing    "In January I started a file called "questions people ask twice"."
S2   MOVE: words somebody said        "The first entry was a sentence from a call: "how do you actually decide what to write about"."
S3a  MOVE: a figure                   "By March the file had nine entries"
S3b  MOVE: a figure                   "six of them asked about deciding"
S4a  MOVE: a step                     "I read the nine back in one sitting"
S4b  MOVE: a step                     "grouped them by what they were asking me to show"
S5   MOVE: a figure                   "Four wanted the criteria written down."
S6   MOVE: a figure                   "Two wanted to see a real example."
S7   MOVE: a figure                   "Three wanted to know what I throw away."
S8   MOVE: an event                   "The next call I ran, I opened on the criteria rather than the work."
S9   MOVE: an event                   "She asked for the list before I offered it."
S10  MOVE: a step                     "The file is now the first thing I open when I plan a post."
sentences pasted: 10   rows after splitting: 12   moves: 12

## Counts
moves: 12   slides: 6   boundaries: 5   hand-offs written: 5
boundaries rejected: 2   passes: 3

## The deck

### Slide 1
In January I started a file called "questions people ask twice".
The first entry in the file was a call about what to write.

--- hand-off 1 ---
carried term: "write"
  slide 1: "The first entry in the file was a call about what to write."
  slide 2: ""how do you actually decide what to write about""
hand-off source: written
words used: file (slide 1), first (slide 2), entry (slide 2), call (slide 2), about (slide 2), what (slide 2), write (slide 2)
left open: the words they used
resolved on slide 2 by: ""how do you actually decide what to write about""
trimmed from slide 2: "The first entry was a sentence from a call:"
   (the word sources are read off slide 2 before the trim; the carried term is
    checked against slide 2 after it, which is why "write" carries and
    "sentence" would not)

### Slide 2
"How do you actually decide what to write about"

--- hand-off 2 ---
carried term: "decide"
  slide 2: ""how do you actually decide what to write about""
  slide 3: "six of them asked about deciding"
hand-off source: from your draft, S2
left open: how many people asked it
resolved on slide 3 by: "Six of them asked about deciding."

### Slide 3
By March the file had nine entries.
Six of them asked about deciding.

--- hand-off 3 ---
carried term: "asked", inflected to "asks" on slide 4
  slide 3: "six of them asked about deciding"
  slide 4: "The nine asks grouped into what they wanted me to show."
hand-off source: from your draft, S3b
left open: what the asks had in common
resolved on slide 4 by: "The nine asks grouped into what they wanted me to show."

### Slide 4
I read the nine back in one sitting.
The nine asks grouped into what they wanted me to show.

--- hand-off 4 ---
carried term: "wanted"
  slide 4: "The nine asks grouped into what they wanted me to show."
  slide 5: "Four wanted the criteria written down."
hand-off source: written, replaces S4b
words used: nine (slide 4), asks (slide 4, from S4b before it was replaced), grouped (slide 4), show (slide 4), wanted (slide 5)
left open: what they wanted shown
resolved on slide 5 by: "Four wanted the criteria written down."

### Slide 5
Four wanted the criteria written down.
Two wanted to see a real example.
Three wanted to know what I throw away.

--- hand-off 5 ---
carried term: "criteria"   list exception, carried by item 1
  slide 5: "Four wanted the criteria written down."
  slide 6: "The next call I ran, I opened on the criteria rather than the work."
hand-off source: from your draft, S5
left open: what you did with the criteria
resolved on slide 6 by: "The next call I ran, I opened on the criteria rather than the work."

### Slide 6
The next call I ran, I opened on the criteria rather than the work.
She asked for the list before I offered it.
The file is now the first thing I open when I plan a post.

## Rejected boundaries
pass 1, between slide 6 (S8) and slide 7 (S9): no term crosses it. S8 ends on
"the work" and S9 opens on "She", and no sentence could be written from the two
sides without adding an event the draft never states. Merged.
pass 2, between slide 6 (S8, S9) and slide 7 (S10): no term crosses it. S9 ends
on "offered it" and S10 carries file, first, open, plan, post, none of which
appear in S9. Merged.
```

Pass one cut twelve moves into eight slides. Two boundaries failed every source
and were merged, which is why the deck closes on a three-sentence slide rather
than on three thin ones. Pass three re-tested the five surviving boundaries and
all five carry a hand-off, so `hand-offs written` equals `boundaries` and the cut
is finished.

The second fixture, `fixtures/prose-post-one-claim.md`, fires Refusal 1: rows 6,
moves 0, and the `Moves found` block prints `none`.

## Edge cases

**A quoted sentence on its own slide.** Legal, and the quote is the whole slide.
The hand-off into it names the thing left open, and the quote resolves it.

**Two moves in one sentence that clearly want different slides.** They stay
together. If that reads badly, the honest fix is in the prose, and this unit
prints `SPLIT WANTED at S<n>` with the sentence quoted, and cuts nothing.

**A list of seven items.** It stays whole on one slide and prints
`LIST OF 7 KEPT WHOLE`. A list is one move however long it is.

**The last slide has nothing after it.** The last slide takes no hand-off, and
the boundary count is slides minus one for exactly that reason. Never write a
hand-off out of the final slide to nothing.

**You want a slide count for the platform.** The move count is the answer this
unit has. Refusal 2 fires on a number you picked, and the moves are printed so
you can see where the ceiling comes from.

**The draft has a number that changes between slides.** Print the figure on the
slide the draft put it on and nowhere else. A figure restated on a later slide
is a row that restates, and `no move` applies.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never print a slide without the hand-off block on the boundary before it.
- Never write a hand-off sentence containing a word absent from both of the
  slides it sits between.
- Never invent an event, a figure, a name, a quote or a step to carry a cut.
- Never accept a boundary on a term that matches by spelling and means something
  else.
- Never produce more slides than moves, and never pad a slide to fill a count.
- Never rewrite a sentence for style. Sentences are moved, split at their own
  conjunctions, or replaced by a printed `written` hand-off, and nothing else.
- Never design. No cover copy, no colour, no font, no image direction.
- Never claim what a deck will do to a post's performance.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
