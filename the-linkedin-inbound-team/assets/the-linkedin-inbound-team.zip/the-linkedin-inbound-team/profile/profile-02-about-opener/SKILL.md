---
name: profile-02-about-opener
description: "Use when the About section opens with career history and the visitor clicks away before the see-more link. Takes your current About text pasted whole and returns the two lines that sit above the fold, cut from sentences you already wrote. Triggers on \"rewrite my About section opener\", \"first lines of my LinkedIn About\", \"what should my About start with\", \"my About section is boring\", \"fix the top of my About\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 02 of 30: the About opener

## What this does

Reads the About section you have now, tags every sentence in it by what that
sentence carries, and builds the opening two lines out of the sentences that
already carry a buyer and a change.

**The line only this unit produces:** the two lines that sit above the About
section's see-more fold.

Nothing in the two lines is written from nothing. Every content word in them
comes from the text you pasted, and any word this unit had to add is printed in
a list underneath so you can see exactly what was put in your mouth. That is the
whole reason the unit demands the full paste: it has no other source for how you
write.

## Required input

1. **Your About section, pasted whole.** Not a summary of it, not the first
   paragraph. The whole thing, including the part below the fold, because the
   sentence worth opening with is usually down there.
2. Optional: **the words your buyers use for themselves.** Used only when the
   About text names its buyer in your words rather than theirs.

No follower count, no post history, no analytics of any kind.

## What it refuses

**Refusal 1, nothing pasted to work from.** Fewer than three sentences in the
About text, or the About is empty:

```
NOT ENOUGH TEXT TO CUT FROM
sentences supplied: <n>

This unit rewrites sentences you have already written. With <n> of them there is
nothing to preserve, and anything it produced would be this unit's writing under
your name.

Supply three sentences you have written anywhere: a DM where you explained what
you do, the last email that described the work, a comment you left on somebody
else's post. Paste them raw. They do not have to be good.
```

**Refusal 2, nothing in the paste to lift.** The About text runs to three or
more sentences and none of them carries a buyer, a change, or the work:

```
NOTHING IN THIS PASTE CAN OPEN IT
sentences supplied: <n>
carrying a buyer: 0    carrying a change: 0    carrying the work: 0

Every sentence here is career history, opinion, or description of yourself. An
opener cut from this text would say who you have been and not who it is for.

Supply one sentence answering this: who came to you last, and what was going
wrong for them when they did.
```

Both refusals stop the run. Neither one is fixed by this unit writing the
missing sentence.

## Method

**Step 1, split into sentences and number them.** A fragment ending in a full
stop is a sentence. Print `S1`, `S2`, and so on, so every later step can point
at a number.

**Step 2, tag every sentence.** Every sentence gets at least one tag:

| Tag | What the sentence carries |
|---|---|
| `BUYER` | Names the group of people the work is for |
| `CHANGE` | Names what is different for them afterwards |
| `WORK` | Names what you actually do |
| `STORY` | Career history, years, previous employers, qualifications |
| `VIEW` | A statement about the work or the field, no self-description in it |
| `ASK` | Invites contact |
| `FILLER` | Adjectives about yourself with no fact attached |
| `OTHER` | None of the above fits |

A sentence carrying two of these gets both tags printed on its row. Where a
sentence joins a buyer to a change with `where`, `so that`, `usually at the
point`, or a comma doing the same job, split it at the joint and tag each half,
then print both halves under the same sentence number. One status per fact, never
one status per sentence.

**Step 3, the gates.** Fewer than three sentences, fire Refusal 1. Zero `BUYER`,
zero `CHANGE` and zero `WORK`, fire Refusal 2. Otherwise continue.

**Step 4, build line 1, which carries the buyer.** Take the sentence tagged
`BUYER`. Where that sentence carries no change, words from any sentence tagged
`CHANGE` may join it. Line 1 has to name the buyer and the situation they are in
when they come to you.

If no sentence is tagged `BUYER` but Step 3 passed, line 1 prints
`[NEEDS: who this is for, in the words they would use for themselves]` in the
buyer slot, and the rest of the line is built as normal.

**Step 5, build line 2, which carries the work.** Take the sentence tagged
`WORK` or `CHANGE`. Line 2 says what you do about the situation line 1 named. If
neither tag exists, print `[NEEDS: what you do about it, in one clause]`.

**Step 6, the added-words list.** List every content word in the two lines that
does not appear anywhere in the pasted About text. An inflection of a word that
appears there counts as appearing (`depend` covers `depends`). Joining words
(`the`, `and`, `where`, `is`, `to`, `for`, `with`, `a`, `that`, `it`) are not
content words and are not listed. Print:

```
words added: none | "<word>", "<word>"
```

More than three added content words means the opener is no longer cut from your
About. Cut back to the words that are there and print the list again. Never
print a shorter list than the one you actually produced.

**Step 7, the character counts and the working budget.** Print the count of each
line and of the pair.

This unit does not claim to know where LinkedIn puts the see-more cut. The point
it truncates at moves with the device, the window width and whether the visitor
is in the app or a browser, so a unit that printed an exact fold position would
be printing something it cannot see. What it does instead: line 1 is written to
stand alone as a complete statement, so that wherever the cut lands, the first
thing read is finished.

The working budget, which is this unit's choice and not a platform measurement:
line 1 at or under 100 characters, line 2 at or under 120. Over budget, print:

```
OVER the working budget by <n>
shortened: "<the line with words removed>"
removed: "<the exact words taken out>"
```

Both versions stay printed. The reader picks.

**Step 8, name the sentence that follows.** The third line of the About is the
first sentence in the paste that was not used in lines 1 or 2, in the order it
appears, skipping any sentence tagged `FILLER` or `ASK`. Print `follows: S<n>`
and quote it. This is here so the seam is visible: a strong opener with a
career-history sentence underneath it reads as two people writing.

**Step 9, print the sentence census.** Population, stated in words: the
sentences in the About text you pasted. Every tag gets its own row, including
the tags at zero:

```
sentences in the About you pasted: <n>
BUYER:  <n>   S<n>
CHANGE: <n>   S<n>
WORK:   <n>   S<n>
STORY:  <n>   S<n>
VIEW:   <n>   S<n>
ASK:    <n>   S<n>
FILLER: <n>   S<n>
OTHER:  <n>   S<n>
```

Rows do not sum to the sentence count, because a sentence carrying two tags is
counted on both rows. State that under the census every time. No percentage is
printed: the share of your About that is career history is not a number this
unit has any standard to judge, and printing one would invent the standard.

## Output format

```
# About opener

## Line 1
<the line>
characters: <n>       | OVER the working budget by <n>

## Line 2
<the line>
characters: <n>       | OVER the working budget by <n>

pair: <n> characters
words added: none | "<word>"

## Follows
S<n>: "<the sentence that should sit under them>"

## Census
<the census from Step 9>
```

## Worked case

This worked case is a literal run of `fixtures/about-pasted-whole.md`, checked
line by line against the steps above. It is the same input, not a similar one.

```
# About opener

## Line 1
I work with operations directors at manufacturers where the month-end close is still in one person's head.
characters: 106       OVER the working budget by 6
shortened: "I work with operations directors where the month-end close is still in one person's head."
removed: "at manufacturers"

## Line 2
Kettleworth puts it into a system the rest of the team can run.
characters: 63

pair: 169 characters
words added: none

## Follows
S1: "Fifteen years in operations and I still think the hardest part of any business is the handover."

## Census
sentences in the About you pasted: 8
BUYER:  1   S6
CHANGE: 1   S2
WORK:   2   S2, S4
STORY:  2   S1, S5
VIEW:   2   S1, S3
ASK:    1   S8
FILLER: 1   S7
OTHER:  0

Rows sum to 10 over 8 sentences, because S1 and S2 each carry two tags.
```

Line 1 was built from S6, which carries the buyer, joined to `month-end close`
and `one person's head` from S2, which carries the change. Line 2 was built from
S2. Every content word in both lines appears in the paste, so the added-words
list is empty. S7 is skipped by Step 8 as `FILLER` and S8 as `ASK`, and neither
was used, which leaves S1 as the first unused sentence in order.

## Edge cases

**The About is written in the third person.** Tag and cut it as it stands, and
print one line saying the two lines came back in third person because that is
what was pasted. Switching the person is a rewrite of every sentence in the
section, and this unit is not doing that silently in two lines.

**The About opens with the ask already.** The `ASK` sentence is never used as
line 1 or line 2. An invitation read before the reason for it is an invitation to
nothing. Print one line saying where the ask moved to: the end.

**Two sentences carry the buyer and they disagree.** Print both, use the one
that appears later in the paste, and print one line naming the disagreement. A
profile claiming two different buyers is a decision the reader has to make, and
this unit picks the later one only so the run can finish.

**The paste has line breaks but no full stops.** Treat each line break as a
sentence boundary and say so in one line, because the numbering the rest of the
output points at depends on it.

**The strongest sentence in the paste is tagged `VIEW`.** It still does not
become line 1. Line 1 carries the buyer. Print the `VIEW` sentence under
`Follows` if Step 8 lands on it, which is where a line like that does its work.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never write a sentence in the reader's voice from nothing. Every content word
  comes from the paste, and the ones that did not are listed.
- Never invent a buyer, a change, a year, an employer, a qualification or a
  client the paste did not carry.
- Never put a result or an outcome figure in either line.
- Never claim to know where the see-more cut falls.
- Never delete a sentence from the reader's About. This unit writes two lines and
  names the one that follows. Everything else in the paste is untouched.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
