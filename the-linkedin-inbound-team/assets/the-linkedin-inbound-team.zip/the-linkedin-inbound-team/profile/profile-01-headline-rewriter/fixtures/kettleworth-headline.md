# Fixture, a current headline and an offer sentence

Invented person, invented company. Exercises a headline built out of role,
credential and personal phrases, beside a two-clause offer sentence.

---

## Current headline, copied exactly

Founder & CEO @ Kettleworth | Helping businesses scale | Speaker | Ex-Verrow | Coffee enthusiast

## Offer sentence

I get the month-end close out of spreadsheets for operations directors at
mid-size manufacturers, and onto one system their own team can run.

## Words my buyers use for themselves

Operations director, head of finance operations, finance ops lead
