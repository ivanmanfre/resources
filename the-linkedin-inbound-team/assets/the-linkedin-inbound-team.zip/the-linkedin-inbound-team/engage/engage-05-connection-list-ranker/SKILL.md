---
name: engage-05-connection-list-ranker
description: "Use before an outreach push, to figure out which of your existing LinkedIn connections to talk to first. Takes the names and headlines copied from your connections list screen plus your offer sentence, and returns the speak-to order with the headline phrase that ranked each connection. Triggers on \"rank my LinkedIn connections\", \"who should I reach out to first\", \"sort my connections by relevance\", \"which connections are worth talking to\", \"prioritize my connection list\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 05 of 30: the connection list ranker

## What this does

Reads the names and headlines from your connections list screen beside your
offer sentence, and orders the connections who have a headline into who is
worth speaking to first.

**The line only this unit produces:** the speak-to order of your existing
connections, with the headline phrase that ranked each.

## Required input

1. **Names and headlines copied from the connections list screen**, one row
   per line, exactly as the screen shows them.
2. **Your offer sentence.** One sentence naming who you work with and what
   changes for them.

Nothing else is read. No connection date, no mutual connection count, no
message history with anyone on the list.

## What it refuses

**Refusal 1, no buyer named in the offer sentence.** Same buyer test as
elsewhere in this pack: could you type this into LinkedIn's people search
and get people back.

```
NO BUYER NAMED IN THE OFFER SENTENCE
offer sentence: "<as pasted>"
what was found instead: <the word that stood in for a buyer>

Nothing here can be ranked against a buyer that is not a searchable group.
Supply one line: the job titles your buyer actually holds.
```

**Refusal 2, per row: no headline gets parked, never ranked on the name
alone.** Applied per row, not to the whole list. See Step 2.

## Method

**Step 1, extract the buyer descriptor from the offer sentence.** Run the
buyer test. If it fails, fire Refusal 1 and stop. Print `buyer descriptor:
"<span>"`.

**Step 2, split every row into headline-present or no-headline.** Population
stated:

```
rows pasted: <n>
with headline: <n>
no headline (parked): <n>
```

No-headline rows are printed under a separate `Parked` section at the end,
name only, never ranked.

**Step 3, classify every headline-present row.** Three classes:

- `MATCH`: headline names the same function as the buyer descriptor, within
  one seniority step.
- `ADJACENT`: headline names a function that reports into or works closely
  with the buyer descriptor's function, but is not it. State which
  relationship (`reports into` or `works closely with`).
- `NO MATCH`: headline names a function unrelated to the buyer descriptor.

**Step 4, rank.** Order: all `MATCH` rows first, then all `ADJACENT`, then
all `NO MATCH`. Within each class, keep the order the rows were pasted in;
this unit does not invent a tiebreaker beyond the class the row landed in.

**Step 5, print the headline phrase that ranked each row.** The exact span
of the headline that produced its class, quoted.

## Output format

```
# Connection ranking
buyer descriptor: "<span>"
rows pasted: <n>
with headline: <n>   no headline (parked): <n>

## Speak-to order
1. <name> - MATCH - "<headline phrase>"
2. <name> - MATCH - "<headline phrase>"
...
<n>. <name> - ADJACENT - "<headline phrase>" (reports into / works closely
with <buyer function>)
...
<n>. <name> - NO MATCH - "<headline phrase>"

## Parked, no headline
- <name>
```

## Worked case

This worked case is a literal run of `fixtures/connections-list-sample.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
# Connection ranking
buyer descriptor: "clinic owners"
rows pasted: 10
with headline: 8   no headline (parked): 2

## Speak-to order
1. Jonah Petrakis - MATCH - "Owner, Fenwick Family Dental"
2. Lachlan Vire - MATCH - "Owner-Operator, Milbrook Chiropractic"
3. Callum Reeve - MATCH - "Founder & Owner, Northshore Vision Clinic"
4. Marek Ostrowski - MATCH - "Clinic Director, Fennimore Health"
5. Btissam Kharrat - ADJACENT - "Practice Manager, Rourke Physiotherapy"
(reports into clinic owner)
6. Odalys Ferreira - ADJACENT - "Front Desk Lead, Solene Dental Group"
(works closely with clinic owner)
7. Ines Okonjo - NO MATCH - "Marketing Manager, Bright Path Wellness"
8. Tamsin Oduya - NO MATCH - "Software Engineer, Vellum Systems"

## Parked, no headline
- Aurelia Danesh
- Petar Vuksanovic
```

`Clinic Director` is classed `MATCH`, not `ADJACENT`, because a director
runs the clinic's decisions the same way an owner does; the seat differs
from `Owner` by title only, not by function.

## Edge cases

**A headline names a function that used to be the buyer's function but the
person has since moved on** (e.g. "Ex-VP Sales, now Founder"). Classify on
the current role only, the part of the headline stated as present tense or
without a former marker. Print which part of the headline was used.

**Two people have the exact same headline text.** Rank them next to each
other in the order pasted, and note nothing further; identical headlines
carry identical evidence.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never rank a row with no headline; park it instead.
- Never infer a function from a name, a company name alone, or a photo.
- Never state that a `MATCH` row is more likely to reply, buy, or convert.
  This unit ranks by function match only.
- No em dashes anywhere. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
