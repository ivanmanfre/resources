# Fixture, an offer sentence and a draft about something else

Invented for testing. No real people, no real companies, no record of any
engagement.

What this input is designed to exercise: a draft whose subject has nothing to do
with the offer, written for exactly the people the offer is for.

---

My offer sentence:
I write the weekly client note for B2B agencies so the work they do stays
visible to the client.

How I ask for a reply, in words I already use:
send me a message

My draft:
An agency I sat with last Tuesday handed a new hire an eleven-page onboarding pack.
She read two pages and asked the person next to her if there was a shorter version.
There was one, in a Slack thread from March.
We spent the afternoon turning the Slack thread into a one-page card.
The card is what the next hire will get.
Written things decay in the direction of longer.
