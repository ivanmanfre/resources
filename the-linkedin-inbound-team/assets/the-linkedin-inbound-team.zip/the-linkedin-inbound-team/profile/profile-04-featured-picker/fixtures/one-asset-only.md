# Fixture, one live asset and one that is still an intention

Invented person, invented links. Exercises the gate on the count of assets that
can actually be linked.

---

## Offer sentence

I help clinic owners get the front desk running without them standing behind it.

## What I already have live

**1. The front desk script pack**
what it is: a PDF
link: https://pellamont.example/front-desk-scripts
what a visitor gets: the words the desk uses for the eight calls that come in every day

**2. The staffing rota guide**
what it is: something I keep meaning to write up
link: (does not exist yet)
what a visitor gets: how to build a rota that survives someone calling in sick
