# Fixture, a profile carrying two live assets

Invented person, invented links. Exercises a short list from a profile with no
service page behind it.

---

## Offer sentence

I help clinic owners get the front desk running without them standing behind it.

## What I already have live

**1. The front desk script pack**
what it is: a PDF
link: https://pellamont.example/front-desk-scripts
what a visitor gets: the words the desk uses for the eight calls that come in every day

**2. What to do when the desk is short-staffed**
what it is: a post on my own profile
link: https://linkedin.example/posts/short-staffed-desk
what a visitor gets: the order to drop tasks in when two people are covering four seats
