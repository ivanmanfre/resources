# Fixture, a comment thread on your own post

Invented for testing. Not a real thread and not a record of any real person
or company.

Note: exercises the CONTENT / NO CONTENT split, the per-comment refusal, and
Step 5's branch for a commenter whose comment is itself a direct question.

---

Post subject (for context only, not read by this unit): launching a
subscription tier at an invented company, Larkspur Analytics.

## Comment thread

Tomasz Bilek, Head of Ops at Ferndale Metals:
"We tried a tiered pricing move like this last year and the mid-tier
cannibalized our top tier for two months before it settled."

Priya Nandan, no headline shown:
"🔥"

Colm Ashworth, Founder at Voss & Rye:
"Congrats"

Selin Aydemir, RevOps Lead at Bramwell Co:
"How did you handle grandfathering people who were already on the old plan?"

Devon Achebe, Support Manager at Kestrel Freight:
"This is close to what we're planning for Q1, we're worried about support
load doubling."
