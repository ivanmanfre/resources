# Fixture, a current-role experience entry copied off the profile

Invented person, invented company. Exercises a long entry written in org-chart
language, with compound lines in it.

---

## Header, as it appears

Director of Client Services
Bramwell and Co  ·  Full-time
Mar 2021 to Present
Leeds, United Kingdom  ·  Hybrid

## Body, as it appears

Leading a talented team of 12 across client services and delivery.
Responsible for the full client lifecycle from onboarding through to renewal.
Built and rolled out a new onboarding process that cut the number of escalations in the first month.
I run the weekly account review and write the monthly client note that goes to every account.
Sit on the leadership team and own the services P and L.
Passionate about service excellence and long-term partnerships.
Speaker at two industry events.
Reporting to the Managing Director.
