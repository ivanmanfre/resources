# Fixture, a post written straight through as prose

Invented for testing. Not a real post and not a record of any engagement.

What this input is designed to exercise: two sentences carrying two facts each,
a three-item list, and two adjacent beats that belong on one slide.

---

In January I started a file called "questions people ask twice". The first entry
was a sentence from a call: "how do you actually decide what to write about". By
March the file had nine entries and six of them asked about deciding. I read the
nine back in one sitting and grouped them by what they were asking me to show.
Four wanted the criteria written down. Two wanted to see a real example. Three
wanted to know what I throw away. The next call I ran, I opened on the criteria
rather than the work. She asked for the list before I offered it. The file is
now the first thing I open when I plan a post.
