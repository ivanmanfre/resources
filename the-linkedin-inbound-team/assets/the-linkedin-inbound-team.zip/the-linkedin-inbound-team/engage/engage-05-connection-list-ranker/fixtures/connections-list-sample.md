# Fixture, a connections list screen

Invented for testing. Not real people or companies.

Note: exercises MATCH, ADJACENT, NO MATCH, and the parked-no-headline branch
in one pass.

---

Offer sentence: "I help clinic owners get more booked consults without
adding front-desk headcount."

Connections, copied from the connections list screen, in the order shown:

1. Jonah Petrakis - Owner, Fenwick Family Dental
2. Aurelia Danesh - (no headline shown)
3. Btissam Kharrat - Practice Manager, Rourke Physiotherapy
4. Lachlan Vire - Owner-Operator, Milbrook Chiropractic
5. Odalys Ferreira - Front Desk Lead, Solene Dental Group
6. Petar Vuksanovic - (no headline shown)
7. Ines Okonjo - Marketing Manager, Bright Path Wellness
8. Callum Reeve - Founder & Owner, Northshore Vision Clinic
9. Tamsin Oduya - Software Engineer, Vellum Systems
10. Marek Ostrowski - Clinic Director, Fennimore Health
