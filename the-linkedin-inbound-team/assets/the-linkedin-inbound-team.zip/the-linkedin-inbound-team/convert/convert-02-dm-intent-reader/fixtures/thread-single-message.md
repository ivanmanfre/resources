# Fixture, single message from them

Invented for testing. Not a real thread and not a record of any real person.
Exercises Refusal 1.

---

M1 YOU: "Hey, here's the swipe file: <link>."

M2 THEM: "Thanks so much, appreciate you sending it over."
