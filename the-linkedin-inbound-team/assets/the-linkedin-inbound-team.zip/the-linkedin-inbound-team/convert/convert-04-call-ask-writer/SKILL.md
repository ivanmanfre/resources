---
name: convert-04-call-ask-writer
description: "Use once a warm thread has a real problem stated in their own words and it is time to ask for the call. Takes the DM thread in full and returns the call-ask sentence, attached to the sentence of theirs that earns it. Triggers on \"write the call ask for this thread\", \"how do I ask this person for a call\", \"turn this DM into a call\", \"write the line that asks for a call\", \"move this thread to a call\"."
---

# The LinkedIn Inbound Team, CONVERT, unit 28 of 30: the call ask writer

## What this does

Finds the sentence in the thread where they stated a problem in their own
words, and writes one sentence that asks for a call, tied directly to that
sentence.

**The line only this unit produces:** the call-ask sentence, attached to the
sentence of theirs that earns it.

## Required input

1. **The DM thread**, both sides, in full, in order.

## What it refuses

**Refusal 1, no problem in their own words.**

```
NOTHING FOR A CALL TO BE ABOUT
Messages from them: <n>
None of them states a problem, a thing that is not working, costing them
something, or that they have tried and could not fix. A call asked for now
would be asking them to show up and describe their situation to you for the
first time out loud, which is not what a call-ask sentence is for.

What would change that: [NEEDS: one message where they say what is not
working, in their own words]
```

## Method

**Step 1, lay out every message from them.** Number them.

**Step 2, find problem statements.** A problem statement names one of:
something not working, something costing them time or money, something they
tried and it did not hold, or something they do not know how to do. A
statement of interest ("this looks useful") is not a problem statement. A
stated goal with no obstacle named ("I want to grow my list") is not a
problem statement on its own; a goal plus a named obstacle is.

Print every problem statement found, in order, quoted, with its message
number.

**Step 3, pick the one to anchor on.** The anchor is the most recent problem
statement, not the strongest-sounding one. A thread can carry several; the
ask is about where the conversation is now, not about the sharpest line three
messages back.

If the anchor message itself carries two problem statements in two different
sentences, the anchor is the one that comes later inside that message; the
thread ends on that sentence.

**Step 4, write the ask.** One sentence, two parts:

1. a callback to the anchor, in language close to theirs, not a summary that
   drifts from their words
2. the ask itself, naming that it is a short conversation and stating nothing
   about outcome, price, or what happens on the call beyond talking through
   what they described

No second sentence. No question stacked onto a second question. One ask,
done.

**Step 5, the check.** Read the drafted sentence back against the anchor. If
the ask names anything the anchor did not, a cause, a fix, a timeline, a
number, print `OVERREACH: "<the added part>"` and cut it before shipping.

## Output format

```
# Call ask for the thread with <their name>

## Problem statements found
M<n>: "<quoted>"
...

## Anchor
M<n>: "<the most recent one>"

## The ask
"<the call-ask sentence>"

## Check
overreach check: clean | OVERREACH removed: "<what was cut>"
```

## Worked case

This is the fixture run. It is `fixtures/thread-with-problem.md`, executed
line by line against the rules above.

```
## Problem statements found
M2: "I've been trying to fix our welcome sequence for two months and every
version I write gets a worse open rate than the last one."
M4: "I'm honestly not sure if it's the subject line, the send time, or the
list itself at this point."

## Anchor
M4: "I'm honestly not sure if it's the subject line, the send time, or the
list itself at this point."

## The ask
"You said you're not sure anymore whether it's the subject line, the send
time, or the list itself, worth a short call to work through which one it
actually is."

## Check
overreach check: clean
```

The second fixture, `fixtures/thread-no-problem.md`, exercises Refusal 1. The
thread carries interest and a compliment, no message from THEM states
anything not working, and the run stops at `NOTHING FOR A CALL TO BE ABOUT`.

## Edge cases

**The problem is about their team or a vendor, not their own execution.**
Still counts. The problem does not have to be a failure of their own doing,
only their situation.

**A scheduling link is already sitting in the thread**, sent by them earlier.
This unit still writes the ask; it does not check calendars and does not
touch a scheduling tool. The ask stands on its own regardless of what
logistics already exist.

**The most recent problem statement is weaker than an earlier one.** Anchor on
it anyway. Anchoring on an earlier, stronger line would be asking about a
conversation the thread has already moved past.

**They describe the problem twice in slightly different words across two
messages.** Print both under Step 2, and anchor on the later occurrence; the
later phrasing is the one they left you with.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a problem the thread did not state.
- Never attach a promise of an outcome, a fix, or a result to the ask.
- Never write more than one ask.
- Never name a price, a package, or a deliverable in the ask.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  harness, supercharge, game-changer, streamline, empower, utilize.
