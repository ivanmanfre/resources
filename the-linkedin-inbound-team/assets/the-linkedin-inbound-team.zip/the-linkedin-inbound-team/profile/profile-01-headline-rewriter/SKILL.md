---
name: profile-01-headline-rewriter
description: "Use when the LinkedIn headline reads like a job title and a stranger cannot tell who it is for. Takes the headline you have now plus the one sentence that describes your offer, and returns three headline candidates with the character count printed against the 220 limit. Triggers on \"rewrite my LinkedIn headline\", \"my headline says nothing\", \"what should my headline be\", \"fix my headline\", \"headline options for my profile\"."
---

# The LinkedIn Inbound Team, PROFILE, unit 01 of 30: the headline rewriter

## What this does

Reads the headline you have now beside the sentence you use to describe your
offer, and writes three replacements in three fixed shapes, so a stranger who
reads any of them can name who you work with and what changes for them.

**The line only this unit produces:** three headline candidates, each printed
with its character count against the 220 limit.

It does not score your profile, and it does not tell you which of the three to
use. Three shapes are printed because the choice between them is a taste call
that belongs to the person whose name sits above it.

## Required input

1. **The headline you have now**, copied exactly as it appears, separators and
   all. If it is blank, write `blank` and the phrase census in Step 1 prints
   `no phrases supplied`.
2. **Your offer sentence.** One sentence, in your own words, saying who you work
   with and what is different for them afterwards.
3. **Optional: the words your buyers use for themselves.** Job titles as they
   would appear on their own profiles. If supplied, these words are used ahead
   of any word this unit would otherwise pick.

Nothing else is required and nothing else is read. No follower count, no
engagement figure, no profile view count, no export of any kind.

## What it refuses

**Refusal 1, no buyer anywhere.** The buyer test runs at Step 3, once Step 1 has
tagged the headline and Step 2 has read the offer sentence, and it runs on both
of those results together. A buyer is a group of people you could type into LinkedIn's
people search and get people back. `operations directors at mid-size
manufacturers` passes. `businesses`, `companies`, `brands`, `teams`, `clients`,
`people` and `organisations` all fail, because none of them is a person. If
neither input passes the test, stop and print this:

```
NO BUYER NAMED
headline: "<the headline as pasted>"
offer sentence: "<the sentence as pasted>"

The buyer test: could you type this into LinkedIn's people search and get people
back. Nothing in either line passes it.

What was found instead: <the word or words that stood in for a buyer>

Supply one line: the job title your last three enquiries had on their own
profile. Type it the way they write it, not the way you describe them.
```

Do not proceed on a guess. A headline aimed at a category is read by nobody in
it, and this unit has no way to find out who you meant.

**Refusal 2, no candidate ships with an open slot.** Where the offer sentence
carries a buyer but no change, the candidates are still written and the missing
piece prints as `[NEEDS: ...]` inside the candidate. That candidate is not
publishable. Print this line under any candidate carrying a bracket:

```
DO NOT PASTE THIS ONE YET: it carries an open slot. Fill the bracket in your own
words first.
```

Never close the bracket for the reader by picking a plausible change.

## Method

**Step 1, split the current headline and tag every phrase.** Split at the
separators the reader actually used (`|`, bullet characters, commas, line
breaks). Tag each phrase with every tag it carries:

| Tag | What it means |
|---|---|
| `BUYER` | Names a group of people who could be found in people search |
| `CHANGE` | Names what is different for that group afterwards |
| `WORK` | Names the thing you do, with no buyer and no change attached |
| `NEITHER` | Carries none of the three |

A phrase carrying two of these gets both tags printed on its row. Where a single
phrase carries a buyer and a change joined by `for` or `so that`, split it at the
joint first and tag each half on its own row. One phrase, one row, all its tags.

**Step 2, read the offer sentence into three fields.** Quote the span that
carries each one. A span is one unbroken run of words copied out of the offer
sentence. No ellipsis, no stitching two distant runs into one field, and no word
of the sentence appears in two fields. Where the field cannot be filled by one
unbroken run, the field is not filled: print the bracket instead.

```
buyer:  "<span from the offer sentence or the buyer-words line>"
change: "<span>"   | [NEEDS: the change your buyer ends up with, in your words]
work:   "<span>"   | [NEEDS: what you actually do for them, in one clause]
```

The verbs `help`, `support`, `partner with` and `work with` name no work on
their own, so a span containing only one of those is not a work span. A sentence
built out of one of those verbs and a buyer carries a buyer and no change and no
work, and all three fields print that way.

**Step 3, the buyer gate.** If Step 2's buyer slot is empty and Step 1 produced
no `BUYER` phrase, fire Refusal 1 and stop. Otherwise carry the buyer word
forward. Where the buyer-words line was supplied, use its wording over the offer
sentence's wording, and print which one you used.

**Step 4, write three candidates in three fixed shapes.** Every candidate has to
contain the buyer word. Nothing may enter a candidate that was not in one of the
inputs, other than joining words.

- **A, buyer first:** `<buyer> | <change>`. The buyer is the first thing on the
  line, before the company, before the role.
- **B, the work:** one clause naming what you do, with the buyer inside it.
- **C, one sentence:** one sentence written straight through. A separator
  character is a `|`, a bullet, a slash or a dash used to divide the line into
  parts, and shape C carries none of them. Punctuation the sentence needs to
  stay grammatical is not a separator, and neither is punctuation sitting inside
  a span you quoted or inside a `[NEEDS: ...]` bracket. A bracket prints in shape
  C exactly as it prints everywhere else, commas and all.

Where the buyer-words line was supplied, its wording is used in all three shapes,
in the form the buyer-words line wrote it. Do not switch to the offer sentence's
form in one candidate and the buyer-words form in another.

**Step 5, count the characters.** Count every character including spaces and
separators. Print `characters: <n> / 220`. Over 220, print `OVER by <n>` and then
print the cut you made and the shortened line under it, so the reader sees which
words left. A candidate carrying one or more open `[NEEDS: ...]` brackets prints
no number, because the count would change the moment a bracket is filled. It
prints instead one line naming how many brackets are open and which field each
one stands for:

```
characters: not counted, slots open: <n>   <the field name of each open bracket, comma separated>
```

Two candidates carrying different numbers of open brackets never print the same
status line. A candidate missing one field and a candidate missing two are not
the same distance from publishable, and the status line says which is which.

**Step 6, print the phrase census from Step 1.** Population, stated in words:
the phrases in the headline you pasted, split at the separators you used. Every
tag gets its own row, including the ones at zero:

```
phrases in the headline you pasted: <n>
BUYER:    <n>   <the phrases>
CHANGE:   <n>   <the phrases>
WORK:     <n>   <the phrases>
NEITHER:  <n>   <the phrases>
```

Rows do not sum to the phrase count, because a phrase carrying two tags is
counted on both rows. No percentage is printed here. The denominator would be set
by where you happened to put your separators, and a number that moves with your
punctuation is not a finding.

Where the headline was blank, print `phrases in the headline you pasted: 0` and
no census rows.

**Step 7, the left-behind check, run against the input.** Any phrase from Step 1
tagged `BUYER` or `CHANGE` whose words appear in none of the three candidates is
printed as `left behind: "<phrase>"`. This is a check on what your current
headline was carrying, so nothing that was already working disappears without
you seeing it go.

**Step 8, print what was held out, run against the input.** A company name, a
credential or a former title sitting in the headline you pasted is kept out of
the three candidates by the edge cases below. Every such phrase gets its own
printed row naming the phrase and why it was held, so the choice is visible
rather than silent. Where nothing was held out, the section prints `none`.

## Output format

```
# Headline candidates

## Reading
buyer:  "<span>"     source: headline | offer sentence | buyer-words line
change: "<span>"     | [NEEDS: ...]
work:   "<span>"     | [NEEDS: ...]

## A, buyer first
<the headline text>
characters: <n> / 220   | characters: not counted, slots open: <n>   <field names>

## B, the work
<the headline text>
characters: <n> / 220   | characters: not counted, slots open: <n>   <field names>

## C, one sentence
<the headline text>
characters: <n> / 220   | characters: not counted, slots open: <n>   <field names>

## What the headline you pasted was carrying
<the census from Step 6>

## Left behind
- "<phrase>"   | none

## Held out of the candidates
- "<phrase>"   because: <company name | credential | former title>   | none
```

## Worked case

This worked case is a literal run of `fixtures/kettleworth-headline.md`, checked
line by line against the steps above. It is the same input, not a similar one.

```
# Headline candidates

## Reading
buyer:  "operations directors at mid-size manufacturers"   source: offer sentence
        wording used: "operations director" from the buyer-words line, with
        "at mid-size manufacturers" from the offer sentence
change: "onto one system their own team can run"   source: offer sentence
work:   "get the month-end close out of spreadsheets"   source: offer sentence

## A, buyer first
Operations director at mid-size manufacturers | onto one system their own team can run
characters: 86 / 220

## B, the work
I get the month-end close out of spreadsheets for the operations director at mid-size manufacturers
characters: 99 / 220

## C, one sentence
I get the month-end close out of spreadsheets for the operations director at mid-size manufacturers and onto one system their own team can run.
characters: 143 / 220

## What the headline you pasted was carrying
phrases in the headline you pasted: 5
BUYER:    0
CHANGE:   0
WORK:     1   "Founder & CEO @ Kettleworth"
NEITHER:  4   "Helping businesses scale", "Speaker", "Ex-Verrow", "Coffee enthusiast"

## Left behind
none

## Held out of the candidates
- "Founder & CEO @ Kettleworth"   because: company name
- "Ex-Verrow"   because: credential
```

`Helping businesses scale` is tagged `NEITHER` and not `CHANGE`, because
`businesses` fails the buyer test and `scale` names no state anybody could
check. The census rows sum to 5 here, since no phrase in this input carried two
tags.

Three things in this run are worth reading twice, because each one is a rule
above doing visible work. The `change` field is `"onto one system their own team
can run"` and nothing more: it is one unbroken run of the offer sentence, and
the words `out of spreadsheets` are already spent on the `work` field, so they
cannot appear in both. Candidate A says `Operations director`, singular, because
the buyer-words line said `Operations director` and Step 4 holds that form across
all three shapes. Candidate C carries no comma because the offer sentence's own
`and` joins the two halves without one, so the sentence runs straight through.

## Edge cases

**The company name is in the headline.** It is tagged `WORK` or `NEITHER` like
any other phrase and it does not enter the candidates unless the buyer searches
for the company by name. It gets a row in Step 8's held-out section, so the
choice is visible rather than silent.

**A credential sits in the headline** (`Ex-<big company>`, a qualification, a
former title). Tag it `NEITHER`, print it, give it a row in Step 8's held-out
section, and leave it out of the three shapes.
It is a fourth thing the reader can append themselves once they have picked a
line, and appending it changes the character count, so print the count of the
candidate without it.

**The offer sentence has two buyers in it.** Run the whole unit once per buyer
and print two sets of three. One headline aimed at two buyers reads to each of
them as aimed at somebody else. Never merge them into one line with a slash.

**The reader gives a headline and no offer sentence.** If Step 1 produced a
`BUYER` phrase, the run continues with `change: [NEEDS: ...]`. If it did not,
Refusal 1 fires.

**The current headline is already good.** Print the three candidates anyway and
print one line naming the phrase in the current headline that the candidates
kept. This unit has no verdict to give on which is better, so it does not give
one.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a buyer, a change, a number, a company, a credential or a
  qualification the input did not carry.
- Never put a result, an outcome figure, a percentage or a client name in a
  headline candidate.
- Never write a candidate that omits the buyer word.
- Never state which candidate will perform better. There is nothing here that
  could tell you.
- Never count characters by estimate. Count them.
- No em dashes anywhere in the output.
- Banned words in any form: leverage, unlock, elevate, seamless, robust, delve,
  streamline, empower, transformative, compelling, supercharge.
