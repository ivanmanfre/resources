# Fixture, inbound reply that is a thank-you only

Invented for testing. Not a real thread and not a record of any real person.
Exercises Refusal 2, no situation stated, no pitch written.

Person: Wren Castillo
Headline: Founder, Hollow & Finch

---

M1 YOU: "Hi Wren, here's the file: <link>."

M2 THEM: "Thank you, appreciate you sending it over."
