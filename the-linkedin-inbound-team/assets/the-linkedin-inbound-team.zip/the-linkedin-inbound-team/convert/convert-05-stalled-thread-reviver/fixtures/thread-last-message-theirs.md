# Fixture, thread where the last message is theirs

Invented for testing. Not a real thread and not a record of any real person.
Exercises Refusal 1, the reader owes the reply here, not a revival message.

Person: Sable Winters

---

M1 YOU, 4w: "Hey Sable, here's the file: <link>."

M2 THEM, 4w: "Thank you, this is helpful."

M3 YOU, 3w: "Glad it's useful. What are you working on right now."

M4 THEM, 3w: "Rebuilding our checkout flow, mostly the mobile version, it's
been slow going."
