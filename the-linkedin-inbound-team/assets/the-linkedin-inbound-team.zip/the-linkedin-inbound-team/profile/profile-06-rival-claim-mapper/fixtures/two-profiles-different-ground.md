# Fixture, your profile and someone who competes for the same buyer on other ground

Invented people, invented companies. Exercises a competitor selling to the same
buyer from a different category.

---

## YOUR PROFILE

### Headline

Fractional CFO for creative agencies | Cash flow, forecasting, pricing

### About

I work with creative agency owners who are profitable on paper and stressed about payroll.

I build the forecast, run the monthly numbers meeting, and sit in on pricing decisions.

Fifteen years in agency finance before going independent.

No long tie-ins. Monthly, cancel any time.

---

## THEIR PROFILE

### Headline

Helping ambitious founders build businesses that last

### About

I coach owner-managers through the decisions that keep them awake at night: hiring, exits, and what to do when the founder has become the bottleneck.

We usually start with pricing, because that is where the money hides.

Everything I do is one to one, ninety minutes at a time.

I sold my own business in 2019 and have coached fifty owners since.
