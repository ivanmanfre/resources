---
name: engage-01-comment-angle-writer
description: "Use when you want to comment on someone else's post and add something real instead of a generic reaction. Takes the post you want to comment on plus one first-hand fact you actually have about its subject, and returns the comment text with the exact line of their post it answers. Triggers on \"write a comment for this post\", \"what should I say in the comments\", \"comment on this without sounding generic\", \"add something to this post\", \"help me reply to this LinkedIn post\"."
---

# The LinkedIn Inbound Team, ENGAGE, unit 01 of 30: the comment angle writer

## What this does

Reads a post someone else wrote and the one fact you actually have about its
subject, and turns that fact into a comment that adds something the post did
not already say.

**The line only this unit produces:** the comment text, forty words maximum,
paired with the line of their post it answers.

It does not summarize the post back to its author, and it does not compliment
it. Both read as nothing to a person who scans their own comments for real
signal, and posts that get read are read by people paying that kind of
attention.

## Required input

1. **The post you want to comment on**, pasted whole, exactly as it reads on
   the feed.
2. **The one first-hand fact you have about its subject**, in your own words,
   one or two sentences. This is not your opinion of the post. It is
   something that happened to you, something you tested, something you saw,
   or a number you can stand behind.

Nothing else is read. No follower count, no engagement figure, no list of the
author's other posts.

## What it refuses

**Refusal 1, no first-hand fact supplied.** Run the first-hand test on field 2
before anything else. A first-hand fact names an event, a date, a number, or a
specific outcome that happened to the person supplying it. "I think this is
right" and "great point" and "I agree" all fail the test, because none of them
names anything that happened. If field 2 fails, stop and print:

```
NO FIRST-HAND FACT SUPPLIED
what was given: "<field 2 as pasted>"

A comment that adds nothing but agreement is not this unit's job, and writing
one in your name would be borrowed authority: it reads as if you knew
something about this that you have not actually told me.

Supply one sentence: something that happened to you, something you tested,
something you saw, or a number tied to this subject.
```

**Refusal 2, the post carries no line the fact answers.** If every line in the
post is checked in Step 1 and none of them relates to the subject named in
field 2, stop and print:

```
NO MATCHING LINE IN THIS POST
your fact: "<field 2 as pasted>"
post lines checked: <n>

None of the <n> lines in this post are about the same subject as the fact you
gave me, so there is nothing here for it to answer.
```

## Method

**Step 1, split the post into lines and tag each one with its subject in a
few words.** A "line" is a paragraph break as the post shows it, not a
sentence break. Print the count: `lines in the post: <n>`.

**Step 2, run the first-hand test on field 2.** Look for an event, a date, a
number, or a named outcome. If it fails, fire Refusal 1 and stop.

**Step 3, find the line the fact answers.** Compare the subject of field 2
against every line's tag from Step 1. Pick the single closest line. If
nothing matches at all, fire Refusal 2 and stop.

**Step 4, write the comment.** One rule: the comment states the fact, ties it
to the matched line, and adds nothing the input did not carry. No question
mark forced onto the end if the fact does not naturally lead to one. No
"great post" or any variant opening.

**Step 5, count the words.** Count every word in the comment, including the
words in numbers written as digits. Print `words: <n> / 40`. Over 40, cut and
show what left:

```
words: 47 / 40 OVER
cut: "<the words removed>"
final: "<the comment after the cut>"
words: <n> / 40
```

## Output format

```
# Comment
matched line: "<the line from their post>"
comment: "<the comment text>"
words: <n> / 40
```

This is a draft in neutral register, not a claim of your voice. Rewrite it in
your own words before you post it.

## Worked case

This worked case is a literal run of `fixtures/scaling-post-comment.md`,
checked line by line against the steps above. It is the same input, not a
similar one.

```
lines in the post: 4

matched line: "We doubled headcount in Q2 and support tickets went up 40%,
not down like I expected."

comment: "Same pattern here at 12 people: we added two support hires in one
month and first-response time got worse for three weeks before it improved.
The ramp cost showed up in speed, not ticket count."

words: 35 / 40
```

## Edge cases

**The post has already been answered by a comment saying the same thing you
would add.** This unit does not read the comment thread, only the post, so it
has no way to know that. Print one line under the output: `Not checked
against existing comments: this unit reads the post only.`

**Your fact contradicts the post.** Write the comment anyway. A fact that
disagrees with the post is still a fact, and softening it into agreement
would not be this unit's job.

**The post is a question with no claim in it.** Tag every line `QUESTION`
in Step 1 rather than a subject tag, and if field 2 answers the question
directly, that counts as a match in Step 3.

## Hard guardrails

- Where the input does not carry a value this format asks for, print
  `[NEEDS: <what to supply>]`. Never fill the slot with a plausible value.
- Never invent a number, a date, an outcome or an event the reader did not
  supply in field 2.
- Never write "great post", "this resonates", "so true" or any opening that
  carries no fact.
- Never quote a line from the post that is not verbatim.
- No em dashes anywhere in the output. No exclamation marks.
- Banned words in any form: leverage, unlock, elevate, seamless, robust,
  delve, streamline, empower, transformative, compelling, supercharge,
  game-changer, harness, utilize.
